//
//  UIView+OurSlider.m
//  cbm_ios
//
//  Created by mac12 on 2022/02/15.
//

#import "OurSlider.h"


@interface OurSlider ()
{
    float screenWidth;
    float screenHeight;
    UIView *thumbView;
    UIView *trackView;
    UIView *track;
    UIView *haloView;
    UIView *filledTrackView;
    
    float trackViewGap;
    float trackViewHeight;
    float trackHeight;
    float thumbWidth;
    float trackRound;
    float thumbRound;
    float numTextGap;
    float pointWidth;
    float titleTextGap;
    float titleFontSize;
    float titleTextWidth;
    
    float red;
    float green;
    float blue;
    
    UIView *temp_point;
    NSMutableArray *pointArray;
    
    UILabel *balloonLabel;
}

@end

@implementation OurSlider

-(void)setView:(int)r green:(int)g blue:(int)b{
    trackViewGap=30;
    trackViewHeight=20;
    trackHeight=10;
    thumbWidth=15;
    trackRound=trackHeight/2;
    thumbRound=thumbWidth/2;
    numTextGap=8;
    pointWidth=7;
    titleTextGap=0;
    titleFontSize=10;
    titleTextWidth=45;
    
    red=[self calColor:r];
    green=[self calColor:g];
    blue=[self calColor:b];
    NSLog(@"%d %d %d",r, g, b);
    NSLog(@"%f %f %f",red, green, blue);
   // 0.00392156
    
    //pointArray
    pointArray = [[NSMutableArray alloc]init];
    
    NSLog(@"screen size %f %f", [[UIScreen mainScreen]bounds].size.width,[[UIScreen mainScreen]bounds].size.height);
    screenWidth=[[UIScreen mainScreen]bounds].size.width;
    screenHeight=[[UIScreen mainScreen]bounds].size.height;
    
    /*
    
     ourslider
        trackview
            track
            thumb
            pointwrap
                point
                numLabel
        
     
     */
    
    trackView=[[UIView alloc]initWithFrame:CGRectMake([self calResolution:trackViewGap], 0, screenWidth-([self calResolution:trackViewGap]*2), [self calResolution:trackViewHeight])];
//    [trackView setBackgroundColor:UIColor.grayColor];
    [self addSubview:trackView];
    
    // r 0.3921 g0.8627 b0.3882
    track=[[UIView alloc]initWithFrame:
    CGRectMake(0, (trackView.frame.size.height/2)-([self calResolution:trackHeight]/2),
               trackView.frame.size.width, [self calResolution:trackHeight])];
    [track setBackgroundColor:[UIColor colorWithRed:red green:green blue:blue alpha:0.2]];
    [track.layer setMasksToBounds:true];
    [track.layer setCornerRadius:[self calResolution:trackRound]];
    [trackView addSubview:track];
    
    thumbView=[[UIView alloc]initWithFrame:CGRectMake(screenWidth, (trackView.frame.size.height/2)-([self calResolution:thumbWidth]/2), [self calResolution:thumbWidth], [self calResolution:thumbWidth])];
    [thumbView setBackgroundColor:[UIColor colorWithRed:red green:green blue:blue alpha:1]];
    [thumbView.layer setMasksToBounds:true];
    [thumbView.layer setCornerRadius:[self calResolution:thumbRound]];
    [thumbView.layer setBorderWidth:2];
    [thumbView.layer setBorderColor:[UIColor colorWithRed:1 green:1 blue:1 alpha:1].CGColor];
    [trackView addSubview:thumbView];
    [trackView.layer setMasksToBounds:false];
    [self.layer setMasksToBounds:false];
    
    [trackView bringSubviewToFront:thumbView];
    
    
    haloView = [[UIView alloc]initWithFrame:CGRectMake(screenWidth, (trackView.frame.size.height/2)-([self calResolution:thumbWidth]/2), [self calResolution:thumbWidth*2.2], [self calResolution:thumbWidth*2.2])];
    [haloView setBackgroundColor:[UIColor colorWithRed:red green:green blue:blue alpha:0.15]];
    [haloView.layer setMasksToBounds:true];
    [haloView.layer setCornerRadius:[self calResolution:thumbRound*2.2]];
    [trackView addSubview:haloView];

    filledTrackView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, [self calResolution:trackHeight])];
    [filledTrackView setBackgroundColor:[UIColor colorWithRed:red green:green blue:blue alpha:1]];
    [filledTrackView.layer setMasksToBounds:true];
    [filledTrackView.layer setCornerRadius:[self calResolution:trackRound]];
    [trackView addSubview:filledTrackView];

}

-(void)touchedPoint:(UITapGestureRecognizer *)sender{
    NSLog(@"%d",sender.view.tag);
    self.tag=sender.view.tag;
//    [thumbView setFrame:CGRectMake(sender.view.frame.origin.x, thumbView.frame.origin.y, thumbView.frame.size.width, thumbView.frame.size.height)];
    [thumbView setCenter:sender.view.center];
    [haloView setCenter:sender.view.center];
    [haloView.layer removeAllAnimations];
    self->haloView.hidden = NO;
    self->haloView.alpha = 1.0;
    [UIView animateWithDuration:1 animations:^{
        self->haloView.alpha = 0.0;
    } completion:^(BOOL finished){
        if(!finished)
            return;
        else{
            self->haloView.hidden = YES;
            self->haloView.alpha = 1.0;
        }
    }];
    [haloView setCenter:sender.view.center];
    [filledTrackView setBounds:CGRectMake(0, 0, sender.view.center.x, [self calResolution:trackHeight])];
    CGPoint point;
    point.x = sender.view.center.x/2;
    point.y = sender.view.center.y;
    [filledTrackView setCenter:point];
    thumbView.hidden = NO;
    haloView.hidden = NO;
    filledTrackView.hidden = NO;
    //UIViewController *controller 
}

-(void)setPoint:(int)startNum endNum:(int)endNum textArray:(nonnull NSArray *)textArray titleNameType:(int)type{
    [thumbView setFrame:CGRectMake(screenWidth, (trackView.frame.size.height/2)-([self calResolution:thumbWidth]/2), [self calResolution:thumbWidth], [self calResolution:thumbWidth])];
        self.tag=0;
        
        for(UIView *subView in [trackView subviews]){
            if([subView isKindOfClass:[UILabel class]] ){
                [subView removeFromSuperview];
            }
        }
    
    int textCount=(startNum-endNum)*-1;
    
    for(int i=0, ct=startNum;i<=textCount;i++,ct++){
        UITapGestureRecognizer *tr = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(touchedPoint:)];
        //tr.cancelsTouchesInView = NO;
        UIView *pointWrap=[[UIView alloc]initWithFrame:CGRectMake(
                            ((track.frame.size.width-([self calResolution:trackViewHeight]*(textCount+1)))/(textCount))*i+([self calResolution:trackViewHeight]*(i)),
                            (track.frame.size.height/2)-([self calResolution:trackHeight]/2),
                            [self calResolution:trackViewHeight],[self calResolution:trackViewHeight])];
//        [pointWrap setBackgroundColor:UIColor.blueColor];
        [pointWrap.layer setMasksToBounds:false];
        [pointWrap addGestureRecognizer:tr];
        
        [trackView addSubview:pointWrap];
        
        
        UIView *point=[[UIView alloc]initWithFrame:CGRectMake((pointWrap.frame.size.width/2)-([self calResolution:pointWidth]/2),
                                                              (pointWrap.frame.size.height/2)-([self calResolution:pointWidth]/2),
                                                              [self calResolution:pointWidth], [self calResolution:pointWidth])];
        [point setBackgroundColor:[UIColor colorWithRed:red green:green blue:blue alpha:0.5]];
        [point.layer setMasksToBounds:true];
        [point.layer setCornerRadius:[self calResolution:trackHeight]/2];
        [pointWrap setTag:ct];
    //    [point.layer setBorderColor:[UIColor colorWithRed:0.3921 green:0.8627 blue:0.3882 alpha:0.2].CGColor];
        [pointWrap addSubview:point];
        
        [pointArray addObject:pointWrap];
        [pointArray addObject:point];
        //numberLabel 속성 결정
        UILabel *numLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, [self calResolution:trackViewHeight], [self calResolution:trackViewHeight])];
        [numLabel setText:[NSString stringWithFormat:@"%d",ct]];
        [numLabel setTextAlignment:NSTextAlignmentCenter];
        [numLabel setFont:[UIFont fontWithName:@"NanumSquareOTF_acR" size:11]];
//        [numLabel setBackgroundColor:UIColor.redColor];
        [numLabel.layer setMasksToBounds:false];
        [numLabel setCenter:CGPointMake(pointWrap.center.x, pointWrap.frame.origin.y+pointWrap.frame.size.height+[self calResolution:numTextGap])];
        [trackView addSubview:numLabel];
        
        
        if (type==0) {
            UILabel *titleName=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, [self calResolution:titleTextWidth], [self calResolution:trackViewHeight])];
            [titleName setNumberOfLines:10];
            [titleName setText:textArray[i]];
            //[titleName setFont:[UIFont systemFontOfSize:titleFontSize]];
            [titleName setFont:[UIFont fontWithName:@"NanumSquareOTF_acR" size:10]];
            [titleName sizeToFit];
    //        [titleName setBackgroundColor:UIColor.blueColor];
            [titleName setTextAlignment:NSTextAlignmentCenter];
            [titleName.layer setMasksToBounds:false];
            [titleName setCenter:CGPointMake(pointWrap.center.x, numLabel.frame.origin.y+numLabel.frame.size.height+[self calResolution:titleTextGap])];
            [titleName setFrame:CGRectMake(titleName.frame.origin.x, numLabel.frame.origin.y+numLabel.frame.size.height+[self calResolution:titleTextGap], titleName.frame.size.width, titleName.frame.size.height)];
            [trackView addSubview:titleName];
        }else if (type==1){
            UILabel *titleName=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, [self calResolution:titleTextWidth], [self calResolution:trackViewHeight])];
//            [titleName setNumberOfLines:10];
            [titleName setText:textArray[i]];
            //[titleName setFont:[UIFont systemFontOfSize:titleFontSize]];
            [titleName setFont:[UIFont fontWithName:@"NanumSquareOTF_acR" size:10]];
            [titleName sizeToFit];
    //        [titleName setBackgroundColor:UIColor.blueColor];
            
            [titleName.layer setMasksToBounds:false];
            [titleName setCenter:CGPointMake(pointWrap.center.x, numLabel.frame.origin.y+numLabel.frame.size.height+[self calResolution:titleTextGap])];
            
            if(i==0){
                [titleName setTextAlignment:NSTextAlignmentLeft];
                [titleName setFrame:CGRectMake(0, trackView.frame.origin.y-titleName.frame.size.height-[self calResolution:titleTextGap], titleName.frame.size.width, titleName.frame.size.height)];
            }else if(i==textCount){
                [titleName setTextAlignment:NSTextAlignmentRight];
                [titleName setFrame:CGRectMake(trackView.frame.size.width-titleName.frame.size.width, trackView.frame.origin.y-titleName.frame.size.height-[self calResolution:titleTextGap], titleName.frame.size.width, titleName.frame.size.height)];
            }else{
                [titleName setTextAlignment:NSTextAlignmentCenter];
                [titleName setFrame:CGRectMake(titleName.frame.origin.x, trackView.frame.origin.y-titleName.frame.size.height-[self calResolution:titleTextGap], titleName.frame.size.width, titleName.frame.size.height)];
            }
            
            
            
            [trackView addSubview:titleName];

        }
        
        

//        NSLog(@"font %f",titleName.font.pointSize);
    }
    [trackView bringSubviewToFront:thumbView];
}
-(float)calResolution:(float) num{
    return screenWidth*(num/320);
}
-(float)calColor:(int)num{
    if (num==0)
        return 0;
    else
        return (float)1*((float)num/255);
}
-(NSMutableArray*) getView{
    return pointArray;
}

-(void) hiddenThumb{
    [thumbView setCenter:CGPointMake(screenWidth, (trackView.frame.size.height/2)-([self calResolution:thumbWidth]/2))];
    [haloView setCenter:CGPointMake(screenWidth, (trackView.frame.size.height/2)-([self calResolution:thumbWidth]/2))];
    [filledTrackView setCenter:CGPointMake(0, 0)];
    thumbView.hidden = YES;
    haloView.hidden = YES;
    filledTrackView.hidden = YES;
}
@end
