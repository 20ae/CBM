//
//  AppDelegate.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

//objc //AppDelegate.h
@property (strong, nonatomic) UIWindow *window;

@end

