//
//  GoalController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "GoalController.h"

@interface GoalController (){
    int isDoingNetwork; //중복 터치 차단
}

@end

@implementation GoalController

NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수
bool isChecking; // 라디오 버튼들 중 선택된 버튼이 있는지 관리하는 변수
int goalNum; // TestLog의 Goal에 입력할 값을 담는 변수(라디오 버튼 값)
NSString * goalText; //TestLog의 GoalText에 입력할 값을 담는 변수
int btnNum; // 버튼을 클릭한 횟수를 세는 변수

- (void)viewDidLoad {
    [super viewDidLoad];
    isDoingNetwork = 0;
    // 배경 이미지를 화면 크기에 맞게 변경
    UIImage *image = [UIImage imageNamed:@"back_blue.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    // 변수 초기화
    isChecking = false;
    btnNum = 1;
    userDefaults = [NSUserDefaults standardUserDefaults];
    
    // 1페이지 첫 레이블 제외 모든 object 숨김
    _goalNextBtn.hidden = YES;
    _goalNextBtn_Back.hidden = YES;
    _goalLabel1_2.hidden = YES;
    _goalLabel1_3.hidden = YES;
    _goalLabel2_1.hidden = YES;
    _goalLabel2_2.hidden = YES;
    _goalLabel2_3.hidden = YES;
    _goalLabel3_1.hidden = YES;
    [_radioButtons setValue:@(YES) forKey:@"hidden"];
    _goalLabel4_1.hidden = YES;
    _goalYesBtn.hidden = YES;
    _goalNoBtn.hidden = YES;
    _goalLabel5_1.hidden = YES;
    _goalText.hidden = YES;
    _goalLabel6_1.hidden = YES;
    _goalLabel6_2.hidden = YES;
    _goalLabel7_1.hidden = YES;
    
    // 오브젝트가 지연되어 뜨게끔 타이머 설정
    [self performSelector:@selector(visibleLabel:) withObject:_goalLabel1_2 afterDelay:3.0];
    [self performSelector:@selector(visibleLabel:) withObject:_goalLabel1_3 afterDelay:6.0];
    [self performSelector:@selector(visibleBtn:) withObject:_goalNextBtn afterDelay:8.0];
    [self performSelector:@selector(visibleBtnBack:) withObject:_goalNextBtn_Back afterDelay:8.0];
    
}

// Goal, GoalText를 DB에 저장하는 함수
- (void) updateGoal: (int) goal goalText : (NSString *) goalText{
    isDoingNetwork=1;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/update_goal.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];

    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d&goal=%d&goalText=%@", testLogPkey, testPkey, goal, goalText];

    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                if(isDoingNetwork==1)
                    isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                if(isDoingNetwork==1){
                    NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                    NSLog(@"responseData: %@", content);
                    if([content intValue] == 0)
                        [self updateCurrentProgress]; //curProgress +1 증가
                    else{
                        isDoingNetwork = 0;
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];   }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                        }
                }
            }
        } ];
    [dataTask resume];
}

// 목표세우기가 끝났음을 알리기 위해 DB의 currentProgress를 1 증가시키는 함수
- (void) updateCurrentProgress{
    isDoingNetwork=2;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey, testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                if(isDoingNetwork==2)
                    isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                if(isDoingNetwork==2){
                    NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                    NSLog(@"responseData: %@", content);
                    if([content intValue] == 0)
                        [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                    else{
                        isDoingNetwork = 0;
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];   }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                        }
                }
            }
        
    } ];
    [dataTask resume];
}


// 호출하면 레이블을 띄워주는 함수
-(void)visibleLabel:(UILabel *)label
{
    label.hidden = NO;
}

// 호출하면 버튼을 띄워주는 함수
-(void)visibleBtn:(UIButton *)button
{
    button.hidden = NO;
}

// 호출하면 버튼 배경을 띄워주는 함수
-(void)visibleBtnBack:(UIImageView *)image
{
    image.hidden = NO;
}

// goalLabel2_2의 text를 반환해주는 함수
-(NSString *)getLabelText
{
    NSString * userName = [userDefaults objectForKey:@"UserName"]; // 로컬에서 user의 이름 가져오기
    NSString * firstName;
    if(userName.length >= 2)
    {
        firstName = [userName substringFromIndex:1]; // 로컬에 저장된 user의 name에서 첫 글자를 제외하고 가져오기
    }
    else
    {
        firstName = userName; // name이 한 글자인 경우 첫 글자 제외 없이 이름 가져오기
    }
    NSString * resultText = [NSString stringWithFormat:@"%@%@%@",@"그리고 보여주는 선택지에서 ", firstName, @"님의\n14일 후 모습을 하나만 골라보세요😉"];
    
    // 문자열 행간 15로 지정하기
    NSMutableParagraphStyle *style  = [[NSMutableParagraphStyle alloc] init];
    style.lineSpacing = 15;
    style.alignment = NSTextAlignmentCenter;
    NSDictionary *attributtes = @{NSParagraphStyleAttributeName : style,};
    
    _goalLabel2_2.attributedText = [[NSAttributedString alloc] initWithString:resultText attributes:attributtes];
    [_goalLabel2_2 sizeToFit];
    return resultText;
}

// 라디오 버튼(TestLog의 Goal)
- (IBAction)touchRadioButton:(UIButton *)sender {
    if(isChecking){
                for (UIButton* button in _radioButtons){
                    [button setBackgroundImage:[UIImage imageNamed:@"goal_image2.png"] forState:UIControlStateNormal];
                    button.selected = false;
                }
                sender.selected = true;
                [sender setBackgroundImage:[UIImage imageNamed:@"goal_image1.png"] forState:UIControlStateNormal];
                goalNum = (int)[_radioButtons indexOfObject:sender] + 1;
        }
        else{
            sender.selected = true;
            [sender setBackgroundImage:[UIImage imageNamed:@"goal_image1.png"] forState:UIControlStateNormal];
            goalNum = (int)[_radioButtons indexOfObject:sender] + 1;
            isChecking = true;
        }
    
    _goalNextBtn.hidden = NO;
    _goalNextBtn_Back.hidden = NO;
}

// next 버튼 클릭 시 화면 전환
- (IBAction)btnClick:(UIButton *)sender {
    switch(btnNum){
        case 1: // 1번째로 버튼 클릭 시 (1페이지에서 2페이지로 이동)
            _goalLabel1_1.hidden = YES;
            _goalLabel1_2.hidden = YES;
            _goalLabel1_3.hidden = YES;
            _goalLabel2_1.hidden = NO;
            _goalNextBtn.hidden = YES;
            _goalNextBtn_Back.hidden = YES;
            _goalLabel2_2.text = [self getLabelText];
            [self performSelector:@selector(visibleLabel:) withObject:_goalLabel2_2 afterDelay:3.0];
            
            [self performSelector:@selector(visibleLabel:) withObject:_goalLabel2_3 afterDelay:6.0];
            
            [self performSelector:@selector(visibleBtn:) withObject:_goalNextBtn afterDelay:8.0];
            [self performSelector:@selector(visibleBtnBack:) withObject:_goalNextBtn_Back afterDelay:8.0];
            btnNum++;
            break;
        
        case 2: // 2번째로 버튼 클릭 시 (2페이지에서 3페이지로 이동)
            _goalLabel2_1.hidden = YES;
            _goalLabel2_2.hidden = YES;
            _goalLabel2_3.hidden = YES;
            _goalLabel3_1.hidden = NO;
            [_radioButtons setValue:@(NO) forKey:@"hidden"];
            _goalNextBtn.hidden = YES;
            _goalNextBtn_Back.hidden = YES;
            btnNum++;
            break;
            
        case 3: // 3번째로 버튼 클릭 시 (3페이지에서 4페이지로 이동)
            _goalLabel3_1.hidden = YES;
            [_radioButtons setValue:@(YES) forKey:@"hidden"];
            _goalNextBtn.hidden = YES;
            _goalNextBtn_Back.hidden = YES;
            _goalLabel4_1.hidden = NO;
            _goalYesBtn.hidden = NO;
            _goalNoBtn.hidden = NO;
            btnNum++;
            break;
        case 4: // 4번째로 버튼 클릭 시 (4페이지에는 nextBtn이 없음, 4페이지에서 yesBtn 선택 후 넘어온 5페이지에서 직접 작성 후 6 페이지로 이동)
            if([_goalText.text isEqual:@""]){ // goalText 입력 안 했을 시 alert 띄움
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
                    UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
                    [alert addAction:closeAction];
                    [self presentViewController:alert animated:YES completion:nil];
            }
            else{
            _goalLabel5_1.hidden = YES;
            _goalText.hidden = YES;
            _goalNextBtn.hidden = YES;
            _goalNextBtn_Back.hidden = YES;
            _goalLabel6_1.hidden = NO;
            [self performSelector:@selector(visibleLabel:) withObject:_goalLabel6_2 afterDelay:3.0];
            
            [self performSelector:@selector(visibleBtn:) withObject:_goalNextBtn afterDelay:5.0];
            
            [self performSelector:@selector(visibleBtnBack:) withObject:_goalNextBtn_Back afterDelay:5.0];
            goalText = _goalText.text;
            btnNum++;
            }
            break;
        case 5: // 5번째로 버튼 클릭 시 (6페이지)
            if(isDoingNetwork==0)
                [self updateGoal:goalNum goalText:goalText]; // DB로 데이터 전달
                //[self updateCurrentProgress]; // 목표세우기가 끝났으므로 currentprogress 1 증가시키기
                //[self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                break;
        case 6: // 6번째로 버튼 클릭 시 (7페이지)
            if(isDoingNetwork==0)
                [self updateGoal:goalNum goalText:@""]; // DB로 데이터 전달
                //[self updateCurrentProgress]; // 목표세우기가 끝났으므로 currentprogress 1 증가시키기
                //[self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                break;
        
    }
}

// 4페이지에서 Yes 버튼 클릭 시 수행되는 함수 (4페이지에서 5페이지로 이동)
- (IBAction)touchYesBtn:(UIButton *)sender {
    _goalLabel4_1.hidden = YES;
    _goalYesBtn.hidden = YES;
    _goalNoBtn.hidden = YES;
    _goalLabel5_1.hidden = NO;
    _goalText.layer.cornerRadius = 10; // textview 모서리 둥글게 처리
    _goalText.hidden = NO;
    _goalNextBtn.hidden = NO;
    _goalNextBtn_Back.hidden = NO;
}

// 4페이지에서 No 버튼 클릭 시 수행되는 함수 (4페이지에서 7페이지로 이동)
- (IBAction)touchNoBtn:(UIButton *)sender {
    btnNum = 6;
    _goalLabel4_1.hidden = YES;
    _goalYesBtn.hidden = YES;
    _goalNoBtn.hidden = YES;
    _goalLabel7_1.hidden = NO;
    [self performSelector:@selector(visibleBtn:) withObject:_goalNextBtn afterDelay:2.0];
    [self performSelector:@selector(visibleBtnBack:) withObject:_goalNextBtn_Back afterDelay:2.0];
}

//화면 바깥 터치 시 키보드 내리기
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}

@end
