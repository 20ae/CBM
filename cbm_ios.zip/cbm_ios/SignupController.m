//
//  SignupController.m
//  cbm_ios
//
//  Created by ae on 2022/02/08.
//

#import "SignupController.h"

@interface SignupController ()
@end


@implementation SignupController
@synthesize name;
@synthesize number;
@synthesize group_type;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //뒤로가기
    UISwipeGestureRecognizer *rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipes:)];
    rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    [self.view addGestureRecognizer:rightSwipeGestureRecognizer];

    //textField 테두리 및 Padding 적용
    name.borderStyle = UITextBorderStyleNone;
    number.borderStyle = UITextBorderStyleNone;
    
    CGRect viewRect = CGRectMake(10, 10, 20, 53);
    UIView *nameView = [[UIView alloc] initWithFrame:viewRect];
    name.leftView = nameView;
    name.leftViewMode = UITextFieldViewModeAlways;
    name.rightView = nameView;
    name.rightViewMode = UITextFieldViewModeAlways;
    
    UIView *numberView = [[UIView alloc] initWithFrame:viewRect];
    number.leftView = numberView;
    number.leftViewMode = UITextFieldViewModeAlways;
    number.rightView = numberView;
    number.rightViewMode = UITextFieldViewModeAlways;
    
    //배경 화면 맞춤 + 투명도 조절
    UIImage *bgImage = [UIImage imageNamed:@"back_login.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
    
    //그룹 이미지 적용하기
    UISegmentedControl *mySegmentedControl = group_type;

    UIImage *groupImageA = [[UIImage imageNamed:@"selected_a_group_image.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    UIImage *groupImageB = [[UIImage imageNamed:@"selected_b_group_image.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    UIImage *selectGroupImage = [[UIImage imageNamed:@"select_group_image.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 0, 0, 0)];
    
    [mySegmentedControl setDividerImage: selectGroupImage forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [mySegmentedControl setDividerImage: groupImageA forLeftSegmentState:UIControlStateSelected rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [mySegmentedControl setDividerImage: groupImageB forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateSelected barMetrics:UIBarMetricsDefault];
    // Do any additional setup after loading the view.
}

//스와이프 제스쳐 함수
- (void)handleSwipes:(UISwipeGestureRecognizer*)recognizer {
    if (recognizer.direction == UISwipeGestureRecognizerDirectionRight) {
        [self dismissViewControllerAnimated:true completion:nil];
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)signup:(id)sender {
    if(([name.text length] > 0 && name.text != nil && [name.text isEqual:@""] == FALSE) && ([number.text length] > 0 && number.text != nil && [number.text isEqual:@""] == FALSE) && (group_type.selectedSegmentIndex != -1)){
        NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
        // Disables cacheing
        defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
        NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
        
        NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/trySignup.php";
        NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
        
        // post 데이터를 넣는 부분
    NSString *postData = [NSString stringWithFormat:@"name=%@&id=%@&group_type=%d", name.text, number.text , group_type.selectedSegmentIndex];
        [urlRequest setHTTPMethod:@"POST"];
        [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
        NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
                
                if(error){
                    NSLog(@"network error!");
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];
                    }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
                else{
                    
                    NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                    NSLog(@"responseData1: %@", content);
                    
                    if([content intValue] == -1){
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"회원가입 실패" message:@"입력하신 참가번호가 존재합니다." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                        }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                    }
                    else{
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"등록하기 성공" message:@"등록하기가 완료되었습니다." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];
                            [self dismissViewControllerAnimated:true completion:nil];
                        }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                    }
                }
                
            } ];
        [dataTask resume];
    }
    else if(group_type.selectedSegmentIndex == -1){
        //그룹 선택 경고
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"회원가입 실패" message:@"그룹을 선택하세요" preferredStyle: UIAlertControllerStyleAlert];
        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
            [alert dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
    }
    else if(name.text && [name.text length] == 0){
        //이름 입력 경고창
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"회원가입 실패" message:@"이름을 입력하세요" preferredStyle: UIAlertControllerStyleAlert];
        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
            [alert dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
        
    }else if(number.text && [number.text length] == 0){
        //참가번호 입력 경고창
        UIAlertController *alert = [UIAlertController
                                    alertControllerWithTitle:@"회원가입 실패"
                                    message:@"참가번호를 입력하세요"
                                    preferredStyle: UIAlertControllerStyleAlert];
        UIAlertController* cancel = [UIAlertAction
                                     actionWithTitle:@"확인"
                                     style:UIAlertActionStyleDefault
                                     handler:^(UIAlertAction * action){
            [alert dismissViewControllerAnimated:YES completion:nil];
        }];
        [alert addAction:cancel];
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}

//화면 바깥 터치 시 키보드 내리기
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}
@end
