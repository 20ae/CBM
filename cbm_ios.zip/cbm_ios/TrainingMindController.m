//
//  TrainingMindController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "TrainingMindController.h"

@interface TrainingMindController ()
{
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    AVPlayer *player2;
    AVPlayerLayer *playerLayer2;
    AVPlayer *player3;
    AVPlayerLayer *playerLayer3;
    AVPlayer *player4;
    AVPlayerLayer *playerLayer4;
    AVPlayer *player5;
    AVPlayerLayer *playerLayer5;
    AVPlayer *player6;
    AVPlayerLayer *playerLayer6;
    OurSlider* slider;
    NSArray *textArray;
    NSArray *textArray2;
    int count;
    int firstpg;
    int secondpg;
    int thirdpg;
    int fifthpg;
    int image;
    int testPkey;
    int testLogPkey;
    int updateNumber;
    int isDoingNetwork;
    int isSendingData;
}
@property (weak, nonatomic) IBOutlet UIImageView *TrainButBack;
@property (weak, nonatomic) IBOutlet UIButton *TrainMindBut;
//첫번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel_2;
@property (weak, nonatomic) IBOutlet UIImageView *TrainMindImg;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel2;

//두번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel3;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel4;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel5;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel6;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel7;

//세번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel8;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel9;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel10;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel11;

//다섯번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel12;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel13;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel13_2;


//일곱번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel14;
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel15;

//여덟번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel16;

//스물번째 장면
@property (weak, nonatomic) IBOutlet UILabel *TrainMindLabel17;
@property (weak, nonatomic) IBOutlet UIImageView *TrainMindImg2;

@end

@implementation TrainingMindController



- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    isDoingNetwork = 0;
    isSendingData = 0;
    //slider관련 action함수는 touchesBegan CGRectMake은 x,y,width,height이며 width와 height,x 고정하고 y축으로 위치 잡기
    slider = [[OurSlider alloc] initWithFrame:CGRectMake(0, UIScreen.mainScreen.bounds.size.height*0.45, UIScreen.mainScreen.bounds.size.width, 100)];
    //example hax ffdbfc -> red: 0xff green: 0xdb blue: 0xfc
    [slider setView:0x64 green:0xdc blue:0x63];
    //slider값 사용시 slider.tag로 하면 된다.
    [self.view addSubview:slider];
    //slider밑에 라벨할 글 array하기
    textArray2=[NSArray arrayWithObjects:@"전혀\n몰입되지\n않음",@"",@"약간\n몰입한",@"",@"어느 정도\n몰입한",@"",@"꽤\n몰입한",@"",@"매우\n몰입한",nil];
    textArray=[NSArray arrayWithObjects:@"전혀\n생생하지\n않음",@"",@"약간\n생생한",@"",@"어느 정도\n생생한",@"",@"꽤\n생생한",@"",@"매우\n생생한", nil];
    //textArray에 값을 넣고 titleNameType지정하기(titleNameType - 0:textArray가 slider 아래 1:textArray가 slider 위)
    [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
    slider.hidden = YES;
    
    
    //레이아웃 횟수
    count = 0;
    firstpg = 0;
    secondpg = 0;
    thirdpg = 0;
    fifthpg = 0;
    
    //update 횟수
    updateNumber = 0;
    
    //TestPkey와 TestLogPkey
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    
    printf("testPkey: %d\n",testPkey);
    printf("testLogPkey: %d\n", testLogPkey);
    
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_green.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼 관련 변수
    self.TrainMindBut.hidden = YES;
    self.TrainButBack.hidden = YES;
    [_TrainMindBut setTitle:@"" forState:UIControlStateNormal];
    //앱 다시 활성활 때 호출하는 함수
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(apWillEnterForeground:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    
    //첫번째 장면
    {
        self.TrainMindLabel.hidden = NO;
        self.TrainMindLabel_2.hidden = NO;
        self.TrainMindImg.hidden = NO;
        self.TrainMindLabel2.hidden = YES;
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:[_TrainMindLabel_2 text]];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:19] range:NSMakeRange(0, 11)];
        [_TrainMindLabel_2 setAttributedText:textFont];
        NSMutableAttributedString* textFont2 = [[NSMutableAttributedString alloc] initWithString:[_TrainMindLabel2 text]];
        [textFont2 addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(27, 11)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont2.length)];
        [_TrainMindLabel2 setAttributedText:textFont2];
    }
    //두번째 장면
    {
        self.TrainMindLabel3.hidden = YES;
        self.TrainMindLabel4.hidden = YES;
        self.TrainMindLabel5.hidden = YES;
        self.TrainMindLabel6.hidden = YES;
        self.TrainMindLabel7.hidden = YES;
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:[_TrainMindLabel4 text]];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(0, 17)];
        [_TrainMindLabel4 setAttributedText:textFont];
        NSMutableAttributedString* textFont2 = [[NSMutableAttributedString alloc] initWithString:[_TrainMindLabel6 text]];
        [textFont2 addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(0, 12)];
        [_TrainMindLabel6 setAttributedText:textFont2];
        
    }
    //세번째 장면
    {
        self.TrainMindLabel8.hidden = YES;
        self.TrainMindLabel9.hidden = YES;
        self.TrainMindLabel10.hidden = YES;
        self.TrainMindLabel11.hidden = YES;
        NSString *labelText = @"현재 그 일이 일어나는 것처럼 상상하시기\n바랍니다.";
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:labelText];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:15] range:NSMakeRange(0, 22)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:7];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont.length)];
        [_TrainMindLabel10 setAttributedText:textFont];
    }
    //네번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_imagine/1.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay:) name:AVPlayerItemPlaybackStalledNotification object:[player currentItem]];
    }
    //다섯번째 장면
    {
        self.TrainMindLabel12.hidden = YES;
        self.TrainMindLabel13.hidden = YES;
        self.TrainMindLabel13_2.hidden = YES;
        NSString *modifyText =@"앞으로 여러분은 시간과 공간을\n뛰어넘어 이야기가 들려주는 장면으로\n가보는 여행을 해 볼 겁니다.";
        NSString *modifyText2=@"마음으로 상상할 때는 오감각을\n활용한다는 것, 잊지 마세요!!!";
        NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:modifyText];
        NSMutableAttributedString *modifyLabel2 = [[NSMutableAttributedString alloc] initWithString:modifyText2];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
        [modifyLabel2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel2.length)];
        [_TrainMindLabel13 setAttributedText:modifyLabel];
        [_TrainMindLabel13_2 setAttributedText:modifyLabel2];
    }
    //여섯번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_imagine/2.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player2 = [AVPlayer playerWithURL:url];
        player2.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player2 currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay2:) name:AVPlayerItemPlaybackStalledNotification object:[player2 currentItem]];
    }
    //일곱번째 장면
    {
        self.TrainMindLabel14.hidden = YES;
        self.TrainMindLabel15.hidden = YES;
    }
    //여덟번째 장면
    {
        self.TrainMindLabel16.hidden = YES;
    }
    //아홉번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_imagine/3.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player3 = [AVPlayer playerWithURL:url];
        player3.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player3 currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay3:) name:AVPlayerItemPlaybackStalledNotification object:[player3 currentItem]];
    }
    //열두번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_imagine/4.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player4 = [AVPlayer playerWithURL:url];
        player4.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player4 currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay4:) name:AVPlayerItemPlaybackStalledNotification object:[player4 currentItem]];
    }
    //열다섯번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_imagine/5.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player5 = [AVPlayer playerWithURL:url];
        player5.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player5 currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay5:) name:AVPlayerItemPlaybackStalledNotification object:[player5 currentItem]];
    }
    //열여덟번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_imagine/6.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player6 = [AVPlayer playerWithURL:url];
        player6.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player6 currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay6:) name:AVPlayerItemPlaybackStalledNotification object:[player6 currentItem]];
    }
    //스물번째 장면
    {
        self.TrainMindLabel17.hidden = YES;
        self.TrainMindImg2.hidden = YES;
    }
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(TrainMin1pgNext:) userInfo:NO repeats:YES];

}


-(void)TrainMin1pgNext:(NSTimer*)timer{
    firstpg++;
    
    if(firstpg == 1){
        self.TrainMindLabel2.hidden = NO;
    }
    else{
        self.TrainMindBut.hidden = NO;
        self.TrainButBack.hidden = NO;
        self.TrainMindBut.enabled = YES;
        [timer invalidate];
    }
}

-(void)TrainMin2pgNext:(NSTimer*)timer{
    secondpg++;
    
    if(secondpg == 1){
        self.TrainMindLabel7.hidden = NO;
    }
    else{
        self.TrainMindBut.hidden = NO;
        self.TrainButBack.hidden = NO;
        self.TrainMindBut.enabled = YES;
        [timer invalidate];
    }
}

-(void)TrainMin3pgNext:(NSTimer*)timer{
    thirdpg++;
    
    if(thirdpg == 1){
        self.TrainMindLabel9.hidden = NO;
        self.TrainMindLabel10.hidden = NO;
    }
    else{
        self.TrainMindLabel11.hidden = NO;
        self.TrainMindBut.hidden = NO;
        self.TrainButBack.hidden = NO;
        self.TrainMindBut.enabled = YES;
        [timer invalidate];
    }
}

-(void)TrainMin5pgNext:(NSTimer*)timer{
    fifthpg++;
    if(fifthpg == 1){
        self.TrainMindLabel13.hidden = NO;
    }
    else if(fifthpg == 2){
        self.TrainMindLabel13_2.hidden = NO;
    }
    else{
        self.TrainMindBut.hidden = NO;
        self.TrainButBack.hidden = NO;
        self.TrainMindBut.enabled = YES;
        [timer invalidate];
    }
}

- (IBAction)ActionTrainMinBut:(id)sender {
    self.TrainMindBut.enabled = NO;
    switch(count){
        case 0:
            {
                count++;
                self.TrainMindLabel.hidden = YES;
                self.TrainMindImg.hidden = YES;
                self.TrainMindLabel_2.hidden = YES;
                self.TrainMindLabel2.hidden = YES;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                self.TrainMindLabel3.hidden = NO;
                self.TrainMindLabel4.hidden = NO;
                self.TrainMindLabel5.hidden = NO;
                self.TrainMindLabel6.hidden = NO;
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(TrainMin2pgNext:) userInfo:NO repeats:YES];
            }
            break;
        case 1:
            {
                count++;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                self.TrainMindLabel3.hidden = YES;
                self.TrainMindLabel4.hidden = YES;
                self.TrainMindLabel5.hidden = YES;
                self.TrainMindLabel6.hidden = YES;
                self.TrainMindLabel7.hidden = YES;
                self.TrainMindLabel8.hidden = NO;
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(TrainMin3pgNext:) userInfo:NO repeats:YES];
            }
            break;
        case 2:
            {
                count++;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                self.TrainMindLabel8.hidden = YES;
                self.TrainMindLabel9.hidden = YES;
                self.TrainMindLabel10.hidden = YES;
                self.TrainMindLabel11.hidden = YES;
                
                if(isSendingData==0){
                    [player play];
                        
                    playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
                    playerLayer.frame = self.view.bounds;
                    float x = 0;
                    float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                    float width = playerLayer.frame.size.width;
                    float height = playerLayer.frame.size.height;
                    CGRect resizeRect = CGRectMake(x, y, width, height);
                    [playerLayer setFrame:resizeRect];
                    [self.view.layer addSublayer:playerLayer];
                    
                    isSendingData = 1;
                }
                
            }
            break;
        case 4:
            {
                count++;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                self.TrainMindLabel12.hidden = YES;
                self.TrainMindLabel13.hidden = YES;
                self.TrainMindLabel13_2.hidden = YES;
                
                if(isSendingData==0){
                    [player2 play];
                    
                    playerLayer2 = [AVPlayerLayer playerLayerWithPlayer:player2];
                    playerLayer2.frame = self.view.bounds;
                    float x = 0;
                    float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                    float width = playerLayer2.frame.size.width;
                    float height = playerLayer2.frame.size.height;
                    CGRect resizeRect = CGRectMake(x, y, width, height);
                    [playerLayer2 setFrame:resizeRect];
                    [self.view.layer addSublayer:playerLayer2];
                    
                    isSendingData = 1;
                }
                
            }
            break;
        case 6:
            {
                count++;
                image = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                //slider 밑에 몰입한 글 종류로 변환
                [slider setPoint:1 endNum:9 textArray:textArray2 titleNameType:0];
                [slider hiddenThumb];
                self.TrainMindLabel15.hidden = YES;
                self.TrainMindLabel16.hidden = NO;
            }
            break;
        case 7:
            {
                count++;
                int focus = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                [slider hiddenThumb];
                slider.hidden = YES;
                self.TrainMindLabel14.hidden = YES;
                self.TrainMindLabel16.hidden = YES;
                updateNumber++;
                
                if(isSendingData==0)
                    [self updateImage:testLogPkey :updateNumber :image :focus];
            }
            break;
        case 9:
            {
                count++;
                image = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                //slider 밑에 몰입한 글 종류로 변환
                [slider setPoint:1 endNum:9 textArray:textArray2 titleNameType:0];
                [slider hiddenThumb];
                self.TrainMindLabel15.hidden = YES;
                self.TrainMindLabel16.hidden = NO;
            }
            break;
        case 10:
            {
                count++;
                int focus = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                [slider hiddenThumb];
                slider.hidden = YES;
                self.TrainMindLabel14.hidden = YES;
                self.TrainMindLabel16.hidden = YES;
                updateNumber++;
                
                if(isSendingData==0)
                    [self updateImage:testLogPkey :updateNumber :image :focus];
            }
            break;
        case 12:
            {
                count++;
                image = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                //slider 밑에 몰입한 글 종류로 변환
                [slider setPoint:1 endNum:9 textArray:textArray2 titleNameType:0];
                [slider hiddenThumb];
                self.TrainMindLabel15.hidden = YES;
                self.TrainMindLabel16.hidden = NO;
            }
            break;
        case 13:
            {
                count++;
                int focus = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                [slider hiddenThumb];
                slider.hidden = YES;
                self.TrainMindLabel14.hidden = YES;
                self.TrainMindLabel16.hidden = YES;
                updateNumber++;
                
                if(isSendingData==0)
                    [self updateImage:testLogPkey :updateNumber :image :focus];
            }
            break;
        case 15:
            {
                count++;
                image = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                //slider 밑에 몰입한 글 종류로 변환
                [slider setPoint:1 endNum:9 textArray:textArray2 titleNameType:0];
                [slider hiddenThumb];
                self.TrainMindLabel15.hidden = YES;
                self.TrainMindLabel16.hidden = NO;
            }
            break;
        case 16:
            {
                count++;
                int focus = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                [slider hiddenThumb];
                slider.hidden = YES;
                self.TrainMindLabel14.hidden = YES;
                self.TrainMindLabel16.hidden = YES;
                updateNumber++;
                
                if(isSendingData==0)
                    [self updateImage:testLogPkey :updateNumber :image :focus];
            }
            break;
        case 18:
            {
                count++;
                image = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                //slider 밑에 몰입한 글 종류로 변환
                [slider setPoint:1 endNum:9 textArray:textArray2 titleNameType:0];
                [slider hiddenThumb];
                self.TrainMindLabel15.hidden = YES;
                self.TrainMindLabel16.hidden = NO;
            }
            break;
        case 19:
            {
                count++;
                int focus = (int)slider.tag;
                self.TrainMindBut.hidden = YES;
                self.TrainButBack.hidden = YES;
                slider.hidden = YES;
                self.TrainMindLabel14.hidden = YES;
                self.TrainMindLabel16.hidden = YES;
                updateNumber++;
                
                if(isSendingData==0)
                    [self updateImage:testLogPkey :updateNumber :image :focus];
            }
            break;
        default:
            if(isDoingNetwork==0)
                [self updateDoneSection:testLogPkey :testPkey];
                //[self.navigationController popViewControllerAnimated:YES];
                break;
    }
}

- (void) updateImage: (int) testLogPkey : (int) videoNum : (int) imageLevel : (int) focusLevel{
    
    isSendingData=1;
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/update_imagine.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이다.
    NSString *postData = [NSString stringWithFormat:@"testLogPkey=%d&videoNum=%d&imagineLevelText=%d&focusLevelText=%d", testLogPkey, videoNum, imageLevel, focusLevel];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                self->isSendingData=0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0){
                    switch(self->count){
                        case 8:
                            {
                                [self->player3 play];
                                self->playerLayer3 = [AVPlayerLayer playerLayerWithPlayer:self->player3];
                                self->playerLayer3.frame = self.view.bounds;
                                float x = 0;
                                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                                float width = self->playerLayer3.frame.size.width;
                                float height = self->playerLayer3.frame.size.height;
                                CGRect resizeRect = CGRectMake(x, y, width, height);
                                [self->playerLayer3 setFrame:resizeRect];
                                [self.view.layer addSublayer:self->playerLayer3];
                            }
                            break;
                        case 11:
                            {
                                [self->player4 play];
                                self->playerLayer4 = [AVPlayerLayer playerLayerWithPlayer:self->player4];
                                self->playerLayer4.frame = self.view.bounds;
                                float x = 0;
                                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                                float width = self->playerLayer4.frame.size.width;
                                float height = self->playerLayer4.frame.size.height;
                                CGRect resizeRect = CGRectMake(x, y, width, height);
                                [self->playerLayer4 setFrame:resizeRect];
                                [self.view.layer addSublayer:self->playerLayer4];
                            }
                            break;
                        case 14:
                            {
                                [self->player5 play];
                                
                                self->playerLayer5 = [AVPlayerLayer playerLayerWithPlayer:self->player5];
                                self->playerLayer5.frame = self.view.bounds;
                                float x = 0;
                                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                                float width = self->playerLayer5.frame.size.width;
                                float height = self->playerLayer5.frame.size.height;
                                CGRect resizeRect = CGRectMake(x, y, width, height);
                                [self->playerLayer5 setFrame:resizeRect];
                                [self.view.layer addSublayer:self->playerLayer5];
                            }
                            break;
                        case 17:
                            {
                                [self->player6 play];
                                self->playerLayer6 = [AVPlayerLayer playerLayerWithPlayer:self->player6];
                                self->playerLayer6.frame = self.view.bounds;
                                float x = 0;
                                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                                float width = self->playerLayer6.frame.size.width;
                                float height = self->playerLayer6.frame.size.height;
                                CGRect resizeRect = CGRectMake(x, y, width, height);
                                [self->playerLayer6 setFrame:resizeRect];
                                [self.view.layer addSublayer:self->playerLayer6];
                            }
                            break;
                        case 20:
                            {
                                self.TrainMindImg2.hidden = NO;
                                self.TrainMindLabel17.hidden = NO;
                                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(TrainMin5pgNext:) userInfo:NO repeats:NO];
                            }
                            break;
                        default:
                            break;
                    }
                }
                else{
                    self->isSendingData = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
    
    
}

- (void) updateDoneSection: (int) testLogPkey : (int) testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이다.
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey,testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
}

//slider touch action
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
    UITouch *touch = [touches anyObject];
    printf("value: %d\n",(int)slider.tag);
    NSMutableArray *pointArray = slider.getView;
    int len = (int)pointArray.count;
    
    for(int i=0;i<len;i++){
        if(pointArray[i]==touch.view){
            self.TrainMindBut.hidden = NO;
            self.TrainButBack.hidden = NO;
            self.TrainMindBut.enabled = YES;
            break;
        }
    }
    
    
}
//동영상 중단 시 호출되는 함수
- (void)replay:(NSNotification *)notification{
    [player play];
    NSLog(@"pause video replay");
}
- (void)replay2:(NSNotification *)notification{
    [player2 play];
    NSLog(@"pause video replay");
}
- (void)replay3:(NSNotification *)notification{
    [player3 play];
    NSLog(@"pause video replay");
}
- (void)replay4:(NSNotification *)notification{
    [player4 play];
    NSLog(@"pause video replay");
}
- (void)replay5:(NSNotification *)notification{
    [player5 play];
    NSLog(@"pause video replay");
}
- (void)replay6:(NSNotification *)notification{
    [player6 play];
    NSLog(@"pause video replay");
}
//동영상 종료 시 호출되는 함수
- (void)playerItemDidReachEnd:(NSNotification *)notification {
    NSLog(@"Ending");
    isSendingData = 0;
    
    if(count == 3){
        playerLayer.hidden = YES;
        count++;
        self.TrainMindLabel12.hidden = NO;
        NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(TrainMin5pgNext:) userInfo:NO repeats:YES];
    }
    else if(count == 5){
        playerLayer2.hidden = YES;
        count++;
        //slider 밑에 생생한 글 종류로 변환
        [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
        slider.hidden = NO;
        self.TrainMindLabel14.hidden = NO;
        self.TrainMindLabel15.hidden = NO;
    }
    else if(count == 8){
        playerLayer3.hidden = YES;
        count++;
        //slider 밑에 생생한 글 종류로 변환
        [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
        slider.hidden = NO;
        self.TrainMindLabel14.hidden = NO;
        self.TrainMindLabel15.hidden = NO;
    }
    else if(count == 11){
        playerLayer4.hidden = YES;
        count++;
        //slider 밑에 생생한 글 종류로 변환
        [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
        slider.hidden = NO;
        self.TrainMindLabel14.hidden = NO;
        self.TrainMindLabel15.hidden = NO;
    }
    else if(count == 14){
        playerLayer5.hidden = YES;
        count++;
        //slider 밑에 생생한 글 종류로 변환
        [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
        slider.hidden = NO;
        self.TrainMindLabel14.hidden = NO;
        self.TrainMindLabel15.hidden = NO;
    }
    else{
        playerLayer6.hidden = YES;
        count++;
        //slider 밑에 생생한 글 종류로 변환
        [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
        slider.hidden = NO;
        self.TrainMindLabel14.hidden = NO;
        self.TrainMindLabel15.hidden = NO;
    }
}
//홈버튼 누르고 나서 다시 앱이 활성화 할 때 호출되는 함수
- (void)apWillEnterForeground:(NSNotification *)notification{
    NSLog(@"확인");
    switch (count) {
        case 3:
            if(player.timeControlStatus == AVPlayerTimeControlStatusPaused){
                [player play];
            }
            break;
        case 5:
            if(player2.timeControlStatus == AVPlayerTimeControlStatusPaused){
                [player2 play];
            }
            break;
        case 8:
            if(player3.timeControlStatus == AVPlayerTimeControlStatusPaused){
                [player3 play];
            }
            break;
        case 11:
            if(player4.timeControlStatus == AVPlayerTimeControlStatusPaused){
                [player4 play];
            }
            break;
        case 14:
            if(player5.timeControlStatus == AVPlayerTimeControlStatusPaused){
                [player5 play];
            }
            break;
        case 17:
            if(player6.timeControlStatus == AVPlayerTimeControlStatusPaused){
                [player6 play];
            }
            break;
            
    }
}

@end
