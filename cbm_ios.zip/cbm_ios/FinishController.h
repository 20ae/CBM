//
//  FinishController.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FinishController : UIViewController <NSURLSessionDataDelegate>

@property (weak, nonatomic) IBOutlet UILabel *finishLabel2;
@property (weak, nonatomic) IBOutlet UIButton *finishNextBtn;
@property (weak, nonatomic) IBOutlet UIImageView *finishNextBtn_Back;

- (IBAction)touchNextBtn:(UIButton *)sender;

// 타이머에서 호출하는 함수들
-(void)visibleLabel:(UILabel *)label;
-(void)visibleBtn:(UIButton *)button;
-(void)visibleBtnBack:(UIImageView *)image;

@end

NS_ASSUME_NONNULL_END
