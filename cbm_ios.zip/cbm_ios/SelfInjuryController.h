//
//  SelfInjuryController.h
//  cbm_ios
//
//  Created by DS on 2022/02/14.
//

@import AVFoundation;
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SelfInjuryController : UIViewController <NSURLSessionDataDelegate>
// next 버튼
@property (weak, nonatomic) IBOutlet UIButton *selfInjuryNextBtn;
@property (weak, nonatomic) IBOutlet UIImageView *selfInjuryNextBtn_Back;
- (IBAction)touchNextBtn:(UIButton *)sender;


// 자해 심리 교육 1page
@property (weak, nonatomic) IBOutlet UILabel *selfInjuryLabel1_1;
@property (weak, nonatomic) IBOutlet UILabel *selfInjuryLabel1_2;
@property (weak, nonatomic) IBOutlet UILabel *selfInjuryLabel1_3;

// 자해 심리 교육 2page
@property (strong, nonatomic) AVPlayerLayer * videoLayer;
- (void)playerItemDidReachEnd:(NSNotification *)notification;

// 자해 심리 교육 3page
@property (weak, nonatomic) IBOutlet UILabel *selfInjuryLabel3_1;
@property (weak, nonatomic) IBOutlet UILabel *selfInjuryLabel3_2;
@property (weak, nonatomic) IBOutlet UILabel *selfInjuryLabel3_3;

// 화면에 띄울 때 사용하는 함수들 (타이머에서 호출해서 사용)
-(void)visibleLabel:(UILabel *)label;
-(void)visibleBtn:(UIButton *)button;
-(void)visibleBtnBack:(UIImageView *)image;

@end

NS_ASSUME_NONNULL_END
