//
//  HomeController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "HomeController.h"

@interface HomeController ()
{
    float buttonGap;
    float screenWidth;
    float screenHeight;

}
@property (weak, nonatomic) IBOutlet UILabel *day;
@property (weak, nonatomic) IBOutlet UILabel *meeting;
@property (weak, nonatomic) IBOutlet UILabel *greeting;

@property (weak, nonatomic) IBOutlet UIImageView *moonImage;
@property (weak, nonatomic) IBOutlet UIImageView *moonHalfImage;
@property (weak, nonatomic) IBOutlet UIImageView *moonFullImage;

@property (weak, nonatomic) IBOutlet UIButton *btnlog;
@property (weak, nonatomic) IBOutlet UIButton *btnappr;
@property (weak, nonatomic) IBOutlet UIButton *btnedu;
@property (weak, nonatomic) IBOutlet UIButton *btnot;
@property (weak, nonatomic) IBOutlet UIButton *btnmind;
@property (weak, nonatomic) IBOutlet UIButton *btntraincbm;
@property (weak, nonatomic) IBOutlet UIButton *btnrelax;
@property (weak, nonatomic) IBOutlet UIButton *btnVideo;
@property (weak, nonatomic) IBOutlet UIButton *btngoal;
@property (weak, nonatomic) IBOutlet UIButton *btnorientation;
@property (weak, nonatomic) IBOutlet UIButton *btnfinish;
@property (weak, nonatomic) IBOutlet UIButton *btncheck;
@property (weak, nonatomic) IBOutlet UIButton *btnself;
@property (weak, nonatomic) IBOutlet UIScrollView *realScrollview;

@property (weak, nonatomic) IBOutlet UIView *scrollView;
@property (strong, nonatomic) IBOutlet UIView *homeView;
@property (weak, nonatomic) IBOutlet UIImageView *bottomImage;
@property (weak, nonatomic) IBOutlet UIButton *settingBtn;

@end

@implementation HomeController

//home 변수
NSUserDefaults* userDefaults;
int count = 0; //차수를 받아오는 변수
int currentProgress = 0;
NSString *dayText =@""; //며칠인지 나타내는 변수
NSString *roundText = @""; //몇회차인지 나타내는
int groupType;
int lastItemIndex = 0;
//각 회차별 해당 버튼배열
UIButton* arrBtn[6];

NSDictionary *dict;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    //데이터를 가져오는 방법
    userDefaults = [NSUserDefaults standardUserDefaults];
    groupType = (int)[userDefaults integerForKey:@"GroupType"];
    //위에 내비 숨기기
    self.navigationController.navigationBar.hidden=YES;
    
    buttonGap=20; //320*480 20dp
    screenWidth=[[UIScreen mainScreen]bounds].size.width;
    screenHeight=[[UIScreen mainScreen]bounds].size.height;
    //menu button & moonimage hidden
    [self setDisableButton];
    [self setHiddenMoon];
    //전체 버튼 이미지 입히기
    [self setBtnBack];
    //이미지 바꾸기 위한 딕셔너리 만들기
    [self makeDictionary];
    //설정하단바
    [self makeBottomNav];
    

    UIImage *bgImage = [UIImage imageNamed:@"back_home.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
    
    //히스토리 초기화 스와이프 백 막기
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.enabled = NO;
        }
}

- (void) viewWillAppear:(BOOL)animated{
    // android의 onResume()
    [super viewWillAppear:animated];
    
    
    //만남 메시지 - 줄간격
    NSString* string1 = @"만나서 반가워요😊\n오늘 하루도 힘차게 보내봐요!";
    [self setGreetingStyle:string1];
    self->_settingBtn.enabled = YES;
    int userpkey = (int)[userDefaults integerForKey:@"UserPKey"];
    [self requestTestPkey:userpkey];
    //int testpkey = (int)[userDefaults integerForKey:@"testPkey"];
    //[self createLog:testpkey];
   
    NSLog(@"뷰윌어피어");
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //다른 페이지로 이동할 때 버튼을 unenabled로 해주기
    [self disable_button];
    self->_settingBtn.enabled = NO;
}


- (void) requestTestPkey: (int) userpkey {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_test_pkey.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"pkey=%d&", userpkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                [self networkError]; //네트워크 실패 시 함수 호출
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_request_test_pkey: %@", content);
                //로컬에 데이터 저장후 로그 만들기
                [userDefaults setInteger:[content intValue] forKey:@"testPkey"];
                [self createLog:[content intValue]];
            }
            
        } ];
    [dataTask resume];
}


- (void) createLog: (int) testPkey {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_create_log.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"tpkey=%d&", testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                [self networkError]; //네트워크 실패 시 함수 호출
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_request_create_log: %@", content);
                //로컬에 testlogpkey데이터 저장후 함수호출
                [userDefaults setInteger:[content intValue] forKey:@"testLogPkey"];
                [self requestCount:testPkey];
                
                
            }
            
        } ];
    [dataTask resume];
}



- (void) requestCount: (int) testPkey {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_count_test.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"testPKey=%d&", testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                [self networkError]; //네트워크 실패 시 함수 호출
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_request_count_test전체차수: %@", content);
                //여기에 넣어야 딜레이 안생김 전체차수count받아와야하기때문에
                [self requestCurrentProgress:testPkey];
                
                count = [content intValue];
                int day = (count/3 + 1); //일자 값
                int round = count%3; // 회차 값
                if (round == 0){
                    round += 3;
                    day -= 1;
                }
            
                switch (round) {
                    case 1:
                        self->_moonImage.hidden=NO;
                        break;
                    case 2:
                        self->_moonHalfImage.hidden=NO;
                        break;
                    case 3:
                        self->_moonFullImage.hidden=NO;
                        break;

                    default:
                        break;
                }
                
                self->_day.text = [NSString stringWithFormat:@"%d%@",day,@"일차"];
                self->_meeting.text = [NSString stringWithFormat:@"%@ %@" , [self roundKor:(round)], @"번째 만남"];
            
                roundText = [NSString stringWithFormat:@"%@ %@" , [self roundKor:(round+1)], @"번째 만남"]; //인사말에 쓰일것
            }
            
        } ];
    [dataTask resume];
}


- (NSString *) roundKor: (int) num {
    switch (num) {
        case 1:
            return @"첫";
            break;
            
        case 2:
            return @"두";
            break;
            
        case 3:
            return @"세";
            break;
            
        default:
            return @"?";
            break;
    }
}


- (void) requestCurrentProgress: (int)testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    int logpkey = (int)[userDefaults integerForKey:@"testLogPkey"];

    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_current_progress.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"pKey=%d&testPKey=%d", logpkey, testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                [self networkError]; //네트워크 실패 시 함수 호출
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_currentPROGRESS: %@", content);
                
                currentProgress = [content intValue];
                
                if(currentProgress==0) {//1번째 만남
                    //[self delete_button];
                    if(count>1){
                        [self setGreetingStyle:@"또 만나서 반가워요!\n물 한잔 마시고 시작해보는 건 어때요?"];
                }
                }
            }
        NSLog(@"카운트: %d", count);
        //button
        
       
      
        if(groupType == 0){
            switch (count) {
                case 1:
                    arrBtn[0] = self->_btnappr;
                    arrBtn[1] = self->_btnorientation;
                    arrBtn[2] = self->_btnlog;
                    arrBtn[3] = self->_btncheck;
                    arrBtn[4] = self->_btnfinish;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 4){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    break;
                    
                case 2:
                    arrBtn[0] = self->_btnlog;
                    arrBtn[1] = self->_btngoal;
                    arrBtn[2] = self->_btnVideo;
                    arrBtn[3] = self->_btncheck;
                    arrBtn[4] = self->_btnfinish;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    
                    if(currentProgress >= 4){
                        [self doneTestLog:logpkey :testPkey];
                    }
       
                    
                    break;
                    
                    
                case 3:
                    arrBtn[0] = self->_btnlog;
                    arrBtn[1] = self->_btnself;
                    arrBtn[2] = self->_btnedu;
                    arrBtn[3] = self->_btnmind;
                    arrBtn[4] = self->_btncheck;
                    arrBtn[5] = self->_btnfinish;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 5){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    break;
                    
                    
                case 4:
                    arrBtn[0] = self->_btnlog;
                    arrBtn[1] = self->_btnot;
                    arrBtn[2] = self->_btntraincbm;
                    arrBtn[3] = self->_btncheck;
                    arrBtn[4]=self->_btnfinish;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 4){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    break;
                    
                default:
                    break;
            }
            
            if (count>4) {
                if(count > 41){ //14일차 3차이상시
                    self->_realScrollview.hidden = YES;
                    self->_day.text = [NSString stringWithFormat:@""];
                    self->_meeting.text = [NSString stringWithFormat:@"모든 회차가"];
                    self->_greeting.text = [NSString stringWithFormat:@"완료되었습니다"];
                }else{
                    arrBtn[0] = self->_btnlog;
                    arrBtn[1] = self->_btnrelax;
                    arrBtn[2] = self->_btntraincbm;
                    arrBtn[3] = self->_btncheck;
                    arrBtn[4] = self->_btnfinish;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 4){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    
                }
                
            }
           
            [self setButtonPos];
        }else if(groupType == 1){ //그룹타입b
            switch (count) {
                case 1:
                    arrBtn[0] = self->_btnappr;
                    arrBtn[1] = self->_btncheck;
                    arrBtn[2] = self->_btnfinish;
                    arrBtn[3] = NULL;
                    arrBtn[4] = NULL;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 2){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    break;
                    
                case 2:
                    arrBtn[0] = self->_btngoal;
                    arrBtn[1] = self->_btncheck;
                    arrBtn[2] = self->_btnfinish;
                    arrBtn[3] = NULL;
                    arrBtn[4] = NULL;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    
                    if(currentProgress >= 2){
                        [self doneTestLog:logpkey :testPkey];
                    }
       
                    
                    break;
                    
                    
                case 3:
                    arrBtn[0] = self->_btnself;
                    arrBtn[1] = self->_btnedu;
                    arrBtn[2] = self->_btnmind;
                    arrBtn[3] = self->_btncheck;
                    arrBtn[4] = self->_btnfinish;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 4){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    break;

                default:
                    break;
            }
            
            if (count>3) {
                if(count > 41){ //14일차 3차이상시
                    self->_realScrollview.hidden = YES;
                    self->_day.text = [NSString stringWithFormat:@""];
                    self->_meeting.text = [NSString stringWithFormat:@"모든 회차가"];
                    self->_greeting.text = [NSString stringWithFormat:@"완료되었습니다"];
                }else{
                    arrBtn[0] = self->_btntraincbm;
                    arrBtn[1] = self->_btncheck;
                    arrBtn[2] = self->_btnfinish;
                    arrBtn[3] = NULL;
                    arrBtn[4] = NULL;
                    arrBtn[5] = NULL;
                    [self visible_button];
                    [self disable_button];
                    [self enable_button];
                    if(currentProgress >= 2){
                        [self doneTestLog:logpkey :testPkey];
                    }
                    
                }
                
            }
           
            [self setButtonPos];
            
        }
      
        } ];
    [dataTask resume];
}


- (void) doneTestLog: (int) testLogPkey :(int) testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_test_log.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey, testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                [self networkError]; //네트워크 실패 시 함수 호출
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                //NSLog(@"donetest: %@", content);
                if ([roundText isEqual: @"? 번째 만남"]){
                    [self setGreetingStyle:@"오늘도 수고하셨어요☺️😉 내일 봐요!"];
                }else{
                    //NSLog(@"curprogress%d", currentProgress);
                    if (groupType == 0){
                        if(count >= 41){
                        if (currentProgress == 4){
                            [self setGreetingStyle:[NSString stringWithFormat:@"%@", @"모든 회차가 완료되었습니다"]];
                        }}else{
                            [self setGreetingStyle:[NSString stringWithFormat:@"%@%@", roundText, @"에서 만나요☺️😉"]];
                        }
                    }else if (groupType == 1){
                        if(count>=41){
                            if (currentProgress ==2){
                                [self setGreetingStyle:[NSString stringWithFormat:@"%@", @"모든 회차가 완료되었습니다"]];
                            }
                        }else{
                            [self setGreetingStyle:[NSString stringWithFormat:@"%@%@", roundText, @"에서 만나요☺️😉"]];
                        }
                    }
                    
                        
                }
            
                    
            }
            
        } ];
    [dataTask resume];
}




- (void) disable_button{
    for (int i=0; i<6; i++) {
        if(arrBtn[i] != NULL){
            arrBtn[i].enabled = NO;
        }
    }
}
 - (void) delete_button{
     for (int i=0; i<6; i++) {
         if(arrBtn[i] != NULL){
             arrBtn[i].hidden = YES;
             arrBtn[i]=NULL;
         }
     }
 }

- (void) enable_button{
    for (int i=0; i<6; i++) {
        if(arrBtn[i] != NULL){
            lastItemIndex = i;
        }
    }
    
    if(currentProgress<=lastItemIndex){
        arrBtn[currentProgress].enabled = YES;
        //arrbtn 으로 키값 dictionary 로 찾기
        //NSLog(@"도대체무엇   %@", arrBtn[currentProgress].titleLabel.text);
        NSString *imageName = [dict objectForKey:arrBtn[currentProgress].titleLabel.text];
        [self setBtnEnabled:arrBtn[currentProgress] :imageName];
    }
    else{
        arrBtn[lastItemIndex].enabled = YES;
        NSString *imageName = [dict objectForKey:arrBtn[lastItemIndex].titleLabel.text];
        [self setBtnEnabled:arrBtn[lastItemIndex] :imageName];
    }
}

- (void) visible_button{
    for (int i=0; i<6; i++) {
        if(arrBtn[i] != NULL){
            arrBtn[i].hidden = NO;
        }
    }
}


-(float)calResolution:(float) num{
    return screenWidth*(num/320);
}

-(void)setDisableButton{
    //menu btn
    _btnappr.hidden=YES;
    _btnorientation.hidden=YES;
    _btnlog.hidden=YES;
    _btngoal.hidden=YES;
    _btnVideo.hidden=YES;
    _btnot.hidden = YES;
    _btnedu.hidden=YES;
    _btntraincbm.hidden=YES;
    _btnmind.hidden=YES;
    _btnrelax.hidden=YES;
    _btnfinish.hidden=YES;
    _btnself.hidden=YES;
    _btncheck.hidden=YES;
}

-(void)setHiddenMoon{
    _moonImage.hidden=YES;
    _moonHalfImage.hidden=YES;
    _moonFullImage.hidden=YES;
}


//menu button pos
-(void)setButtonPos{
    NSLog(@"버튼가로%f",arrBtn[0].frame.size.width);
    CGFloat btnX = ((_scrollView.frame.size.width/2)-(arrBtn[0].frame.size.width/2));
    [arrBtn[0] setFrame:CGRectMake(btnX, 0, arrBtn[0].frame.size.width, arrBtn[0].frame.size.height)];
    [arrBtn[1] setFrame:CGRectMake(btnX, arrBtn[0].frame.origin.y+arrBtn[0].frame.size.height+[self calResolution:buttonGap], arrBtn[1].frame.size.width, arrBtn[1].frame.size.height)];
    [arrBtn[2] setFrame:CGRectMake(btnX, arrBtn[1].frame.origin.y+arrBtn[1].frame.size.height+[self calResolution:buttonGap], arrBtn[2].frame.size.width, arrBtn[2].frame.size.height)];
    [arrBtn[3] setFrame:CGRectMake(btnX, arrBtn[2].frame.origin.y+arrBtn[2].frame.size.height+[self calResolution:buttonGap], arrBtn[3].frame.size.width, arrBtn[3].frame.size.height)];
    [arrBtn[4] setFrame:CGRectMake(btnX, arrBtn[3].frame.origin.y+arrBtn[3].frame.size.height+[self calResolution:buttonGap], arrBtn[4].frame.size.width, arrBtn[4].frame.size.height)];
    if(arrBtn[5] != NULL){
        [arrBtn[5] setFrame:CGRectMake(btnX, arrBtn[4].frame.origin.y+arrBtn[4].frame.size.height+[self calResolution:buttonGap], arrBtn[5].frame.size.width, arrBtn[5].frame.size.height)];
    }
    
    [self setScrollHeight];
    
}

-(void) setScrollHeight { //동적으로 스크롤뷰 height 지정하기
    CGRect scrollframe = _scrollView.frame;
  
    float margin = screenHeight*90/480; //320*480기준 margin으로 계산
    NSLog(@"마진 %f", margin);
    if(arrBtn[5] != NULL){
        
        [_realScrollview setContentSize:(CGSizeMake(scrollframe.size.width, arrBtn[5].frame.origin.y+margin))];
     
        
    }else if (arrBtn[4] != NULL){
        [_realScrollview setContentSize:(CGSizeMake(scrollframe.size.width, arrBtn[4].frame.origin.y+ margin))];
    }else if (arrBtn[3] != NULL){
        [_realScrollview setContentSize:(CGSizeMake(scrollframe.size.width, arrBtn[3].frame.origin.y+ margin))];
    }else{
        [_realScrollview setContentSize:(CGSizeMake(scrollframe.size.width, arrBtn[2].frame.origin.y+ margin))];
    }
}




-(void) makeBottomNav{ // 해상도따라 하단 바 생성
    //하단바 이미지
    CGRect currentFrame = _bottomImage.frame;
   
    //bottom image
    float imageWidth = screenWidth*currentFrame.size.width/320;
    float imageHeight = screenHeight*currentFrame.size.height/480;
   
    _bottomImage.frame = CGRectMake(0, screenHeight-imageHeight, imageWidth, imageHeight);

    [_bottomImage setUserInteractionEnabled:false];
    
    //setting btn
    float settingRight = screenWidth*17/320;
    float settingBottom = screenHeight*12/480;
    float settingSize = screenWidth*24.5/320;

    [_settingBtn setFrame:CGRectMake(screenWidth-settingRight-settingSize, screenHeight-settingBottom-settingSize, settingSize, settingSize)];
 
}

-(void)setBtnBack{
    _btnappr.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"approach_btn_off.png"]];
    _btnorientation.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"orientation_btn_off.png"]];
    _btnlog.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"log_btn_off.png"]];
    _btngoal.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"goal_btn_off.png"]];
    _btnVideo.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"relaxvideo_btn_off.png"]];
    _btnedu.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"educbm_btn_off.png"]];
    _btntraincbm.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"cbm_btn_off.png"]];
    _btnmind.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"mind_btn_off.png"]];
    _btnrelax.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"relax_btn_off.png"]];
    _btnfinish.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"rest_btn_off.png"]];
    _btnself.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"selfinjury_btn_off.png"]];
    _btncheck.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"check_btn_off.png"]];
    _btnot.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"relaxot_btn_off.png"]];
}

//문자열과 줄간격 조정하는 함수 greeting msg
- (void) setGreetingStyle: (NSString*) string {
    NSMutableParagraphStyle *style  = [[NSMutableParagraphStyle alloc] init];
    style.minimumLineHeight = 15.f;
    style.maximumLineHeight = 15.f;
    style.alignment = NSTextAlignmentCenter;
    NSDictionary *attributtes = @{NSParagraphStyleAttributeName : style,};
    
    _greeting.attributedText = [[NSAttributedString alloc] initWithString:string attributes:attributtes];
    [_greeting sizeToFit];
    
}

//change enabled button's image
- (void) setBtnEnabled: (UIButton*) btnName : (NSString*) imageName{
    [self setBtnBack]; // btn offimage
    [btnName setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:imageName]]];
}

//해쉬맵 btnname - imagename (btnon)
- (void) makeDictionary {
    dict = [NSDictionary dictionaryWithObjectsAndKeys: @"approach_btn_on.png",@"다가서기",  @"orientation_btn_on.png",@"치료오리엔테이션", @"log_btn_on.png",@"기분일기", @"goal_btn_on.png", @"목표세우기", @"relaxvideo_btn_on.png", @"이완훈련교육",  @"educbm_btn_on.png", @"cbm교육",   @"cbm_btn_on.png",@"cbm", @"mind_btn_on.png", @"심상교육", @"relax_btn_on.png",@"이완훈련",  @"rest_btn_on.png",@"쉬어가기", @"selfinjury_btn_on.png", @"자해심리치료",  @"check_btn_on.png",@"컨디션체크",@"relaxot_btn_on.png",@"이완훈련ot", nil];
}

//쉬어가기
- (IBAction)rest:(id)sender {
 
    NSString* message =[NSString stringWithFormat:@"%@ %@이 종료되었습니다.", _day.text,_meeting.text];
    //timer 3초정도 맞춰서 toast n일 n차 종료 출력하고 finish
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:nil
                                                                      message:@""
                                                               preferredStyle:UIAlertControllerStyleAlert];
        UIView *firstSubview = alert.view.subviews.firstObject;
        UIView *alertContentView = firstSubview.subviews.firstObject;
        for (UIView *subSubView in alertContentView.subviews) {
            subSubView.backgroundColor = [UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1.0f];
        }
        NSMutableAttributedString *AS = [[NSMutableAttributedString alloc] initWithString:message];
        [AS addAttribute: NSForegroundColorAttributeName value: [UIColor whiteColor] range: NSMakeRange(0,AS.length)];
        [alert setValue:AS forKey:@"attributedTitle"];
        [self presentViewController:alert animated:YES completion:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [alert dismissViewControllerAnimated:YES completion:^{
            }];
        });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        exit(0);
    });
    
    //[self performSelector:@selector(dismissViewControllerAnimated:YES completion:nil) withObject:nil afterDelay:3.0];
  
}
//네트워크 에러시 호출하는 함수
-(void)networkError{
    //버튼 상태를 unenbled해주기
    [self disable_button];
    self->_settingBtn.enabled = NO;
    NSString* message =@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요.";
    //timer 3초정도 맞춰서 toast하여 네트워크 연결 실패함을 알린다.
    UIAlertController * alert=[UIAlertController alertControllerWithTitle:nil
                                                                      message:@""
                                                               preferredStyle:UIAlertControllerStyleAlert];
        UIView *firstSubview = alert.view.subviews.firstObject;
        UIView *alertContentView = firstSubview.subviews.firstObject;
        for (UIView *subSubView in alertContentView.subviews) {
            subSubView.backgroundColor = [UIColor colorWithRed:50/255.0f green:50/255.0f blue:50/255.0f alpha:1.0f];
        }
        NSMutableAttributedString *AS = [[NSMutableAttributedString alloc] initWithString:message];
        [AS addAttribute: NSForegroundColorAttributeName value: [UIColor whiteColor] range: NSMakeRange(0,AS.length)];
        [alert setValue:AS forKey:@"attributedTitle"];
        [self presentViewController:alert animated:YES completion:nil];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [alert dismissViewControllerAnimated:YES completion:^{
            }];
        });
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        exit(0);
    });
}

@end
