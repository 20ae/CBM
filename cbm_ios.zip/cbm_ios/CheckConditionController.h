//
//  CheckConditionController.h
//  cbm_ios
//
//  Created by DS on 2022/02/14.
//

#import <UIKit/UIKit.h>
#import "OurSlider.h"

NS_ASSUME_NONNULL_BEGIN

@interface CheckConditionController : UIViewController <NSURLSessionDataDelegate>

@end

NS_ASSUME_NONNULL_END
