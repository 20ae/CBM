//
//  UIView+OurSlider.h
//  cbm_ios
//
//  Created by mac12 on 2022/02/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@class OurSlider;

@interface OurSlider : UIView
{
    
}
-(void)setView:(int)red green:(int)green blue:(int)blue;
-(void)setPoint:(int)startNum endNum: (int)endNum textArray:(NSArray *) textArray titleNameType:(int)type;
-(NSMutableArray*)getView;
-(void)hiddenThumb;
@end

NS_ASSUME_NONNULL_END
