//
//  FinishController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "FinishController.h"

@interface FinishController ()

@end

@implementation FinishController

NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수

- (void)viewDidLoad {
    [super viewDidLoad];
    // 배경 이미지를 화면 크기에 맞게 변경
    UIImage *image = [UIImage imageNamed:@"back_green.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    // 변수 초기화
    userDefaults = [NSUserDefaults standardUserDefaults];
    
    // 두번째 레이블과 버튼 숨김 처리
    _finishLabel2.hidden = YES;
    _finishNextBtn.hidden = YES;
    _finishNextBtn_Back.hidden = YES;
    
    [self performSelector:@selector(visibleLabel:) withObject:_finishLabel2 afterDelay:2.0];
    [self performSelector:@selector(visibleBtn:) withObject:_finishNextBtn afterDelay:4.0];
    [self performSelector:@selector(visibleBtnBack:) withObject:_finishNextBtn_Back afterDelay:4.0];
}

- (IBAction)touchNextBtn:(UIButton *)sender {
        //[self updateCurrentProgress]; // 마무리가 끝났으므로 currentprogress 1 증가시키기
        //[self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
    [self.navigationController popToRootViewControllerAnimated:YES];
}

// 호출하면 레이블을 띄워주는 함수
-(void)visibleLabel:(UILabel *)label
{
    label.hidden = NO;
}

// 호출하면 버튼을 띄워주는 함수
-(void)visibleBtn:(UIButton *)button
{
    button.hidden = NO;
}

// 호출하면 버튼 배경을 띄워주는 함수
-(void)visibleBtnBack:(UIImageView *)image
{
    image.hidden = NO;
}

/*
// 마무리가 끝났음을 알리기 위해 DB의 currentProgress를 1 증가시키는 함수
- (void) updateCurrentProgress{
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey, testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
            }
        
    } ];
    [dataTask resume];
    //증가시키고 앱종료
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        exit(0);
        });
}
 */

@end
