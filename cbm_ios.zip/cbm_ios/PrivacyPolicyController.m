//
//  PrivacyPolicyController.m
//  cbm_ios
//
//  Created by DS on 2022/04/29.
//

#import "PrivacyPolicyController.h"

@interface PrivacyPolicyController ()
@property (weak, nonatomic) IBOutlet WKWebView *privacyPolicyWebView;
@property (weak, nonatomic) IBOutlet UIButton *closeButton;

@end

@implementation PrivacyPolicyController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setPrivacyPolicy];
    
    UIImage *bgImage = [UIImage imageNamed:@"back_login.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
}

- (void)setPrivacyPolicy {
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://healingmindcenter.com/cbm_app/privacy_policy.php"]];
    [_privacyPolicyWebView setTranslatesAutoresizingMaskIntoConstraints:false];
    //[request setHTTPBody:bodyData];
    [_privacyPolicyWebView loadRequest:request];
}

//닫기 버튼 터치 시
- (IBAction)closePrivacyPolicy:(id)sender {
    [self dismissViewControllerAnimated:true completion:nil];
}

//스와이프 제스쳐 함수
- (void)handleSwipes:(UISwipeGestureRecognizer*)recognizer {
    if (recognizer.direction == UISwipeGestureRecognizerDirectionRight) {
        [self dismissViewControllerAnimated:true completion:nil];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
