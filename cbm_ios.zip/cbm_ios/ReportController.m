//
//  ReportController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "ReportController.h"


@interface ReportController (){
    NSUserDefaults* userDefaults;
    int userpkey;
    int groupType;
}

@property (weak, nonatomic) IBOutlet UIButton *backBtn;

@property (weak, nonatomic) IBOutlet UINavigationItem *backNav;
@property (weak, nonatomic) IBOutlet WKWebView *reportWebView;


@end

@implementation ReportController

- (IBAction)reportBackBtn:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //[_backBtn setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"report_image2"]]];
    
    userDefaults = [NSUserDefaults standardUserDefaults];
    userpkey = (int)[userDefaults integerForKey:@"UserPKey"];
    groupType = (int)[userDefaults integerForKey:@"GroupType"];
    [self setReport];
    
    UIImage *bgImage = [UIImage imageNamed:@"back_report.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
    

    // Do any additional setup after loading the view.
}

// WebView 생성
- (void)setReport {
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://healingmindcenter.com/cbm_app/cbm_api/cbm_graph.php"]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //&으로 분리되고, "=" 기호로 값과 키를 연결하는 key-value tuple로 인코딩되는 값(HTML Form형태)- ContentType으로 넘김
    
    NSString *body = [NSString stringWithFormat:@"user_id=%d&type=%d", userpkey, groupType];
    NSData *bodyData = [body dataUsingEncoding:NSUTF8StringEncoding];
    [_reportWebView setTranslatesAutoresizingMaskIntoConstraints:false];
    [request setHTTPBody:bodyData];
    [_reportWebView loadRequest:request];

    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
@end

