//
//  CustomerCenterController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "CustomerCenterController.h"

@interface CustomerCenterController ()
@property (weak, nonatomic) IBOutlet UITextView *contentView;
@property (weak, nonatomic) IBOutlet UIButton *customerCenterBack;


@end

@implementation CustomerCenterController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //배경
    UIImage *bgImage = [UIImage imageNamed:@"back_report.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
}

- (IBAction)customerCenterGoBack:(UIButton *)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

@end
