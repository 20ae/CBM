//
//  EduCBMController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "EduCBMController.h"

@interface EduCBMController ()
{
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    int testPkey;
    int testLogPkey;
    int count;
    
    int firstpg;
    int secondpg;
    int thirdpg;
    int fourthpg;
    int fifthpg;
    int seventhpg;
    
    int isDoingNetwork; //중복 터치 차단
}
//버튼관련
@property (weak, nonatomic) IBOutlet UIImageView *EduButBack;
@property (weak, nonatomic) IBOutlet UIButton *EduCBMBut;

//첫번째장면
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel2;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel3;

//두번째장면
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel4;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel5;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel6;

//세번째장면
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel7;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel8;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel9;

//네번째장면
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel10;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel11;

//다섯번째장면
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel12;
@property (weak, nonatomic) IBOutlet UIImageView *EduCBMImage;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel13;

//일곱번째장면
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel14;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel15;
@property (weak, nonatomic) IBOutlet UILabel *EduCBMLabel16;

@end



@implementation EduCBMController

- (void)viewDidLoad {
    [super viewDidLoad];
    isDoingNetwork = 0; //중복 터치 차단
    // Do any additional setup after loading the view.
    
    //TestPkey와 TestLogPkey
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_green.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼관련 설정
    self.EduCBMBut.hidden = YES;
    self.EduButBack.hidden = YES;
    [self.EduCBMBut setTitle:@"" forState:UIControlStateNormal];
    
    //앱 다시 활성활 때 호출하는 함수
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(apWillEnterForeground:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    
    //페이지 및 시간차 관련 변수
    count = 1;
    firstpg = 0;
    secondpg = 0;
    thirdpg = 0;
    fourthpg = 0;
    fifthpg = 0;
    seventhpg = 0;
    
    //각 페이지 관련 오브젝트 숨기기 및 영상 링크 가져오기
    //첫번째 장면
    {
        self.EduCBMLabel3.hidden = YES;
        NSString *text = @"인지편향수정 훈련은\nCBM이라고도 하는데,\n이는 Cognitive Bias Modification의\n줄임말이에요.";
        _EduCBMLabel3.text = text;
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:[_EduCBMLabel3 text]];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(0, 9)];
        NSString *research = @"CBM";
        NSUInteger result = [_EduCBMLabel3.text rangeOfString:research options:NSCaseInsensitiveSearch].location;
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(result, research.length)];
        NSString *research2 = @"Cognitive Bias Modification";
        NSUInteger result2 = [_EduCBMLabel3.text rangeOfString:research2 options:NSCaseInsensitiveSearch].location;
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(result2, research2.length)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont.length)];
        [_EduCBMLabel3 setAttributedText:textFont];
    }
    //두번째 장면
    {
        self.EduCBMLabel4.hidden = YES;
        self.EduCBMLabel5.hidden = YES;
        self.EduCBMLabel6.hidden = YES;
    }
    //세번째장면
    {
        self.EduCBMLabel7.hidden = YES;
        self.EduCBMLabel8.hidden = YES;
        NSString *name = [userDefaults objectForKey:@"UserName"] != nil ? [userDefaults objectForKey:@"UserName"]:@"userName";
        NSString *modifyName = name.length > 1 ? [name substringWithRange:NSMakeRange(1,name.length-1)] : name;
        NSString *modifyName_trim =[modifyName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSString *modifyLabel = [@"이것이 바로 이 훈련에서\n" stringByAppendingString:modifyName_trim];
        modifyLabel = [modifyLabel stringByAppendingString:@"님이 해 주실 일이에요."];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        NSMutableAttributedString *modifyLabel2 = [[NSMutableAttributedString alloc] initWithString:modifyLabel];
        [modifyLabel2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel2.length)];
        [self.EduCBMLabel9 setAttributedText:modifyLabel2];
        self.EduCBMLabel9.hidden = YES;
    }
    //네번째장면
    {
        self.EduCBMLabel10.hidden = YES;
        self.EduCBMLabel11.hidden = YES;
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:[_EduCBMLabel11 text]];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(90, 57)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont.length)];
        [_EduCBMLabel11 setAttributedText:textFont];
    }
    //다섯번째장면
    {
        self.EduCBMLabel12.hidden = YES;
        self.EduCBMImage.hidden = YES;
        self.EduCBMLabel13.hidden = YES;
    }
    //여섯번째장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_cbm/1.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay:) name:AVPlayerItemPlaybackStalledNotification object:[player currentItem]];
    }
    //일곱번째장면
    {
        self.EduCBMLabel14.hidden = YES;
        self.EduCBMLabel15.hidden = YES;
        self.EduCBMLabel16.hidden = YES;
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:[_EduCBMLabel14 text]];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(0, 10)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont.length)];
        [_EduCBMLabel14 setAttributedText:textFont];
    }
    
    //첫번째페이지 시간차 변수 및 함수호출
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(EduCBM1pageNext:) userInfo:NO repeats:YES];
}

//시간차 관련 함수
-(void)EduCBM1pageNext:(NSTimer*)timer{
    firstpg++;
    if(firstpg == 1){
        self.EduCBMLabel3.hidden = NO;
    }
    else{
        self.EduCBMBut.hidden = NO;
        self.EduButBack.hidden = NO;
    }
    
    if(firstpg >=2){
        //timer loop 종료
        [timer invalidate];
    }
    
}
-(void)EduCBM2pageNext:(NSTimer*)timer{
    secondpg++;
    if(secondpg==1){
        self.EduCBMLabel6.hidden = NO;
    }
    else{
        self.EduCBMBut.hidden = NO;
        self.EduButBack.hidden = NO;
    }
    
    if(secondpg>=2){
        [timer invalidate];
    }
}
-(void)EduCBM3pageNext:(NSTimer*)timer{
    thirdpg++;
    if(thirdpg == 1){
        self.EduCBMLabel8.hidden = NO;
    }
    else if(thirdpg == 2){
        self.EduCBMLabel9.hidden = NO;
    }
    else{
        self.EduCBMBut.hidden = NO;
        self.EduButBack.hidden = NO;
    }
    
    if(thirdpg>=3){
        [timer invalidate];
    }
}
-(void)EduCBM4pageNext:(NSTimer*)timer{
    fourthpg++;
    if(fourthpg == 1){
        self.EduCBMLabel11.hidden = NO;
    }
    else{
        self.EduCBMBut.hidden = NO;
        self.EduButBack.hidden = NO;
    }
    
    if(fourthpg>=2){
        [timer invalidate];
    }
    
}
-(void)EduCBM5pageNext:(NSTimer*)timer{
    fifthpg++;
    if(fifthpg == 1){
        self.EduCBMLabel13.hidden = NO;
    }
    else{
        self.EduCBMBut.hidden = NO;
        self.EduButBack.hidden = NO;
    }
    
    if(fifthpg>=2){
        [timer invalidate];
    }
}
-(void)EduCBM7pageNext:(NSTimer*)timer{
    seventhpg++;
    if(seventhpg==1){
        self.EduCBMLabel15.hidden = NO;
    }
    else if(seventhpg==2){
        self.EduCBMLabel16.hidden = NO;
    }
    else{
        self.EduCBMBut.hidden = NO;
        self.EduButBack.hidden = NO;
    }
    
    if(seventhpg>=3){
        [timer invalidate];
    }
}
//동영상 중단 시 호출되는 함수
- (void)replay:(NSNotification *)notification{
    [player play];
    NSLog(@"pause video replay");
}

//영상 끝날 때 호출 되는 함수
- (void)playerItemDidReachEnd:(NSNotification *)notification {
    NSLog(@"Ending");
    
   
    self.EduCBMBut.hidden = NO;
    self.EduButBack.hidden = NO;
    
}


//버튼 클릭 시 호출되는 함수
- (IBAction)ActionBut:(id)sender {
    switch (count) {
        case 1:
            {
                count++;
                self.EduCBMLabel.hidden = YES;
                self.EduCBMLabel2.hidden = YES;
                self.EduCBMLabel3.hidden = YES;
                self.EduButBack.hidden = YES;
                self.EduCBMBut.hidden = YES;
                
                self.EduCBMLabel4.hidden = NO;
                self.EduCBMLabel5.hidden = NO;
                //두번째 페이지 시간차 변수및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(EduCBM2pageNext:) userInfo:NO repeats:YES];
            }
            break;
        case 2:
            {
                count++;
                self.EduCBMLabel4.hidden = YES;
                self.EduCBMLabel5.hidden = YES;
                self.EduCBMLabel6.hidden = YES;
                self.EduButBack.hidden = YES;
                self.EduCBMBut.hidden = YES;
                
                self.EduCBMLabel7.hidden = NO;
                //세번째 페이지 시간차 변수및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(EduCBM3pageNext:) userInfo:NO repeats:YES];
            }
            break;
        case 3:
            {
                count++;
                self.EduCBMLabel7.hidden = YES;
                self.EduCBMLabel8.hidden = YES;
                self.EduCBMLabel9.hidden = YES;
                self.EduButBack.hidden = YES;
                self.EduCBMBut.hidden = YES;
                
                self.EduCBMLabel10.hidden = NO;
                //네번째 페이지 시간차 변수 및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(EduCBM4pageNext:) userInfo:NO repeats:YES];
            }
            break;
        case 4:
            {
                count++;
                self.EduCBMLabel10.hidden = YES;
                self.EduCBMLabel11.hidden = YES;
                self.EduButBack.hidden = YES;
                self.EduCBMBut.hidden = YES;
                
                self.EduCBMLabel12.hidden = NO;
                self.EduCBMImage.hidden = NO;
                //다섯번째 페이지 시간차 변수 및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(EduCBM5pageNext:) userInfo:NO repeats:YES];
                
            }
            break;
        case 5:
            {
                count++;
                self.EduCBMLabel12.hidden = YES;
                self.EduCBMImage.hidden = YES;
                self.EduCBMLabel13.hidden = YES;
                self.EduButBack.hidden = YES;
                self.EduCBMBut.hidden = YES;
                
                [player play];
                    
                playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
                playerLayer.frame = self.view.bounds;
                float x = 0;
                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                float width = playerLayer.frame.size.width;
                float height = playerLayer.frame.size.height;
                CGRect resizeRect = CGRectMake(x, y, width, height);
                [playerLayer setFrame:resizeRect];
                [self.view.layer addSublayer:playerLayer];
            }
            break;
        case 6:
            {
                playerLayer.hidden = YES;
                self.EduButBack.hidden = YES;
                self.EduCBMBut.hidden = YES;
                count++;
                self.EduCBMLabel14.hidden = NO;
                //일곱번째 페이지 시간차 변수및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(EduCBM7pageNext:) userInfo:NO repeats:YES];
            }
            break;
        default:
            if(isDoingNetwork==0)
                [self updateDoneSection:testLogPkey :testPkey];
                //[self.navigationController popViewControllerAnimated:YES];
                break;
    }
}

//section update 관련 함수
- (void) updateDoneSection: (int) testLogPkey : (int) testPkey{
    isDoingNetwork = 1;
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이다.
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey,testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                isDoingNetwork = 0;
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
}
//홈버튼 누르고 다시 앱이 활성화 할 때 호출되는 함수
- (void)apWillEnterForeground: (NSNotification *)notification{
    NSLog(@"확인");
    if(count == 6){
        if(player.timeControlStatus == AVPlayerTimeControlStatusPaused){
            [player play];
        }
    }
}
@end
