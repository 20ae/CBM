//
//  SettingController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "SettingController.h"

@interface SettingController ()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIButton *homeBack;
@property (weak, nonatomic) IBOutlet UIButton *report;
@property (weak, nonatomic) IBOutlet UIButton *customercenter;
@property (weak, nonatomic) IBOutlet UIButton *qna;
@property (weak, nonatomic) IBOutlet UIImageView *reportIcon;
@property (weak, nonatomic) IBOutlet UIImageView *customercenterIcon;
@property (weak, nonatomic) IBOutlet UIImageView *qnaIcon;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *qnatopconstraint;


@end
NSUserDefaults* userDefaults;
NSString *userFullname;
NSString *userName;
int groupType; //훈련집단이랑 비교집단이랑 영상 다름


@implementation SettingController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.navigationController.navigationBar.hidden=YES;
    UIImage *bgImage = [UIImage imageNamed:@"back_setting.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
    
    _homeBack.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"home_btn.png"]];
    
    //데이터를 가져오는 방법
    userDefaults = [NSUserDefaults standardUserDefaults];
    groupType = (int)[userDefaults integerForKey:@"GroupType"];
    userFullname =[userDefaults objectForKey:@"UserName"];
    
    [self getName];
    _nameLabel.text = [NSString stringWithFormat:@"%@ 님", userName];
    
    if(groupType == 1){
        _report.hidden = YES;
        _reportIcon.hidden = YES;
        
        _qnatopconstraint.constant = 44;
    }
 
}

-(void) getName{
    // 이름이 2글자 이상일 경우에만 성 제거
    if([userFullname length] >= 2){
        userName = [userFullname substringFromIndex : 1];
    } else if([userFullname length] == 1){
        userName = userFullname;
    } else {
        userName = @"user";
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
