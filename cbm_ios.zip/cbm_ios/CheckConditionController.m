//
//  CheckConditionController.m
//  cbm_ios
//
//  Created by DS on 2022/02/14.
//

#import "CheckConditionController.h"
#import "FinishController.h"

@interface CheckConditionController (){
    int isDoingNetwork; //중복 터치 차단
    NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수
    bool isChecking;
    bool isChecking2;
    NSInteger pagenext;
    NSInteger pageNumber;
    NSArray* _radioButtonsArray1_1;
    NSArray* _radioButtonsArray1_2;
    NSArray* _radioButtonsArray2;
    NSArray* _radioButtonsArray3;
    NSInteger testLogPkey;
    NSInteger testPkey;
    NSInteger value;
    NSInteger value2;
    OurSlider* slider;
    NSArray *textArray;
    int currentcount; //차수를 받아오는 변수
    int Progress;
}
@property (weak, nonatomic) IBOutlet UILabel *conditionOrientationText1;
@property (weak, nonatomic) IBOutlet UILabel *conditionOrientationText2;
@property (weak, nonatomic) IBOutlet UIImageView *conditionOrientationImage;
@property (weak, nonatomic) IBOutlet UIImageView *nextButtonBack;
@property (weak, nonatomic) IBOutlet UIButton *NextButton;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText1;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet1_1_1;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet1_1_2;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet1_2_1;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet1_2_2;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText1_1;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText1_2;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText1_3;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText1_4;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText2;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet2_1;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet2_2;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText2_1;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText2_2;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText3;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText3_1;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText3_2;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText3_3;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText3_4;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet3_1;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet3_2;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet3_3;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet3_4;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4_1;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4_2;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4_3;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4_4;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4_5;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText4_6;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet4_1;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet4_2;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet4_3;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet4_4;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet4_5;
@property (weak, nonatomic) IBOutlet UIButton *checkConditionButtonSet4_6;
@property (weak, nonatomic) IBOutlet UITextView *checkConditionTextView4;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText5;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText6;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText7;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText8;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText9;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText10;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText11;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText12;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText13;
@property (weak, nonatomic) IBOutlet UILabel *checkConditionText14;

@end

@implementation CheckConditionController

- (void)viewDidLoad {
    [super viewDidLoad];
    //변수 초기화
    isDoingNetwork = 0;
    isChecking = false;
    isChecking2 = false;
    pagenext  = 0;
    pageNumber = 1;
    userDefaults = [NSUserDefaults standardUserDefaults];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    value = 0;
    value2 = 0;
    currentcount = 0;
    Progress = 0;
    
    [self requestCount:testPkey];
    
    //슬라이더 생성
    //slider관련 action함수는 touchesBegan CGRectMake은 x,y,width,height이며 width와 height,x 고정하고 y축으로 위치 잡기
    slider = [[OurSlider alloc] initWithFrame:CGRectMake(0, UIScreen.mainScreen.bounds.size.height*0.45, UIScreen.mainScreen.bounds.size.width, 100)];
    //example hax ffdbfc -> red: 0xff green: 0xdb blue: 0xfc
    [slider setView:0x64 green:0xdc blue:0x63];
    //slider값 사용시 slider.tag로 하면 된다.
    [self.view addSubview:slider];
    //slider밑에 라벨할 글 array하기
    textArray=[NSArray arrayWithObjects:@"전혀\n우울하지\n않음",@"",@"약간\n우울한",@"",@"어느 정도\n우울한",@"",@"꽤\n우울한",@"",@"매우\n우울한",nil];
    //textArray에 값을 넣고 titleNameType지정하기(titleNameType - 0:textArray가 slider 아래 1:textArray가 slider 위)
    [slider setPoint:1 endNum:9 textArray:textArray titleNameType:0];
    
    //처음에 나오는 것만 빼고 숨기기
    //1페이지
    _conditionOrientationText1.hidden = NO;
    _conditionOrientationImage.hidden = YES;
    _conditionOrientationText2.hidden = YES;
    
    //2페이지
    _checkConditionText1.hidden = YES;
    _checkConditionButtonSet1_1_1.hidden = YES;
    _checkConditionButtonSet1_1_2.hidden = YES;
    _checkConditionButtonSet1_2_1.hidden = YES;
    _checkConditionButtonSet1_2_2.hidden = YES;
    _checkConditionText1_1.hidden = YES;
    _checkConditionText1_2.hidden = YES;
    _checkConditionText1_3.hidden = YES;
    _checkConditionText1_4.hidden = YES;
    
    //3페이지
    _checkConditionText2.hidden = YES;
    _checkConditionButtonSet2_1.hidden = YES;
    _checkConditionButtonSet2_2.hidden = YES;
    _checkConditionText2_1.hidden = YES;
    _checkConditionText2_2.hidden = YES;
    
    //4페이지
    _checkConditionText3.hidden = YES;
    _checkConditionButtonSet3_1.hidden = YES;
    _checkConditionButtonSet3_2.hidden = YES;
    _checkConditionButtonSet3_3.hidden = YES;
    _checkConditionButtonSet3_4.hidden = YES;
    _checkConditionText3_1.hidden = YES;
    _checkConditionText3_2.hidden = YES;
    _checkConditionText3_3.hidden = YES;
    _checkConditionText3_4.hidden = YES;
    
    //5페이지
    _checkConditionText4.hidden = YES;
    _checkConditionButtonSet4_1.hidden = YES;
    _checkConditionButtonSet4_2.hidden = YES;
    _checkConditionButtonSet4_3.hidden = YES;
    _checkConditionButtonSet4_4.hidden = YES;
    _checkConditionButtonSet4_5.hidden = YES;
    _checkConditionButtonSet4_6.hidden = YES;
    _checkConditionText4_1.hidden = YES;
    _checkConditionText4_2.hidden = YES;
    _checkConditionText4_3.hidden = YES;
    _checkConditionText4_4.hidden = YES;
    _checkConditionText4_5.hidden = YES;
    _checkConditionText4_6.hidden = YES;
    _checkConditionTextView4.hidden = YES;
    
    //6페이지
    slider.hidden = YES;
    _checkConditionText5.hidden = YES;
    //7페이지
    _checkConditionText6.hidden = YES;
    //8페이지
    _checkConditionText7.hidden = YES;
    //9페이지
    _checkConditionText8.hidden = YES;
    //10페이지
    _checkConditionText9.hidden = YES;
    //11페이지
    _checkConditionText10.hidden = YES;
    //12페이지
    _checkConditionText11.hidden = YES;
    //13페이지
    _checkConditionText12.hidden = YES;
    //14페이지
    _checkConditionText13.hidden = YES;
    //15페이지
    _checkConditionText14.hidden = YES;
    
    
    _nextButtonBack.hidden =YES;
    _NextButton.hidden = YES;
    
    
    
    //라디오 버튼 지정
    _radioButtonsArray1_1 = [[NSArray alloc] initWithObjects:_checkConditionButtonSet1_1_2,_checkConditionButtonSet1_1_1,nil]; //'예'가 1 '아니요'가 0의 값을 가지도록 함
    _radioButtonsArray1_2 = [[NSArray alloc] initWithObjects:_checkConditionButtonSet1_2_2,_checkConditionButtonSet1_2_1,nil];
    _radioButtonsArray2 = [[NSArray alloc] initWithObjects:_checkConditionButtonSet2_2,_checkConditionButtonSet2_1,nil];
    _radioButtonsArray3 = [[NSArray alloc] initWithObjects:_checkConditionButtonSet3_1,_checkConditionButtonSet3_2,_checkConditionButtonSet3_3,_checkConditionButtonSet3_4,nil];
    
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_green.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
         
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
         
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼 이미지 깨질 시에 버튼에 자동으로 설정되는 타이틀을 공백으로 만들어서 이미지 보이게 함
    [_NextButton setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet1_1_1 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet1_1_2 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet1_2_1 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet1_2_2 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet2_1 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet2_2 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet3_1 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet3_2 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet3_3 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet3_4 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet4_1 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet4_2 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet4_3 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet4_4 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet4_5 setTitle:@"" forState:UIControlStateNormal];
    [_checkConditionButtonSet4_6 setTitle:@"" forState:UIControlStateNormal];
    
    //버튼 이미지 설정(선택시 변화하도록)
    [_checkConditionButtonSet1_1_1 setImage: [UIImage imageNamed:@"checkbox15.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet1_1_2 setImage: [UIImage imageNamed:@"checkbox15.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet1_2_1 setImage: [UIImage imageNamed:@"checkbox15.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet1_2_2 setImage: [UIImage imageNamed:@"checkbox15.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet2_1 setImage: [UIImage imageNamed:@"checkbox15.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet2_2 setImage: [UIImage imageNamed:@"checkbox15.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet3_1 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet3_2 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet3_3 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet3_4 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet4_1 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet4_2 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet4_3 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet4_4 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet4_5 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    [_checkConditionButtonSet4_6 setImage: [UIImage imageNamed:@"checkbox13.png"] forState:UIControlStateNormal];
    
    [_checkConditionButtonSet1_1_1 setImage: [UIImage imageNamed:@"checkbox15_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet1_1_2 setImage: [UIImage imageNamed:@"checkbox15_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet1_2_1 setImage: [UIImage imageNamed:@"checkbox15_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet1_2_2 setImage: [UIImage imageNamed:@"checkbox15_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet2_1 setImage: [UIImage imageNamed:@"checkbox15_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet2_2 setImage: [UIImage imageNamed:@"checkbox15_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet3_1 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet3_2 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet3_3 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet3_4 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet4_1 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet4_2 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet4_3 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet4_4 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet4_5 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    [_checkConditionButtonSet4_6 setImage: [UIImage imageNamed:@"checkbox13_check.png"] forState:UIControlStateSelected];
    
    //네비게이션바에서 백버튼 제거
    [self.navigationItem setHidesBackButton:true];
    //슬라이드해서 뒤로 넘어가는 기능 제거
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.enabled = NO;
        }
    
    
    //글씨 시간 차로 띄울 때 사용
    [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(checkConditionTimer:) userInfo:nil repeats:YES];
    
    //3page 글자간격 생성
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
    [style setLineSpacing:10];
    NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_checkConditionText3_2.text];
    NSMutableAttributedString *modifyLabel2 = [[NSMutableAttributedString alloc] initWithString:_checkConditionText3_3.text];
    [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
    [modifyLabel2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel2.length)];
    [_checkConditionText3_2 setAttributedText:modifyLabel];
    [_checkConditionText3_3 setAttributedText:modifyLabel2];
}

//글씨 시간 차로 띄울 때 사용
-(void)checkConditionTimer:(NSTimer*)timer{
    pagenext++;
    if(pagenext == 1){
        _conditionOrientationImage.hidden = NO;
    }
    else{
        _conditionOrientationText2.hidden = NO;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    if(pagenext >=2){
        [timer invalidate];
    }
}

- (IBAction)nextPage:(id)sender {
    switch(pageNumber){
        case 1:
            _conditionOrientationText1.hidden = YES;
            _conditionOrientationImage.hidden = YES;
            _conditionOrientationText2.hidden = YES;
            _nextButtonBack.hidden =YES;
            _NextButton.hidden = YES;
            
            _checkConditionText1.hidden = NO;
            _checkConditionButtonSet1_1_1.hidden = NO;
            _checkConditionButtonSet1_1_2.hidden = NO;
            _checkConditionButtonSet1_2_1.hidden = NO;
            _checkConditionButtonSet1_2_2.hidden = NO;
            _checkConditionText1_1.hidden = NO;
            _checkConditionText1_2.hidden = NO;
            _checkConditionText1_3.hidden = NO;
            _checkConditionText1_4.hidden = NO;
            
            isChecking = false;
            isChecking2 = false;
            
            pageNumber++;
            break;
        case 2:
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 3:
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 4:
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 5:
            if(value>0){
                if((value/32)==1){
                    if([_checkConditionTextView4.text isEqual:@""]){ // textview가 빈칸일 경우 alert 띄움
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
                        [alert addAction:closeAction];
                        [self presentViewController:alert animated:YES completion:nil];
                    } else {
                        if(isDoingNetwork==0){
                            [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :_checkConditionTextView4.text];
                        }
                    }
                }
                else{
                    if(isDoingNetwork==0){
                        [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
                    }
                }
            }
            else{
                UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"보기 중에 하나 이상 선택해주세요." preferredStyle:UIAlertControllerStyleAlert];
                
                UIAlertAction * ok = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                }];
                
                [alert addAction:ok];
                [self presentViewController:alert animated:YES completion:nil];
            }
            break;
        case 6:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 7:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 8:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 9:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 10:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 11:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 12:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 13:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 14:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
            break;
        case 15:
            value = (int)slider.tag;
            if(isDoingNetwork==0){
                [self updateCheckConditionServer:testPkey :testLogPkey :pageNumber :value :value2 :@""];
            }
                //[self.navigationController popViewControllerAnimated:YES];
            break;
    }
}


//각 라디오 버튼 그룹마다 선택 구현
- (IBAction)buttonSetAction1_1:(UIButton *)sender {
    if(isChecking){
            for (UIButton* button in _radioButtonsArray1_1){
                button.selected = false;
            }
        sender.selected = true;
        value = (NSInteger)[_radioButtonsArray1_1 indexOfObject:sender];
    }
    else{
        sender.selected = true;
        isChecking = true;
        value = (NSInteger)[_radioButtonsArray1_1 indexOfObject:sender];
    }
    if(isChecking2){
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
}

- (IBAction)buttonSetAction1_2:(UIButton *)sender {
    if(isChecking2){
            for (UIButton* button in _radioButtonsArray1_2){
                button.selected = false;
            }
        sender.selected = true;
        value2 = (NSInteger)[_radioButtonsArray1_2 indexOfObject:sender];
    }
    else{
        sender.selected = true;
        isChecking2 = true;
        value2 = (NSInteger)[_radioButtonsArray1_2 indexOfObject:sender];
    }
    if(isChecking){
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
}

- (IBAction)buttonAction2:(UIButton *)sender {
    if(isChecking){
            for (UIButton* button in _radioButtonsArray2){
                button.selected = false;
            }
        sender.selected = true;
        value = (NSInteger)[_radioButtonsArray2 indexOfObject:sender];
    }
    else{
        sender.selected = true;
        isChecking = true;
        value = (NSInteger)[_radioButtonsArray2 indexOfObject:sender];
    }
    _nextButtonBack.hidden =NO;
    _NextButton.hidden = NO;
}

- (IBAction)buttonAction3:(UIButton *)sender {
    if(isChecking){
            for (UIButton* button in _radioButtonsArray3){
                button.selected = false;
            }
        sender.selected = true;
        value = (NSInteger)[_radioButtonsArray3 indexOfObject:sender];
    }
    else{
        sender.selected = true;
        isChecking = true;
        value = (NSInteger)[_radioButtonsArray3 indexOfObject:sender];
    }
    _nextButtonBack.hidden =NO;
    _NextButton.hidden = NO;
}

- (IBAction)buttonAction4_1:(UIButton *)sender {
    _checkConditionButtonSet4_1.selected = !_checkConditionButtonSet4_1.selected;
    if (_checkConditionButtonSet4_1.selected){
        value += 1;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    else{
        value -= 1;
    }
}

- (IBAction)buttonAction4_2:(id)sender {
    _checkConditionButtonSet4_2.selected = !_checkConditionButtonSet4_2.selected;
    if (_checkConditionButtonSet4_2.selected){
        value += 2;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    else{
        value -= 2;
    }
}

- (IBAction)buttonAction4_3:(id)sender {
    _checkConditionButtonSet4_3.selected = !_checkConditionButtonSet4_3.selected;
    if (_checkConditionButtonSet4_3.selected){
        value += 4;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    else{
        value -= 4;
    }
}

- (IBAction)buttonAction4_4:(id)sender {
    _checkConditionButtonSet4_4.selected = !_checkConditionButtonSet4_4.selected;
    if (_checkConditionButtonSet4_4.selected){
        value += 8;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    else{
        value -= 8;
    }
}

- (IBAction)buttonAction4_5:(id)sender {
    _checkConditionButtonSet4_5.selected = !_checkConditionButtonSet4_5.selected;
    if (_checkConditionButtonSet4_5.selected){
        value += 16;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    else{
        value -= 16;
    }
}

- (IBAction)buttonAction4_6:(id)sender {
    _checkConditionButtonSet4_6.selected = !_checkConditionButtonSet4_6.selected;
    if (_checkConditionButtonSet4_6.selected){
        value += 32;
        _nextButtonBack.hidden =NO;
        _NextButton.hidden = NO;
    }
    else{
        value -= 32;
    }
}

//slider touch action
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
    UITouch *touch = [touches anyObject];
    printf("value: %d\n",(int)slider.tag);
    NSMutableArray *pointArray = slider.getView;
    int len = (int)pointArray.count;
    
    for(int i=0;i<len;i++){
        if(pointArray[i]==touch.view){
            _NextButton.hidden = NO;
            _nextButtonBack.hidden = NO;
            break;
        }
    }
    
    
}

// DB에 데이터 전송
- (void) updateCheckConditionServer:(NSInteger) testPkey : (NSInteger) testLogPkey : (NSInteger) count : (NSInteger) value : (NSInteger) value2 : (NSString*) selfCheck5Text{
    isDoingNetwork = 1;
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분 - 본인 윈도우 노트북에 있는 ip주소로 하면 됩니다.
    NSString *url = @"http://healingmindcenter.com//cbm_app/cbm_api/update_check_condition.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"Pkey=%ld&TestPkey=%ld&Count=%ld&Value=%ld&Value2=%ld&SelfCheck5Text=%@",(long)testLogPkey,(long)testPkey,(long)count,(long)value,(long)value2,selfCheck5Text];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
        if(error){
            NSLog(@"network error!");
            self->isDoingNetwork = 0;
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
            UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                [alert dismissViewControllerAnimated:YES completion:nil];   }];
            [alert addAction:cancel];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else{
            NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
            NSLog(@"responseData1: %@", content);
            if([content intValue] == 1){
                switch(self->pageNumber){
                    case 2:
                        self->_checkConditionText1.hidden = YES;
                        self->_checkConditionButtonSet1_1_1.hidden = YES;
                        self->_checkConditionButtonSet1_1_2.hidden = YES;
                        self->_checkConditionButtonSet1_2_1.hidden = YES;
                        self->_checkConditionButtonSet1_2_2.hidden = YES;
                        self->_checkConditionText1_1.hidden = YES;
                        self->_checkConditionText1_2.hidden = YES;
                        self->_checkConditionText1_3.hidden = YES;
                        self->_checkConditionText1_4.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->isChecking = false;
                        self->isDoingNetwork = 0;
                        
                        if(value||value2){
                            self->_checkConditionText2.hidden = NO;
                            self->_checkConditionButtonSet2_1.hidden = NO;
                            self->_checkConditionButtonSet2_2.hidden = NO;
                            self->_checkConditionText2_1.hidden = NO;
                            self->_checkConditionText2_2.hidden = NO;
                            
                            self->pageNumber++;
                        }
                        else{
                            self->pageNumber = 6;
                            self->slider.hidden = NO;
                            self->_checkConditionText5.hidden = NO;
                        }
                        break;
                    case 3:
                        self->_checkConditionText2.hidden = YES;
                        self->_checkConditionButtonSet2_1.hidden = YES;
                        self->_checkConditionButtonSet2_2.hidden = YES;
                        self->_checkConditionText2_1.hidden = YES;
                        self->_checkConditionText2_2.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->isChecking = false;
                        self->isDoingNetwork = 0;
                        
                        if(!value){
                            self->pageNumber = 6;
                            self->slider.hidden = NO;
                            self->_checkConditionText5.hidden = NO;
                        }
                        else{
                            self->_checkConditionText3.hidden = NO;
                            self->_checkConditionButtonSet3_1.hidden = NO;
                            self->_checkConditionButtonSet3_2.hidden = NO;
                            self->_checkConditionButtonSet3_3.hidden = NO;
                            self->_checkConditionButtonSet3_4.hidden = NO;
                            self->_checkConditionText3_1.hidden = NO;
                            self->_checkConditionText3_2.hidden = NO;
                            self->_checkConditionText3_3.hidden = NO;
                            self->_checkConditionText3_4.hidden = NO;
                            
                            self->pageNumber++;
                        }
                        
                        
                        break;
                    case 4:
                        self->_checkConditionText3.hidden = YES;
                        self->_checkConditionButtonSet3_1.hidden = YES;
                        self->_checkConditionButtonSet3_2.hidden = YES;
                        self-> _checkConditionButtonSet3_3.hidden = YES;
                        self->_checkConditionButtonSet3_4.hidden = YES;
                        self->_checkConditionText3_1.hidden = YES;
                        self->_checkConditionText3_2.hidden = YES;
                        self->_checkConditionText3_3.hidden = YES;
                        self->_checkConditionText3_4.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->_checkConditionText4.hidden = NO;
                        self->_checkConditionButtonSet4_1.hidden = NO;
                        self->_checkConditionButtonSet4_2.hidden = NO;
                        self->_checkConditionButtonSet4_3.hidden = NO;
                        self->_checkConditionButtonSet4_4.hidden = NO;
                        self->_checkConditionButtonSet4_5.hidden = NO;
                        self->_checkConditionButtonSet4_6.hidden = NO;
                        self->_checkConditionText4_1.hidden = NO;
                        self->_checkConditionText4_2.hidden = NO;
                        self->_checkConditionText4_3.hidden = NO;
                        self->_checkConditionText4_4.hidden = NO;
                        self->_checkConditionText4_5.hidden = NO;
                        self->_checkConditionText4_6.hidden = NO;
                        self->_checkConditionTextView4.hidden = NO;
                        
                        self->value = 0;
                        self->isChecking = false;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        
                        break;
                    case 5:
                        self->_checkConditionText4.hidden = YES;
                        self->_checkConditionButtonSet4_1.hidden = YES;
                        self->_checkConditionButtonSet4_2.hidden = YES;
                        self->_checkConditionButtonSet4_3.hidden = YES;
                        self->_checkConditionButtonSet4_4.hidden = YES;
                        self->_checkConditionButtonSet4_5.hidden = YES;
                        self->_checkConditionButtonSet4_6.hidden = YES;
                        self->_checkConditionText4_1.hidden = YES;
                        self->_checkConditionText4_2.hidden = YES;
                        self->_checkConditionText4_3.hidden = YES;
                        self->_checkConditionText4_4.hidden = YES;
                        self->_checkConditionText4_5.hidden = YES;
                        self->_checkConditionText4_6.hidden = YES;
                        self->_checkConditionTextView4.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                                
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                                
                        self->slider.hidden = NO;
                        self->_checkConditionText5.hidden = NO;
                        break;
                    case 6:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText5.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n슬프지\n않음",@"",@"약간\n슬픈",@"",@"어느 정도\n슬픈",@"",@"꽤\n슬픈",@"",@"매우\n슬픈",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText6.hidden = NO;
                        
                        break;
                    case 7:
                        [self->slider hiddenThumb];
                        self-> slider.hidden = YES;
                        self->_checkConditionText6.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n불안하지\n않음",@"",@"약간\n불안한",@"",@"어느 정도\n불안한",@"",@"꽤\n불안한",@"",@"매우\n불안한",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText7.hidden = NO;
                        
                        break;
                    case 8:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText7.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n두렵지\n않음",@"",@"약간\n두려움",@"",@"어느 정도\n두려움",@"",@"꽤\n두려움",@"",@"매우\n두려움",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText8.hidden = NO;
                        
                        break;
                    case 9:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText8.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n외롭지\n않음",@"",@"약간\n외로움",@"",@"어느 정도\n외로움",@"",@"꽤\n외로움",@"",@"매우\n외로움",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText9.hidden = NO;
                        
                        break;
                    case 10:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText9.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n느껴지지\n않음",@"",@"약간\n느낌",@"",@"어느 정도\n느낌",@"",@"꽤\n느낌",@"",@"매우\n느낌",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText10.hidden = NO;
                        
                        break;
                    case 11:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText10.hidden = YES;
                        self-> _nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n화가 나지\n않음",@"",@"약간\n화가 남",@"",@"어느 정도\n화가 남",@"",@"꽤\n화가 남",@"",@"매우\n화가 남",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText11.hidden = NO;
                        
                        break;
                    case 12:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText11.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n화가 나지\n않음",@"",@"약간\n화가 남",@"",@"어느 정도\n화가 남",@"",@"꽤\n화가 남",@"",@"매우\n화가 남",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText12.hidden = NO;
                        
                        break;
                    case 13:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText12.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n수치스럽지\n않음",@"",@"약간\n수치스러움",@"",@"어느 정도\n수치스러움",@"",@"꽤\n수치스러움",@"",@"매우\n수치스러움",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText13.hidden = NO;
                        
                        break;
                    case 14:
                        [self->slider hiddenThumb];
                        self->slider.hidden = YES;
                        self->_checkConditionText13.hidden = YES;
                        self->_nextButtonBack.hidden =YES;
                        self->_NextButton.hidden = YES;
                        
                        self->value = 0;
                        self->isDoingNetwork = 0;
                        self->pageNumber++;
                        
                        self->textArray=[NSArray arrayWithObjects:@"전혀\n공허하지\n않음",@"",@"약간\n공허한",@"",@"어느 정도\n공허한",@"",@"꽤\n공허한",@"",@"매우\n공허한",nil];
                        [self->slider setPoint:1 endNum:9 textArray:self->textArray titleNameType:0];
                        self->slider.hidden = NO;
                        self->_checkConditionText14.hidden = NO;
                        
                        break;
                    case 15:
                        if(self->isDoingNetwork==1){
                            [self updateCurrentProgress:testLogPkey :testPkey];
                        }
                        break;
                }
                
            }
            else{
                self->isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
        }
            
        } ];
    [dataTask resume];
}

- (void) updateCurrentProgress: (NSInteger) testLogPkey :(NSInteger) testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    isDoingNetwork = 2;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분 - 본인 윈도우 노트북에 있는 ip주소로 하면 됩니다.
    NSString *url = @"http://healingmindcenter.com//cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"Pkey=%ld&testPkey=%ld", (long)testLogPkey, (long)testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                self->isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0){
                    if(self->currentcount==3){
                        UIStoryboard *storyboard =
                            [UIStoryboard storyboardWithName:@"Finish" bundle:nil];
                        FinishController *finishview = [storyboard instantiateViewControllerWithIdentifier:@"FinishController"];
                        [self.navigationController pushViewController:finishview animated:YES];
                    }
                    else{
                        [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                    }
                }
                else{
                    self->isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
}

- (void) requestCount: (NSInteger) testPkey {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_count_test.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"testPKey=%ld&", (long)testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_request_count_test전체차수: %@", content);
                //여기에 넣어야 딜레이 안생김 전체차수count받아와야하기때문에
                [self requestCurrentProgress:testPkey];
                
                self->currentcount = [content intValue];
                }            
        } ];
    [dataTask resume];
}

- (void) requestCurrentProgress: (NSInteger)testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    int logpkey = (int)[userDefaults integerForKey:@"testLogPkey"];

    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_current_progress.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"pKey=%d&testPKey=%ld", logpkey, (long)testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_currentPROGRESS: %@", content);
                
                self->Progress = [content intValue];
                
            }
        NSLog(@"카운트: %d", self->currentcount);
        } ];
    [dataTask resume];
}

@end
