//
//  ApproachController.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ApproachController : UIViewController <NSURLSessionDataDelegate>

// 다가서기 1페이지
@property (weak, nonatomic) IBOutlet UILabel *approachLabel1_1;
@property (weak, nonatomic) IBOutlet UILabel *approachLabel1_2;

@property (weak, nonatomic) IBOutlet UIButton *approachNextBtn;
@property (weak, nonatomic) IBOutlet UIImageView *approachNextBtn_Back;

// 다가서기 2페이지
@property (weak, nonatomic) IBOutlet UILabel *approachLabel2_1;
@property (weak, nonatomic) IBOutlet UILabel *approachLabel2_2;
@property (weak, nonatomic) IBOutlet UILabel *approachLabel2_3;

- (IBAction)touchNextBtn:(UIButton *)sender;

// 타이머에서 호출하는 함수들
-(void)visibleLabel:(UILabel *)label;
-(void)visibleBtn:(UIButton *)button;
-(void)visibleBtnBack:(UIImageView *)image;

@end

NS_ASSUME_NONNULL_END
