//
//  TrainingCBMController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//
#import "TrainingCBMController.h"


@interface TrainingCBMController (){
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    
    NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수
    NSInteger cbmDegreeTrans; //몇번째 cbm인지
    NSInteger thinkCount;
    NSInteger pagenext;
    NSInteger testLogPkey;
    NSInteger testPkey;
    int cbmProgress;
    int audioStart; //첫 음성 중복 재생 막음
    int isDoingNetwork; //currentProgress 추가 시에 중복 터치를 막기 위해 사용되는 변수
    int isSendingData; //think 저장 후에 다음 음성 재생, 음성 중복 재생 막음
    bool isDataLoad; //데이터로드확인변수
    int isFirstReplay; //버튼 중복 터치 막음
    int logdata;
}

@property (weak, nonatomic) IBOutlet UIButton *orientationNextButton;
@property (weak, nonatomic) IBOutlet UIButton *thinkButton;
@property (weak, nonatomic) IBOutlet UITextView *thinkTextInput;
@property (weak, nonatomic) IBOutlet UILabel *orientationText1;
@property (weak, nonatomic) IBOutlet UILabel *orientationText2;
@property (weak, nonatomic) IBOutlet UILabel *thinkText1;
@property (weak, nonatomic) IBOutlet UILabel *thinkText2;
@property (weak, nonatomic) IBOutlet UIImageView *orientationImage;
@property (weak, nonatomic) IBOutlet UIImageView *playAudioImage;
@property (weak, nonatomic) IBOutlet UIImageView *btnbackCbm;
@property (weak, nonatomic) IBOutlet UIButton *thinkYesButton;
@property (weak, nonatomic) IBOutlet UIButton *thinkNoButton;
@property (weak, nonatomic) IBOutlet UILabel *thinkYesText;
@property (weak, nonatomic) IBOutlet UILabel *thinkNoText;
@property (weak, nonatomic) IBOutlet UILabel *thinkYesOrNo;
@property (weak, nonatomic) IBOutlet UIButton *replayButton;

@end

@implementation TrainingCBMController

- (void)viewDidLoad {
    [super viewDidLoad];
    //변수 초기화
    cbmDegreeTrans = 0;
    thinkCount = 0;
    pagenext = 0;
    cbmProgress = 0;
    audioStart = 0;
    isDoingNetwork = 0;
    isSendingData = 0;
    isFirstReplay =0;
    userDefaults = [NSUserDefaults standardUserDefaults];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    
    player =nil;
    playerLayer = nil;
    
    [self requestCount:testPkey];
    [_replayButton setExclusiveTouch:YES];
    
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_green.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
         
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
         
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼 이미지 깨질 시에 버튼에 자동으로 설정되는 타이틀을 공백으로 만들어서 이미지 보이게 함
    [_orientationNextButton setTitle:@"" forState:UIControlStateNormal];
    [_thinkButton setTitle:@"" forState:UIControlStateNormal];
    [_thinkYesButton setTitle:@"" forState:UIControlStateNormal];
    [_thinkNoButton setTitle:@"" forState:UIControlStateNormal];
    [_replayButton setTitle:@"" forState:UIControlStateNormal];
    
    //처음에 나오는 것만 빼고 숨기기
    _orientationImage.hidden = NO;
    _orientationText1.hidden = YES;
    _orientationText2.hidden = YES;
    _orientationNextButton.hidden = YES;
    _btnbackCbm.hidden = YES;
    _playAudioImage.hidden = YES;
    _thinkText1.hidden = YES;
    _thinkText2.hidden = YES;
    _thinkTextInput.hidden = YES;
    _thinkButton.hidden = YES;
    _thinkYesButton.hidden = YES;
    _thinkYesText.hidden = YES;
    _thinkNoButton.hidden = YES;
    _thinkNoText.hidden = YES;
    _thinkYesOrNo.hidden = YES;
    _replayButton.hidden = YES;
    
    NSLog(@"viewdidload");
    
    [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(TrainCBMTimer:) userInfo:nil repeats:YES];
    
    //네비게이션바에서 백버튼 제거
    [self.navigationItem setHidesBackButton:true];
    //슬라이드해서 뒤로 넘어가는 기능 제거
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
            self.navigationController.interactivePopGestureRecognizer.enabled = NO;
        }
    //글자간격 생성
    NSString *modifyText = @"방금 들은 이야기를\n생각나는 대로 아래에 적어주세요.";
    _thinkText1.text = modifyText;
    NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
    [style setLineSpacing:10];
    [style setAlignment:NSTextAlignmentCenter];
    NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_thinkText1.text];
    [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
    [_thinkText1 setAttributedText:modifyLabel];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    thinkCount = 0; //자동으로 변수 초기화 안해줌
    pagenext = 0;
    [player pause];
}

//글씨 시간 차로 띄울 때 사용
-(void)TrainCBMTimer:(NSTimer*)timer{
    pagenext++;
    if(pagenext == 1){
        _orientationText1.hidden = NO;
    }
    else{
        _orientationText2.hidden = NO;
        _orientationNextButton.hidden = NO;
        _btnbackCbm.hidden = NO;
    }
    if(pagenext >=2){
        [timer invalidate];
    }
}
//안내문에서 다음으로 넘어가는 버튼 누르면 음성 재생
- (IBAction)orientationNext:(id)sender {
    _orientationImage.hidden = YES;
    _orientationText1.hidden = YES;
    _orientationText2.hidden = YES;
    _orientationNextButton.hidden = YES;
    _btnbackCbm.hidden = YES;
    NSLog(@"orientationNext");
    
    if(audioStart==0){
        [self playCBMAudio:thinkCount+(13*cbmDegreeTrans)+1];
        audioStart += 1;
    }
    
}
// 음성 재생
- (void)playCBMAudio:(NSInteger)audioNum {
    _playAudioImage.hidden = NO;
    _replayButton.hidden = NO;
    _btnbackCbm.hidden = NO;
    
    NSString *audioNumtoString = [@(audioNum) stringValue];
    NSString *url1 = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/cbm/";
    NSString *url2 = @".mp3";
    NSString *fullurl1 = [url1 stringByAppendingString:audioNumtoString];
    NSString *fullurl2 = [fullurl1 stringByAppendingString:url2];
    
    NSURL *url = [NSURL URLWithString:fullurl2];
    if(player == nil){
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;

          [[NSNotificationCenter defaultCenter] addObserver:self
                                                   selector:@selector(playerItemDidReachEnd:)
                                                       name:AVPlayerItemDidPlayToEndTimeNotification
                                                     object:[player currentItem]];
        
    }else{
        [player seekToTime:CMTimeMake(0,1)];
        [player pause];
        [player replaceCurrentItemWithPlayerItem:nil];
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;

          [[NSNotificationCenter defaultCenter] addObserver:self
                                                   selector:@selector(playerItemDidReachEnd:)
                                                       name:AVPlayerItemDidPlayToEndTimeNotification
                                                     object:[player currentItem]];
        
    }
    if(playerLayer == nil){
        playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
        playerLayer.frame = self.view.bounds;
        [self.view.layer addSublayer:playerLayer];
        
    }else{
        
    }
    [player play];
    
    
    
    
}
// 음성 재생 끝나면 종료시키고 생각 입력
- (void)playerItemDidReachEnd:(NSNotification *)notification{
    _playAudioImage.hidden = YES;
    _replayButton.hidden = YES;
    _btnbackCbm.hidden = YES;
    _thinkYesButton.hidden = NO;
    _thinkYesText.hidden = NO;
    _thinkNoButton.hidden = NO;
    _thinkNoText.hidden = NO;
    _thinkYesOrNo.hidden = NO;
    isSendingData = 0;
}

- (IBAction)thinkYes:(id)sender {
    _thinkYesButton.hidden = YES;
    _thinkYesText.hidden = YES;
    _thinkNoButton.hidden = YES;
    _thinkNoText.hidden = YES;
    _thinkYesOrNo.hidden = YES;
    _thinkText1.hidden = NO;
    _thinkTextInput.text = @"";
    _thinkTextInput.hidden = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textViewDidChange:)
                                                     name:UITextViewTextDidChangeNotification
                                                   object:_thinkTextInput];
}

- (IBAction)thinkNo:(id)sender {
    _thinkYesButton.hidden = YES;
    _thinkYesText.hidden = YES;
    _thinkNoButton.hidden = YES;
    _thinkNoText.hidden = YES;
    _thinkYesOrNo.hidden = YES;
    _thinkText1.hidden = NO;
    _thinkTextInput.text = @"";
    _thinkTextInput.hidden = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textViewDidChange:)
                                                     name:UITextViewTextDidChangeNotification
                                                   object:_thinkTextInput];
}

// 입력 창에 입력 시에 버튼 띄우기
- (void)textViewDidChange:(NSNotification *)notification{
    _thinkText2.hidden = NO;
    _thinkButton.hidden = NO;
    _btnbackCbm.hidden = NO;
    
    if([_thinkTextInput.text isEqual:@""]){
        _thinkText2.hidden = YES;
        _thinkButton.hidden = YES;
        _btnbackCbm.hidden = YES;
    }
}
// 입력 후에 다음 영상으로 넘어가기
- (IBAction)updateThink:(id)sender {
    if(isSendingData==0){
        [self updateThinkServer:testLogPkey :_thinkTextInput.text :thinkCount+1];
    }
}
// DB에 데이터 전송
- (void) updateThinkServer: (NSInteger) testLogPkey : (NSString *) think : (NSInteger) thinkCount {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    isSendingData=1;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분 - 본인 윈도우 노트북에 있는 ip주소로 하면 됩니다.
    NSString *url = @"http://healingmindcenter.com//cbm_app/cbm_api/update_think.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"testLogPkey=%ld&think=%@&thinkCount=%ld", (long)testLogPkey, think, (long)thinkCount];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
        if(error){
            NSLog(@"network error!");
            self->isSendingData=0;
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
            UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                [alert dismissViewControllerAnimated:YES completion:nil];   }];
            [alert addAction:cancel];
            [self presentViewController:alert animated:YES completion:nil];
        }
        else{
            NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
            NSLog(@"responseData1: %@", content);
            if([content intValue] == 0){
                self->_thinkText1.hidden = YES;
                self->_thinkText2.hidden = YES;
                self->_thinkTextInput.hidden = YES;
                self->_thinkButton.hidden = YES;
                self->_btnbackCbm.hidden = YES;
                NSLog(@"updatethink");
                
                if (thinkCount>=12){
                    if(self->isDoingNetwork==0)
                        [self updateCurrentProgress:testLogPkey :self->testPkey];
                }
                else{
                    if (self->isSendingData ==1){
                        self->thinkCount += 1;
                        [self playCBMAudio:thinkCount+(13*self->cbmDegreeTrans)+1];
                    }
                }
            }
            else{
                self->isSendingData = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
        }
        } ];
    [dataTask resume];
}

- (void) updateCurrentProgress: (NSInteger) testLogPkey :(NSInteger) testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    isDoingNetwork=1;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분 - 본인 윈도우 노트북에 있는 ip주소로 하면 됩니다.
    NSString *url = @"http://healingmindcenter.com//cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"Pkey=%ld&testPkey=%ld", (long)testLogPkey, (long)testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                isDoingNetwork=0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; //홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
            }
        }
        } ];
    [dataTask resume];
}

- (void) requestCount: (NSInteger) testPkey {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_count_test.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"testPKey=%ld&", (long)testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_request_count_test전체차수: %@", content);
                //여기에 넣어야 딜레이 안생김 전체차수count받아와야하기때문에
                [self requestCurrentProgress:testPkey];
                
                cbmDegreeTrans = [content intValue]-4;
                }
        } ];
    [dataTask resume];
}

- (void) requestCurrentProgress: (NSInteger)testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    int logpkey = (int)[userDefaults integerForKey:@"testLogPkey"];

    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_current_progress.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"pKey=%d&testPKey=%ld", logpkey, (long)testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_currentPROGRESS: %@", content);
                
                cbmProgress = [content intValue];
                
            }
        NSLog(@"카운트: %ld", (long)cbmDegreeTrans);
        } ];
    [dataTask resume];
}

- (IBAction)replayAudio:(id)sender {
    [self playCBMAudio:thinkCount+(13*self->cbmDegreeTrans)+1];
}

//화면 바깥 터치 시 키보드 내리기
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
}

@end
