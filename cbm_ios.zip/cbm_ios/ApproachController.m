//
//  ApproachController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "ApproachController.h"

@interface ApproachController (){
    int isDoingNetwork; //중복 터치 차단
}

@end

@implementation ApproachController

NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수
int btnNum; // 버튼을 클릭한 횟수를 세는 변수
int groupType; //훈련집단이랑 비교집단이랑 멘트 다름
- (void)viewDidLoad {
    [super viewDidLoad];
    
    isDoingNetwork = 0;
    // 배경 이미지를 화면 크기에 맞게 변경
    UIImage *image = [UIImage imageNamed:@"back_pink.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    // 변수 초기화
    btnNum = 1;
    userDefaults = [NSUserDefaults standardUserDefaults];
    groupType = (int)[userDefaults integerForKey:@"GroupType"];
    
    // 첫 레이블 제외 모든 오브젝트 숨김 처리
    _approachLabel1_2.hidden = YES;
    _approachLabel2_1.hidden = YES;
    _approachLabel2_2.hidden = YES;
    _approachLabel2_3.hidden = YES;
    _approachNextBtn.hidden = YES;
    _approachNextBtn_Back.hidden = YES;

    // 오브젝트가 지연되어 뜨게끔 타이머 설정
    [self performSelector:@selector(visibleLabel:) withObject:_approachLabel1_2 afterDelay:2.0];
    [self performSelector:@selector(visibleBtn:) withObject:_approachNextBtn afterDelay:2.0];
    [self performSelector:@selector(visibleBtnBack:) withObject:_approachNextBtn_Back afterDelay:2.0];
    
}

- (IBAction)touchNextBtn:(UIButton *)sender {
    if(btnNum == 1){
        // 1페이지 숨김 처리
        _approachLabel1_1.hidden = YES;
        _approachLabel1_2.hidden = YES;
        _approachNextBtn.hidden = YES;
        _approachNextBtn_Back.hidden = YES;
        
        if(groupType == 1){
            _approachLabel2_3.text = @"그럼 먼저 컨디션 체크부터 해볼까요?";
        }
        
        // 2페이지 띄우기
        _approachLabel2_1.hidden = NO;
        [self performSelector:@selector(visibleLabel:) withObject:_approachLabel2_2 afterDelay:3.0];
        [self performSelector:@selector(visibleLabel:) withObject:_approachLabel2_3 afterDelay:6.0];
        [self performSelector:@selector(visibleLabel:) withObject:_approachLabel1_2 afterDelay:8.0];
        [self performSelector:@selector(visibleBtn:) withObject:_approachNextBtn afterDelay:8.0];
        [self performSelector:@selector(visibleBtnBack:) withObject:_approachNextBtn_Back afterDelay:8.0];
        btnNum++;
    }
    else{
        if(isDoingNetwork == 0){
            [self updateCurrentProgress]; // 다가서기가 끝났으므로 currentprogress 1 증가시키기
            //[self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
        }
    }
}

// 호출하면 레이블을 띄워주는 함수
-(void)visibleLabel:(UILabel *)label
{
    label.hidden = NO;
}

// 호출하면 버튼을 띄워주는 함수
-(void)visibleBtn:(UIButton *)button
{
    button.hidden = NO;
}

// 호출하면 버튼 배경을 띄워주는 함수
-(void)visibleBtnBack:(UIImageView *)image
{
    image.hidden = NO;
}

// 다가서기가 끝났음을 알리기 위해 DB의 currentProgress를 1 증가시키는 함수
- (void) updateCurrentProgress{
    isDoingNetwork = 1;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey, testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
        
    } ];
    [dataTask resume];
}
@end
