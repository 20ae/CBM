//
//  OrientationController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "OrientationController.h"

@interface OrientationController () {
    int count;
    int pageA, pageB, pageC, pageD, pageE, pageF, pageF_1, pageF_2, pageG;
    int isDoingNetwork; //중복 터치 차단
}

@property (strong, nonatomic) IBOutlet UIButton *nextBtn;
@property (strong, nonatomic) IBOutlet UIImageView *nextBtnBack;

@property (strong, nonatomic) IBOutlet UILabel *pageAl1;
@property (strong, nonatomic) IBOutlet UIImageView *pageAimg;
@property (strong, nonatomic) IBOutlet UILabel *pageAl2;

@property (strong, nonatomic) IBOutlet UILabel *pageBl1;
@property (strong, nonatomic) IBOutlet UILabel *pageBl2;
@property (strong, nonatomic) IBOutlet UILabel *pageBl3;
@property (strong, nonatomic) IBOutlet UILabel *pageBl4;
@property (strong, nonatomic) IBOutlet UILabel *pageBl5;

@property (strong, nonatomic) IBOutlet UILabel *pageCl1;
@property (strong, nonatomic) IBOutlet UIImageView *pageCimg;
@property (strong, nonatomic) IBOutlet UILabel *pageCl2;
@property (strong, nonatomic) IBOutlet UILabel *pageCl3;
@property (strong, nonatomic) IBOutlet UILabel *pageCl4;

@property (strong, nonatomic) IBOutlet UILabel *pageDl1;
@property (strong, nonatomic) IBOutlet UILabel *pageDl2;
@property (strong, nonatomic) IBOutlet UILabel *pageDl3;
@property (strong, nonatomic) IBOutlet UILabel *pageDl4;

@property (strong, nonatomic) IBOutlet UILabel *pageEl1;
@property (strong, nonatomic) IBOutlet UILabel *pageEl2;
@property (strong, nonatomic) IBOutlet UILabel *pageEl3;
@property (strong, nonatomic) IBOutlet UILabel *pageEl4;
@property (strong, nonatomic) IBOutlet UILabel *pageEl5;

@property (strong, nonatomic) IBOutlet UILabel *pageFl1;
@property (strong, nonatomic) IBOutlet UILabel *pageFl2;
@property (strong, nonatomic) IBOutlet UILabel *pageFl3;
@property (strong, nonatomic) IBOutlet UILabel *pageFl4;
@property (strong, nonatomic) IBOutlet UILabel *pageFl5;
@property (strong, nonatomic) IBOutlet UILabel *pageFl6;


@property (weak, nonatomic) IBOutlet UILabel *pageFl1_1;
@property (weak, nonatomic) IBOutlet UIImageView *pageF_1img;
@property (weak, nonatomic) IBOutlet UILabel *pageFl1_2;

@property (weak, nonatomic) IBOutlet UILabel *pageFl2_1;
@property (weak, nonatomic) IBOutlet UILabel *pageFl2_2;


@property (strong, nonatomic) IBOutlet UILabel *pageGl1;
@property (strong, nonatomic) IBOutlet UILabel *pageGl2;
@property (strong, nonatomic) IBOutlet UILabel *pageGl3;


@end

@implementation OrientationController

NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수

- (void)viewDidLoad {
    [super viewDidLoad];
    isDoingNetwork = 0;
    // 배경 이미지를 화면 크기에 맞게 변경
    UIImage *image = [UIImage imageNamed:@"back_blue.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //변수 초기화
    count = 0;
    pageA = 0;
    pageB = 0;
    pageC = 0;
    pageD = 0;
    pageE = 0;
    pageF = 0;
    pageF_1 = 0;
    pageF_2 = 0;
    pageG = 0;
    
    NSLog(@"초기화확인 : %d, %d", pageG, count);
    
    //Hidden
    _nextBtn.hidden = YES;
    _nextBtnBack.hidden = YES;

    { //Page A
        _pageAl1.hidden = YES;
        _pageAimg.hidden = YES;
        _pageAl2.hidden = YES;
    }
    
    { //Page B
        _pageBl1.hidden = YES;
        _pageBl2.hidden = YES;
        _pageBl3.hidden = YES;
        _pageBl4.hidden = YES;
        _pageBl5.hidden = YES;
    }
    
    { //Page C
        _pageCl1.hidden = YES;
        _pageCimg.hidden = YES;
        _pageCl2.hidden = YES;
        _pageCl3.hidden = YES;
        _pageCl4.hidden = YES;
    }
    
    { //Page D
        _pageDl1.hidden = YES;
        _pageDl2.hidden = YES;
        _pageDl3.hidden = YES;
        _pageDl4.hidden = YES;
    }
    
    { //Page E
        _pageEl1.hidden = YES;
        _pageEl2.hidden = YES;
        _pageEl3.hidden = YES;
        _pageEl4.hidden = YES;
        _pageEl5.hidden = YES;
    }
    
    { //Page F
        _pageFl1.hidden = YES;
        _pageFl2.hidden = YES;
        _pageFl3.hidden = YES;
        _pageFl4.hidden = YES;
        _pageFl5.hidden = YES;
        _pageFl6.hidden = YES;
    }
    { //Page F_1
        NSString *modifyText = @"마지막으로\n인지편향수정 훈련!";
        NSMutableParagraphStyle *style2 = [[NSMutableParagraphStyle alloc] init];
        [style2 setLineSpacing:2];
        [style2 setAlignment:NSTextAlignmentCenter];
        NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:modifyText];
        [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style2 range:NSMakeRange(0, modifyLabel.length)];
        [self.pageFl1_1 setAttributedText:modifyLabel];
        
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:12];
        [style setAlignment:NSTextAlignmentCenter];
        NSString *modifyText2 = @"내 마음을 좀 더 긍정적으로 바꿔주는 치료법으로\n오디오에서 들려주는 이야기를 듣고,\n생각나는 내용을 적어보는 시간을 가질 거예요.";
        NSMutableAttributedString *modifyLabel2 = [[NSMutableAttributedString alloc] initWithString:modifyText2];
        [modifyLabel2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel2.length)];
        [self.pageFl1_2 setAttributedText:modifyLabel2];
        _pageFl1_1.hidden = YES;
        _pageF_1img.hidden = YES;
        _pageFl1_2.hidden = YES;
    }
    {//Page F_2
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:12];
        [style setAlignment:NSTextAlignmentCenter];
        NSString *modifyText = @"우리는 그걸\n‘CBM’\n이라고 불러요.";
        NSString *modifyText2 = @"앞으로 하루에 3번씩\n이 CBM을 할 거예요.";
        NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:modifyText];
        NSMutableAttributedString *modifyLabel2 = [[NSMutableAttributedString alloc] initWithString:modifyText2];
        [modifyLabel addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(8, 5)];
        [modifyLabel2 addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(14, 3)];
        
        [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
        [modifyLabel2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel2.length)];
        [self.pageFl2_1 setAttributedText:modifyLabel];
        [self.pageFl2_2 setAttributedText:modifyLabel2];
        _pageFl2_1.hidden = YES;
        _pageFl2_2.hidden = YES;
        
    }
    { //Page G
        _pageGl1.hidden = YES;
        _pageGl2.hidden = YES;
        _pageGl3.hidden = YES;
    }
    
    //PageA 타이머 시작
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageA:) userInfo:NO repeats:YES];
}


-(void)ControlPageA:(NSTimer*)timer{
    pageA++;
    switch(pageA){
        case 1:
        {
            _pageAl1.hidden = NO;
            _pageAimg.hidden = NO;
        }
            break;
    
        case 3:
            _pageAl2.hidden = NO;
            break;
            
        case 5:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}

-(void)ControlPageB:(NSTimer*)timer{
    pageB++;
    switch(pageB){
        case 1:
            _pageBl1.hidden = NO;
            break;
    
        case 2:
            _pageBl2.hidden = NO;
            _pageBl3.hidden = NO;
            break;
            
        case 4:
            _pageBl4.hidden = NO;
            _pageBl5.hidden = NO;
            break;
            
        case 6:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}

-(void)ControlPageC:(NSTimer*)timer{
    pageC++;
    switch(pageC){
        case 1:
            _pageCl1.hidden = NO;
            _pageCimg.hidden = NO;
            break;
            
        case 3:
            _pageCl2.hidden = NO;
            break;
            
        case 5:
            _pageCl3.hidden = NO;
            _pageCl4.hidden = NO;
            break;
            
        case 7:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}

-(void)ControlPageD:(NSTimer*)timer{
    pageD++;
    switch(pageD){
        case 1:
            _pageDl1.hidden = NO;
            break;
        
        case 3:
            _pageDl2.hidden = NO;
            break;
            
        case 5:
            _pageDl3.hidden = NO;
            _pageDl4.hidden = NO;
            break;
            
        case 7:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}


-(void)ControlPageE:(NSTimer*)timer{
    pageE++;
    switch(pageE){
        case 1:
            _pageEl1.hidden = NO;
            _pageEl2.hidden = NO;
            break;
    
        case 3:
            _pageEl3.hidden = NO;
            break;
            
        case 6:
            _pageEl4.hidden = NO;
            break;
            
        case 8:
            _pageEl5.hidden = NO;
            break;
            
        case 10:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}

-(void)ControlPageF:(NSTimer*)timer{
    pageF++;
    switch(pageF){
        case 1:
            _pageFl1.hidden = NO;
            break;
    
        case 3:
            _pageFl2.hidden = NO;
            break;
            
        case 5:
            _pageFl3.hidden = NO;
            break;
            
        case 7:
            _pageFl4.hidden = NO;
            break;
            
        case 9:
            _pageFl5.hidden = NO;
            _pageFl6.hidden = NO;
            break;
            
        case 11:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}
-(void)ControlPageF1:(NSTimer*)timer{
    pageF_1++;
    switch (pageF_1) {
        case 1:
            _pageFl1_1.hidden = NO;
            _pageF_1img.hidden = NO;
            break;
        case 2:
            _pageFl1_2.hidden = NO;
            break;
        case 3:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}
-(void)ControlPageF2: (NSTimer*)timer{
    pageF_2++;
    switch (pageF_2) {
        case 1:
            _pageFl2_1.hidden = NO;
            break;
        case 2:
            _pageFl2_2.hidden = NO;
            break;
        case 3:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}
-(void)ControlPageG:(NSTimer*)timer{
    pageG++;
    switch(pageG){
        case 1:
            _pageGl1.hidden = NO;
            break;
            
        case 3:
            _pageGl2.hidden = NO;
            break;
            
        case 5:
            _pageGl3.hidden = NO;
            break;
            
        case 7:
            _nextBtn.hidden = NO;
            _nextBtnBack.hidden = NO;
            [timer invalidate];
            break;
    }
}


//버튼이 눌렸을 때 작업 == 라벨 숨기기
- (IBAction)nextBtn:(id)sender {
    switch(count){
        case 0:
        {
            // pageA -> pageB
            NSLog(@"pageA to B");
            count++;
            _pageAl1.hidden = YES;
            _pageAl2.hidden = YES;
            _pageAimg.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;

            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageB:) userInfo:NO repeats:YES];
        }
            break;
            
        case 1:
        {
            // pageB -> pageC
            count++;
            _pageBl1.hidden = YES;
            _pageBl2.hidden = YES;
            _pageBl3.hidden = YES;
            _pageBl4.hidden = YES;
            _pageBl5.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;

            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageC:) userInfo:NO repeats:YES];
        }
            break;
            
        case 2:
        {
            // pageC -> pageD
            count++;
            _pageCl1.hidden = YES;
            _pageCl2.hidden = YES;
            _pageCl3.hidden = YES;
            _pageCl4.hidden = YES;
            _pageCimg.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;

            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageD:) userInfo:NO repeats:YES];
        }
            break;
            
        case 3:
        {
            // pageD -> pageE
            count++;
            _pageDl1.hidden = YES;
            _pageDl2.hidden = YES;
            _pageDl3.hidden = YES;
            _pageDl4.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;

            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageE:) userInfo:NO repeats:YES];
        }
            break;
            
        case 4:
        {
            // pageE -> pageF
            count++;
            _pageEl1.hidden = YES;
            _pageEl2.hidden = YES;
            _pageEl3.hidden = YES;
            _pageEl4.hidden = YES;
            _pageEl5.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;

            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageF:) userInfo:NO repeats:YES];
        }
            break;
            
        case 5:
        {
            // pageF -> pageF_1
            count++;
            _pageFl1.hidden = YES;
            _pageFl2.hidden = YES;
            _pageFl3.hidden = YES;
            _pageFl4.hidden = YES;
            _pageFl5.hidden = YES;
            _pageFl6.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;

            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageF1:) userInfo:NO repeats:YES];
        }
            break;
            
        case 6:
        {
            // pageF_1 -> pageF_2
            count++;
            _pageFl1_1.hidden = YES;
            _pageF_1img.hidden = YES;
            _pageFl1_2.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;
            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageF2:) userInfo:NO repeats:YES];
            
        }
            break;
        case 7:
        {
            // pageF_2 -> pageG
            count++;
            _pageFl2_1.hidden = YES;
            _pageFl2_2.hidden = YES;
            _nextBtn.hidden = YES;
            _nextBtnBack.hidden = YES;
            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPageG:) userInfo:NO repeats:YES];
        }
            break;
        case 8:
        {
            // pageG -> HOME
            //count = 0;
            if(isDoingNetwork==0)
                [self updateCurrentProgress];
                //[self.navigationController popViewControllerAnimated:YES];
        }
            break;
            
    }
}


//끝났음을 알리는 DB_CurrentProgress 1 증가
- (void) updateCurrentProgress{
    isDoingNetwork = 1;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    NSLog(@"test key value : %d , %d", testLogPkey, testPkey); // user moon : 21, 11
    
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey, testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                    NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                    NSLog(@"responseData1: %@", content);
                    if([content intValue] == 0)
                        [self.navigationController popViewControllerAnimated:YES];
                    else{
                        isDoingNetwork = 0;
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];   }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                    }
            }
        
    } ];
    [dataTask resume];
}


@end
