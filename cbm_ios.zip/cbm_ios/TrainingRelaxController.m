//
//  TrainingRelaxController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "TrainingRelaxController.h"

@interface TrainingRelaxController ()
{
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    int testPkey;
    int testLogPkey;
    //현재 페이지
    int count;
    int firstpg;
    int thirdpg;
    //중복 터치 차단
    int isDoingNetwork;
}
//버튼 관련 변수
@property (weak, nonatomic) IBOutlet UIImageView *RelaxButBack;
@property (weak, nonatomic) IBOutlet UIButton *RelaxBut;

//첫번째 장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxLabel;
@property (weak, nonatomic) IBOutlet UILabel *RelaxLabel2;
@property (weak, nonatomic) IBOutlet UIImageView *RelaxImage;
@property (weak, nonatomic) IBOutlet UILabel *RelaxLabel3;

//세번째 장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxLabel4;
@property (weak, nonatomic) IBOutlet UILabel *RelaxLabel5;

@end

@implementation TrainingRelaxController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    isDoingNetwork=0;
    //TestPkey와 TestLogPkey
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    
    
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_blue.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼관련 설정
    self.RelaxBut.hidden = YES;
    self.RelaxButBack.hidden = YES;
    [self.RelaxBut setTitle:@"" forState:UIControlStateNormal];
    
    //앱 다시 활성활 때 호출하는 함수
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(apWillEnterForeground:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    
    //페이지 및 시간차 관련 변수
    count = 1;
    firstpg = 0;
    thirdpg = 0;
    
    //현재 차수 알아오기
    [self requestCount:testPkey];
    
    //각 페이지 관련 오브젝트 숨기기 및 영상 링크 가져오기
    //첫번째 장면
    {
        self.RelaxImage.hidden = YES;
        self.RelaxLabel3.hidden = YES;
    }
    //두번째 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/relax/1.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay:) name:AVPlayerItemPlaybackStalledNotification object:[player currentItem]];
        playerLayer.hidden = YES;
    }
    //세번째 장면
    {
        //RelaxLabel5 테스트 일부 굵게하고 줄간격 설정
        NSMutableAttributedString* relaxText5 = [[NSMutableAttributedString alloc] initWithString:@"평소에도 불안하거나 긴장되는 일이 있으면\n언제나 ‘말랑말랑 마음풀기’ 알겠죠?😉"];
        [relaxText5 addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(28, 11)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [relaxText5 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, relaxText5.length)];
        [_RelaxLabel5 setAttributedText:relaxText5];
        self.RelaxLabel4.hidden = YES;
        self.RelaxLabel5.hidden = YES;
    }
    //첫번째페이지 시간차 변수 및 함수호출
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(Relax1pageNext:) userInfo:NO repeats:YES];
}

-(void) setUrl:(int)number{
    NSString *numStr = [NSString stringWithFormat:@"%d",number];
    NSString *strUrl = [@"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/relax/" stringByAppendingString:numStr];
    strUrl = [strUrl stringByAppendingString:@".mp4"];
    NSURL *url = [NSURL URLWithString:strUrl];
    player = [AVPlayer playerWithURL:url];
    player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                        selector:@selector(playerItemDidReachEnd:)
                                        name:AVPlayerItemDidPlayToEndTimeNotification
                                        object:[player currentItem]];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay:) name:AVPlayerItemPlaybackStalledNotification object:[player currentItem]];
}
- (IBAction)ActionBut:(id)sender {
    
    switch (count) {
        case 1:
            {
                count++;
                self.RelaxBut.hidden = YES;
                self.RelaxButBack.hidden = YES;
                self.RelaxLabel.hidden = YES;
                self.RelaxLabel2.hidden = YES;
                self.RelaxImage.hidden = YES;
                self.RelaxLabel3.hidden = YES;
                playerLayer.hidden = NO;
                [player play];
                    
                playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
                playerLayer.frame = self.view.bounds;
                float x = 0;
                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                float width = playerLayer.frame.size.width;
                float height = playerLayer.frame.size.height;
                CGRect resizeRect = CGRectMake(x, y, width, height);
                [playerLayer setFrame:resizeRect];
                [self.view.layer addSublayer:playerLayer];
            }
            break;
        case 2:
            {
                count++;
                self.RelaxBut.hidden = YES;
                self.RelaxButBack.hidden = YES;
                playerLayer.hidden = YES;
                self.RelaxLabel4.hidden = NO;
                //세번째페이지 시간차 변수 및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(Relax3pageNext:) userInfo:NO repeats:YES];
            }
            break;
        default:
            if(isDoingNetwork==0)
                [self updateDoneSection:testLogPkey :testPkey];
                //[self.navigationController popViewControllerAnimated:YES];
                break;
    }
}
//동영상 중단 시 호출되는 함수
- (void)replay:(NSNotification *)notification{
    [player play];
    NSLog(@"pause video replay");
}
//동영상 재생 끝난 후 호출되는 함수
- (void)playerItemDidReachEnd:(NSNotification *)notification {
    NSLog(@"Ending");
   
    self.RelaxBut.hidden = NO;
    self.RelaxButBack.hidden = NO;
    
}
//시간차 관련 함수
-(void)Relax1pageNext:(NSTimer*)timer{
    firstpg++;
    if(firstpg==1){
        self.RelaxImage.hidden = NO;
    }
    else if(firstpg ==2){
        self.RelaxLabel3.hidden = NO;
    }
    else{
        self.RelaxBut.hidden = NO;
        self.RelaxButBack.hidden = NO;
    }
    
    if(firstpg>=3){
        [timer invalidate];
    }
}
-(void)Relax3pageNext:(NSTimer*)timer{
    thirdpg++;
    if(thirdpg==1){
        self.RelaxLabel5.hidden = NO;
    }
    else{
        self.RelaxBut.hidden = NO;
        self.RelaxButBack.hidden = NO;
    }
    
    if(thirdpg>=2){
        [timer invalidate];
    }
}
//section update 관련 함수
- (void) updateDoneSection: (int) testLogPkey : (int) testPkey{
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    isDoingNetwork = 1;
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이다.
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey,testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
}
- (void) requestCount: (int) testPkey {
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
   
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_count_test.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    // post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이고
    // 이름은 넣을 때 php 파일에 있는 데이터이름과 동일하게 사용
    NSString *postData = [NSString stringWithFormat:@"testPKey=%d&", testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                    [self.navigationController popToRootViewControllerAnimated:YES];
                }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
                
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData_request_count_test전체차수: %@", content);
                int number = [content intValue];
                [self setUrl:number];
                
                if(number>=5&&number<=41){
                    [self setUrl:number-4];
                }
                 
            }
            
        }];
    [dataTask resume];
}
//홈버튼 누르고 나서 다시 앱이 활성화 할 때 호출되는 함수
- (void) apWillEnterForeground: (NSNotification *)notification{
    NSLog(@"확인");
    if(count==2){
        if(player.timeControlStatus == AVPlayerTimeControlStatusPaused){
            [player play];
        }
    }
}
@end
