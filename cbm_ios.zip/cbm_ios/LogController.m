//
//  LogController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "LogController.h"


@interface LogController () {
    OurSlider *slider2, *slider5;
    
    // 페이지 시간 count 변수 (긍정은 n01, 부정은 n02)
    int page1, page2, page4, page5, page6, page7, page8, page12, page13, page14, page15, page16;
    int page301, page302;
    int page901, page902;
    int page1001, page1002;
    int page1101, page1102;
    int page1701, page1702;
    
    int pageNum; // 진행 중인 페이지 번호, nextBtn case문에서 사용 (긍정은 n01, 부정은 n02)
    int nextpageNum; // 다음에 넘어갈 페이지 번호
    NSString *userName; // 성을 뗀 사용자 이름
    bool isCheck; // 버튼(라디오) 체크 확인
    NSString *emotionString; // 유저가 선택한 감정
    //NSString *emotionStringEx;
    NSArray *emotionArray01; // 긍정
    NSArray *emotionArray02; // 부정
    
    
    //DB 전달값
    int mood1Val, emotionVal;
    int mood2Val;
    NSString *whenText, *whoText, *whereText, *totalText;
    
    int isDoingNetwork; //멀티터치
    int isDoingNetwork2;
}

@end

@implementation LogController

NSUserDefaults * userDefaults; // 로컬에 저장된 정보를 가져올 때 사용하는 변수

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self fitBackgroud]; // 배경 이미지를 화면 크기에 맞게 변경
    [self createSlider]; // 슬라이더 생성 (slider2->mood1, slider5->emotionVal)
    [self cuttingUsername]; // User 이름 가져오기 & 성 떼기
    [self getRecentGrapch]; // 최근 기분 그래프 가져오기

    
    // 페이지 변수 초기화
    page1=0; page2=0;
    page4=0; page5=0; page6=0; page7=0; page8=0;
    page12=0; page13=0; page14=0; page15=0; page16=0;
    
    page301=0; page302 = 0;
    page901=0; page902 = 0;
    page1001=0; page1002 = 0;
    page1101=0; page1102 = 0;
    page1701=0; page1702 = 0;
   
    pageNum = 1; //진행 중인 페이지
    nextpageNum = 8; //다음에 넘어갈 페이지
    
    //db에 전달 값 초기화
    mood1Val = 0;
    emotionVal = 0;
    mood2Val = 0;
    whenText = @"";
    whereText = @"";
    whoText = @"";
    totalText = @"";
    //emotionStringEx = @"example";
    
    isCheck = false;
    isDoingNetwork = 0; //멀티 터치
    isDoingNetwork2 = 0;
    
    //Emotion Array
    emotionArray01 = [NSArray arrayWithObjects: @"긍정적", @"행복한", @"편안한", @"기쁜", @"감사한", @"만족스러운", nil];
    emotionArray02 = [NSArray arrayWithObjects: @"부정적", @"슬픈", @"불안한", @"절망적인", @"화난", @"답답한", @"무서운", @"짜증난", @"우울한", @"공허한", @"걱정스러운", @"수치스러운", nil];
    
    _nextBtn.hidden = YES;
    _nextBtnback.hidden = YES;
    { //page 1
        _page1L1.hidden = YES;
        _page1L2.hidden = YES;
        _page1L3.hidden = YES;
        _page1Img.hidden = NO;
    }
    { //page 2
        _page2L1.hidden = YES;
        _page2L2.hidden = YES;
        slider2.hidden = YES;
    }
    { //page 3 (긍정/부정)
        _page301L1.hidden = YES;
        _page301L2.hidden = YES;
        _page301Blank.hidden = YES;
        [_emotionBtnGroup01 setValue:@(YES) forKey:@"hidden"];
        
        _page302L1.hidden = YES;
        _page302L2.hidden = YES;
        _page302Blank.hidden = YES;
        [_emotionBtnGroup02 setValue:@(YES) forKey:@"hidden"];
    }
    { //page 4
        _page4L1.hidden = YES;
        _page4L2.hidden = YES;
        _page4L3.hidden = YES;
    }
    { //page 5
        _page5L1.hidden = YES;
        slider5.hidden = YES;
    }
    { //page 6
        _page6L1.hidden = YES;
        _recentGraph.hidden = YES;
    }
    { //page 7
        _page7L1.hidden = YES;
        _page7L2.hidden = YES;
        _page7L3.hidden = YES;
        _page7Img.hidden = YES;
    }
    { //page 8
        _page8L1.hidden = YES;
        _page8L2.hidden = YES;
        _page8L3.hidden = YES;
        [_page8BtnGroup setValue:@(YES) forKey:@"hidden"];
    }
    { //page9-01
        _page901L1.hidden = YES;
        _page901L2.hidden = YES;
        _page901L3.hidden = YES;
    }
    { //page10-01
        [_page1001L setValue:@(YES) forKey:@"hidden"];
    }
    { //page11-01
        [_page1101L setValue:@(YES) forKey:@"hidden"];
    }
    { //page9-02
        _page902L1.hidden = YES;
        _page902L2.hidden = YES;
        _page902L3.hidden = YES;
    }
    { //page10-02
        [_page1002L setValue:@(YES) forKey:@"hidden"];
    }
    { //page11-02
        [_page1102L setValue:@(YES) forKey:@"hidden"];
    }
    
    { //page12
        _page12L1.hidden = YES;
        _page12L2.hidden = YES;
    }
    { //page13
        [_page13L setValue:@(YES) forKey:@"hidden"];
        _whenTextView.hidden = YES;
    }
    { //page14
        [_page14L setValue:@(YES) forKey:@"hidden"];
        _whereTextView.hidden = YES;
    }
    { //page15
        [_page15L setValue:@(YES) forKey:@"hidden"];
        _whoTextView.hidden = YES;
    }
    { //page16
        [_page16L setValue:@(YES) forKey:@"hidden"];
        _totalTextView.hidden = YES;
    }
    { //page1701
        _page1701L1.hidden = YES;
        _page1701L2.hidden = YES;
        _page1701L3.hidden = YES;
        _page1701L4.hidden = YES;
        _page1701L5.hidden = YES;
    }
    { //page1702
        _page1702L1.hidden = YES;
        _page1702L2.hidden = YES;
        _page1702L3.hidden = YES;
        _page1702L4.hidden = YES;
    }
    

    

    // Page1  타이머 시작
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage1:) userInfo:NO repeats:YES];

}


// <View Page> - 시간차별로 텍스트 띄우기

//PAGE 1
-(void)ControlPage1:(NSTimer*)timer{
    page1++;
    switch(page1){
        case 1 :
            _page1L1.hidden = NO;
            break;
        case 2:
            _page1L2.hidden = NO;
            break;
        case 4:
            _page1L3.hidden = NO;
            break;
        case 6: {
            _nextBtn.hidden = NO;
            _nextBtnback.hidden = NO;
            [timer invalidate];
            break;
        }
    }
}

//PAGE 2
-(void)ControlPage2 {
    _page2L1.hidden = NO;
    _page2L2.hidden = NO;
    slider2.hidden = NO;
}


//PAGE 3(긍정)
-(void)ControlPage301 {
    _page301L1.hidden = NO;
    _page301L2.hidden = NO;
    _page301Blank.hidden = NO;
    [_emotionBtnGroup01 setValue:@(NO) forKey:@"hidden"];
}

//PAGE 3(부정)
-(void)ControlPage302 {
    _page302L1.hidden = NO;
    _page302L2.hidden = NO;
    _page302Blank.hidden = NO;
    [_emotionBtnGroup02 setValue:@(NO) forKey:@"hidden"];
}

//PAGE 4
-(void)ControlPage4{
    _page4L1.text = [_page4L1.text stringByReplacingOccurrencesOfString:@"사용자" withString:userName];
        
    _page4L2.text = [_page4L2.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
    
    _page4L1.hidden = NO;
    _page4L2.hidden = NO;
    _page4L3.hidden = NO;
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

//PAGE 5
-(void)ControlPage5{
    _page5L1.text = [_page5L1.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
    _page5L1.hidden = NO;
    slider5.hidden = NO;
}

//PAGE 6
-(void)PreControlPage6{
    NSLog(@"save mood2Val : %d", emotionVal);
    _page5L1.hidden = YES;
    slider5.hidden = YES;
            
    _nextBtn.hidden = YES;
    _nextBtnback.hidden = YES;
    
    
    _page6L1.hidden = NO;
    _recentGraph.hidden = NO;
    //시간차로 버튼 나오게 하기
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage6:) userInfo:NO repeats:NO];
    pageNum = 6;
}
-(void)ControlPage6:(NSTimer*)timer{
    
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
    [timer invalidate];
}

//PAGE 7
-(void)ControlPage7{
    _page7L1.text = [_page7L1.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
    
    _page7L1.hidden = NO;
    _page7L2.hidden = NO;
    _page7L3.hidden = NO;
    _page7Img.hidden = NO;
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

//PAGE 8
-(void)ControlPage8{
    _page8L1.text = [_page8L1.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
    
    _page8L1.hidden = NO;
    _page8L2.hidden = NO;
    _page8L3.hidden = NO;
    [_page8BtnGroup setValue:@(NO) forKey:@"hidden"];
}

//---------------------------------------

//PAGE 9(긍정) - 901
-(void)ControlPage901:(NSTimer*)timer{
    page901++;
    switch(page901){
        case 1: {
            _page901L1.text = [_page901L1.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
            NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
            [style setLineSpacing:12];
            [style setAlignment:NSTextAlignmentCenter];
            NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page901L1.text];
            [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
            [_page901L1 setAttributedText: modifyLabel];
            
            _page901L1.hidden = NO;
            break;
        }
        case 3: {
            _page901L2.text = [_page902L2.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
            NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
            [style setLineSpacing:12];
            [style setAlignment:NSTextAlignmentCenter];
            NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page901L2.text];
            [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
            [_page901L2 setAttributedText: modifyLabel];
            _page901L2.hidden = NO;
            break;
        }
        case 5: {
            _page901L3.hidden = NO;
            break;
        }
        case 7:
            _nextBtn.hidden = NO;
            _nextBtnback.hidden = NO;
            [timer invalidate];
            break;
    }
}

//PAGE 10(긍정)
-(void)ControlPage1001 {
    [_page1001L setValue:@(NO) forKey:@"hidden"];
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}


//PAGE 11(긍정)
-(void)ControlPage1101{
    [_page1101L setValue:@(NO) forKey:@"hidden"];
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

//---------------------------------------

//PAGE 9(부정)
-(void)ControlPage902:(NSTimer*)timer{
    page902++;
    switch(page902){
        case 1: {
            _page902L1.text = [_page902L1.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
            NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
            [style setLineSpacing:12];
            [style setAlignment:NSTextAlignmentCenter];
            NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page902L1.text];
            [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
            [_page902L1 setAttributedText: modifyLabel];
            
            _page902L1.hidden = NO;
        break;
        }
        case 3: {
            _page902L2.text = [_page902L2.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
            NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
            [style setLineSpacing:12];
            [style setAlignment:NSTextAlignmentCenter];
            NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page902L2.text];
            [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
            [_page902L2 setAttributedText: modifyLabel];
            _page902L2.hidden = NO;
            break;
        }
        case 5: {
            _page902L3.hidden = NO;
            break;
        }
        case 7:
            _nextBtn.hidden = NO;
            _nextBtnback.hidden = NO;
            [timer invalidate];
            break;
        }
}


//PAGE 10(부정)
-(void)ControlPage1002 {
    [_page1002L setValue:@(NO) forKey:@"hidden"];
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

//PAGE 11(부정)
-(void)ControlPage1102{
    [_page1102L setValue:@(NO) forKey:@"hidden"];
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

//---------------------------------------

//PAGE 12
-(void)ControlPage12:(NSTimer*)timer{
    page12++;
    switch(page12){
        case 1: {
            _page12L1.hidden = NO;
            break;
    }
        case 3: {
            _page12L2.text = [_page12L2.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
            NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
            [style setLineSpacing:12];
            [style setAlignment:NSTextAlignmentCenter];
            NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page12L2.text];
            [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
            NSString * research = @"언제 어디서 누구와 같이 있었던 상황이었는지";
            NSUInteger result = [_page12L2.text rangeOfString:research options:NSCaseInsensitiveSearch].location;
            [modifyLabel addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(result, research.length)];
            [_page12L2 setAttributedText: modifyLabel];
            _page12L2.hidden = NO;
            break;
    }
        case 5:
            _nextBtn.hidden = NO;
        _nextBtnback.hidden = NO;
            [timer invalidate];
            break;
    }
}

//PAGE 13
-(void)ControlPage13{
    _whenTextView.layer.cornerRadius = 10;
    
    [_page13L setValue:@(NO) forKey:@"hidden"];
    _whenTextView.hidden = NO;
    //when text view 입력 확인
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textViewDidChange:)
                                                     name:UITextViewTextDidChangeNotification
                                                   object:_whenTextView];
}

//PAGE 14
-(void)ControlPage14{
    _whereTextView.layer.cornerRadius = 10;
    
    [_page14L setValue:@(NO) forKey:@"hidden"];
    _whereTextView.hidden = NO;
    //where text view 입력 확인
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textViewDidChange:)
                                                     name:UITextViewTextDidChangeNotification
                                                   object:_whereTextView];
}

//PAGE 15
-(void)ControlPage15{
    _whoTextView.layer.cornerRadius = 10;
    
    [_page15L setValue:@(NO) forKey:@"hidden"];
    _whoTextView.hidden = NO;
    //who text view 입력 확인
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textViewDidChange:)
                                                     name:UITextViewTextDidChangeNotification
                                                   object:_whoTextView];
}

//PAGE 16
-(void)ControlPage16{
    _totalTextView.layer.cornerRadius = 10;
    
    [_page16L setValue:@(NO) forKey:@"hidden"];
    _totalTextView.hidden = NO;
    //total text view 입력 확인
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(textViewDidChange:)
                                                     name:UITextViewTextDidChangeNotification
                                                   object:_totalTextView];
}

//PAGE 17(긍정)
    -(void)ControlPage1701:(NSTimer*)timer{
        page1701++;
        switch(page1701){
            case 1: {
                NSString * userName_trim = [userName stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                _page1701L1.text = [_page1701L1.text stringByReplacingOccurrencesOfString:@"사용자" withString:userName_trim];
                _page1701L1.text = [_page1701L1.text stringByReplacingOccurrencesOfString:@"what" withString:totalText];
                
                //what이 길어질 것을 대비하여 동적으로 문자간격 설정
                NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
                [style setLineSpacing:12];
                [style setAlignment:NSTextAlignmentCenter];
                NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page1701L1.text];
                [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
                [_page1701L1 setAttributedText:modifyLabel];
                
                _page1701L2.text = [_page1701L2.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
                
                _page1701L1.hidden = NO;
                _page1701L2.hidden = NO;
                break;
            }
            case 3: {
                _page1701L3.text = [_page1701L3.text stringByReplacingOccurrencesOfString:@"사용자" withString:userName];
                
                _page1701L4.text = [_page1701L4.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
                
                _page1701L3.hidden = NO;
                _page1701L4.hidden = NO;
                break;
            }
            case 5: {
                _page1701L5.hidden = NO;
                break;
            }
            case 7:
                _nextBtn.hidden = NO;
                _nextBtnback.hidden = NO;
                [timer invalidate];
                break;
        }
    }

//PAGE 17(부정)
    -(void)ControlPage1702:(NSTimer*)timer{
        page1702++;
        switch(page1702){
            case 1: {
                
                _page1702L1.text = [_page1702L1.text stringByReplacingOccurrencesOfString:@"사용자" withString:userName];
                
                _page1702L1.text = [_page1702L1.text stringByReplacingOccurrencesOfString:@"what" withString:totalText];
                _page1702L1.text = [_page1702L1.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
                
                NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
                [style setLineSpacing:12];
                [style setAlignment:NSTextAlignmentCenter];
                NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page1702L1.text];
                [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
                [_page1702L1 setAttributedText:modifyLabel];
                _page1702L1.hidden = NO;
                break;
            }
            case 4: {
                _page1702L2.text = [_page1702L2.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
                NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
                [style setLineSpacing:12];
                [style setAlignment:NSTextAlignmentCenter];
                NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page1702L2.text];
                [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
                [_page1702L2 setAttributedText:modifyLabel];
                _page1702L2.hidden = NO;
                break;
            }
            case 7: {
                _page1702L3.text = [_page1702L3.text stringByReplacingOccurrencesOfString:@"선택한" withString:emotionString];
                NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc]init];
                [style setLineSpacing:12];
                [style setAlignment:NSTextAlignmentCenter];
                NSMutableAttributedString *modifyLabel = [[NSMutableAttributedString alloc] initWithString:_page1702L3.text];
                [modifyLabel addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, modifyLabel.length)];
                [_page1702L3 setAttributedText:modifyLabel];
                _page1702L3.hidden = NO;
                break;
            }
            case 9: {
                _page1702L4.hidden = NO;
                break;
            }
            case 11: {
                _nextBtn.hidden = NO;
                _nextBtnback.hidden = NO;
                [timer invalidate];
                break;
            }
        }
    }


- (IBAction)nextBtn:(id)sender {

    switch(pageNum){
        case 1:{
             //page1->2
            NSLog(@"Page1 to 2");
            _page1L1.hidden = YES;
            _page1L2.hidden = YES;
            _page1L3.hidden = YES;
            _page1Img.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            [self ControlPage2];
            pageNum = 2;
        
            break;
        }
        case 2: {
             //page2->3a/3b
            NSLog(@"Page2 to 3");
            
            //슬라이더 값 저장
            mood1Val = (int)slider2.tag;
            NSLog(@"save mood2Val : %d, %d", (int)slider2.tag, mood1Val);
            if(mood1Val == 0){
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"다시 선택" message:@"0을 제외한 값을 선택해주세요." preferredStyle: UIAlertControllerStyleActionSheet];
                UIAlertController *ok = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];
                }];
                [alert addAction:ok];
                [self presentViewController:alert animated:YES completion:nil];
            } else if(mood1Val > 0 ) {
                //긍정
                _page2L1.hidden = YES;
                _page2L2.hidden = YES;
                slider2.hidden = YES;
                
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                [self ControlPage301];
                pageNum = 301;
                
            } else if(mood1Val < 0 ){
                //부정
                _page2L1.hidden = YES;
                _page2L2.hidden = YES;
                slider2.hidden = YES;
                
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                [self ControlPage302];
                pageNum = 302;
            }
            break;
        }
        case 301: {
            //긍정, page3->4
            NSLog(@"Page3 to 4");
            _page301L1.hidden = YES;
            _page301L2.hidden = YES;
            _page301Blank.hidden = YES;
            [_emotionBtnGroup01 setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            
            pageNum = 4;
            [self ControlPage4];
        
            break;
        }
        case 302: {
            //부정, page3->4
            NSLog(@"Page3 to 4");
            _page302L1.hidden = YES;
            _page302L2.hidden = YES;
            _page302Blank.hidden = YES;
            [_emotionBtnGroup02 setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            
            pageNum = 4;
            [self ControlPage4];
            
            break;
        }
        
        case 4: {
            //page4->5
            NSLog(@"Page4 to 5");
            _page4L1.hidden = YES;
            _page4L2.hidden = YES;
            _page4L3.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 5;
            [self ControlPage5];
        
            break;
        }
        case 5: {
            //page5->6
            //슬라이더 값 저장
            NSLog(@"Page5 to 6");
            emotionVal = (int)slider5.tag;
            //값 전달하고 최근 기분 그래프 나오게 하기
            [self updateModeAndEmotion];
            
            
        
            break;
        }
            
        case 6: {
            //page6->7
            NSLog(@"Page6 to 7");
            _page6L1.hidden = YES;
            _recentGraph.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            [self ControlPage7];
            pageNum = 7;
        
            break;
        }
            
        case 7: {
            //page7->8
            NSLog(@"Page7 to 8");
            _page7L1.hidden = YES;
            _page7L2.hidden = YES;
            _page7L3.hidden = YES;
            _page7Img.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            [self ControlPage8];
            pageNum = 8;
            
            break;
        }
            
        case 8: {
            //page8->901/902
            _page8L1.hidden = YES;
            _page8L2.hidden = YES;
            _page8L3.hidden = YES;
            [_page8BtnGroup setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            
            //선택 값에 따라서 넘어가는 페이지가 다름
            switch(nextpageNum){
                case 8: //나중에 지우기
                case 901:{
                    NSLog(@"page 8 to 9(긍정예시)");
                    pageNum = 901;
                    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage901:) userInfo:NO repeats:YES];
                    
                    break;
                }
                case 902:{
                    NSLog(@"page 8 to 9(부정예시)");
                    pageNum = 902;
                    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage902:) userInfo:NO repeats:YES];

                    break;
                }
                case 13:{
                    NSLog(@"page 8 to 13(예시X)");
                    pageNum = 13;
                    [self ControlPage13];
                    break;
                }
                default: {
                    NSLog(@"error, pageNum :%d", pageNum);
                    break;
                }
            }
        
            break;
        }
        
        //=====================================
                
        case 901: {
            //page901->1001
            NSLog(@"Page9(긍정) to 10(긍정)");
            _page901L1.hidden = YES;
            _page901L2.hidden = YES;
            _page901L3.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 1001;
            [self ControlPage1001];
            
            break;
        }
            
        case 1001: {
            //page1001->1101
            NSLog(@"Page10(긍정) to 11(긍정)");
            [_page1001L setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 1101;
            [self ControlPage1101];
            
            break;
        }
            
        case 1101: {
            //page1101->12
            NSLog(@"Page11(긍정) to 12");
            [_page1101L setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 12;
            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage12:) userInfo:NO repeats:YES];
            break;
        }
                
        //=====================================
                
        case 902:
        {
            //page902->1002
            NSLog(@"Page9(부정) to 10(부정)");
            _page902L1.hidden = YES;
            _page902L2.hidden = YES;
            _page902L3.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 1002;
            [self ControlPage1002];
            
            break;
        }

        case 1002: {
            //page1002->1102
            NSLog(@"Page10(부정) to 11(부정)");
            [_page1002L setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 1102;
            [self ControlPage1102];
            
            break;
        }
                
        case 1102: {
            //page1102->12
            NSLog(@"Page11(긍정) to 12");
            [_page1102L setValue:@(YES) forKey:@"hidden"];
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 12;
            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage12:) userInfo:NO repeats:YES];
            break;
        }
                
        //=====================================
                
        case 12: {
            //page12->13
            NSLog(@"Page12 to 13");
            _page12L1.hidden = YES;
            _page12L2.hidden = YES;
            
            _nextBtn.hidden = YES;
            _nextBtnback.hidden = YES;
            pageNum = 13;
            [self ControlPage13];
            
            break;
        }
            
        case 13: {
            _whenTextView.text = [_whenTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; //앞뒤로 있는 공백과 텝 그리고 엔터까지 제거
            //page13->14
            if([_whenTextView.text isEqual:@""]){ // textview가 빈칸일 경우 alert 띄움
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
                [alert addAction:closeAction];
                [self presentViewController:alert animated:YES completion:nil];
            } else {
                NSLog(@"Page13 to 14");
                whenText = _whenTextView.text; //db에 넘길 데이터
                
                [_page13L setValue:@(YES) forKey:@"hidden"];
                _whenTextView.hidden = YES;
                
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                pageNum = 14;
                [self ControlPage14];
            }
            break;
        }
                
        case 14: {
            _whereTextView.text = [_whereTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; //앞뒤로 있는 공백과 텝 그리고 엔터까지 제거
            //page14->15
            if([_whereTextView.text isEqual:@""]){ // textview가 빈칸일 경우 alert 띄움
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
                [alert addAction:closeAction];
                [self presentViewController:alert animated:YES completion:nil];
            } else {
                NSLog(@"Page14 to 15");
                whereText = _whereTextView.text; //db에 넘길 데이터
                
                [_page14L setValue:@(YES) forKey:@"hidden"];
                _whereTextView.hidden = YES;
                
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                pageNum = 15;
                [self ControlPage15];
            }
            break;
        }
            
        case 15: {
            _whoTextView.text = [_whoTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; //앞뒤로 있는 공백과 텝 그리고 엔터까지 제거
            //page15->16
            if([_whoTextView.text isEqual:@""]){ // textview가 빈칸일 경우 alert 띄움
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
                [alert addAction:closeAction];
                [self presentViewController:alert animated:YES completion:nil];
            } else {
                NSLog(@"Page15 to 16");
                whoText = _whoTextView.text; //db에 넘길 데이터
                
                [_page15L setValue:@(YES) forKey:@"hidden"];
                _whoTextView.hidden = YES;
                
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                pageNum = 16;
                [self ControlPage16];
            }
            break;
        }
                
        case 16: {
            _totalTextView.text = [_totalTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; //앞뒤로 있는 공백과 텝 그리고 엔터까지 제거
            //page16->17(긍정/부정)
            if([_totalTextView.text isEqual:@""]){ // textview가 빈칸일 경우 alert 띄움
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
                [alert addAction:closeAction];
                [self presentViewController:alert animated:YES completion:nil];
            } else {
                totalText = _totalTextView.text; //db에 넘길 데이터
                
                [_page16L setValue:@(YES) forKey:@"hidden"];
                _totalTextView.hidden = YES;
                
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                
                if(mood1Val>0){
                    //긍정 마무리
                    pageNum = 1701;
                    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage1701:) userInfo:NO repeats:YES];
                } else {
                    //부정 마무리
                    pageNum = 1702;
                    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(ControlPage1702:) userInfo:NO repeats:YES];
                }
            }
            break;
        }
                
            case 1701:
            { //page17a->home
                _page1701L1.hidden = YES;
                _page1701L2.hidden = YES;
                _page1701L3.hidden = YES;
                _page1701L4.hidden = YES;
                _page1701L5.hidden = YES;
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                pageNum = 1;
                if(isDoingNetwork==0){
                    [self updateLog]; //DB에 데이터 전달
                    //[self updateCurrentProgress]; //DB current +1
                    //[self.navigationController popViewControllerAnimated:YES];
                    }
            }
                break;
                
            case 1702:
            { //page17b->home
                _page1702L1.hidden = YES;
                _page1702L2.hidden = YES;
                _page1702L3.hidden = YES;
                _page1702L4.hidden = YES;
                _nextBtn.hidden = YES;
                _nextBtnback.hidden = YES;
                pageNum = 1;
                if(isDoingNetwork==0){
                    [self updateLog]; //DB에 데이터 전달
                    //[self updateCurrentProgress]; //DB current +1
                    //[self.navigationController popViewControllerAnimated:YES];
                    }
            }
                break;
        }
}


// Emotion Button (긍정 group)
- (IBAction)emotionTouch01:(UIButton *)sender01 {
    if(isCheck){
        for (UIButton* button in _emotionBtnGroup01){
            [button setBackgroundImage:[UIImage imageNamed:@"log_emotion2.png"] forState:UIControlStateNormal];
            button.selected = false;
        }
        sender01.selected = true;
        [sender01 setBackgroundImage:[UIImage imageNamed:@"log_emotion1.png"] forState:UIControlStateNormal];
    } else {
        sender01.selected = true;
        [sender01 setBackgroundImage:[UIImage imageNamed:@"log_emotion1.png"] forState:UIControlStateNormal];
        isCheck = true;
    }
    mood2Val = (int)[_emotionBtnGroup01 indexOfObject:sender01]+1;
    emotionString = [emotionArray01 objectAtIndex:mood2Val];
    NSLog(@"emotion value(01) : %d, %@", mood2Val, emotionString);
    
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

- (IBAction)emotionTouch02:(UIButton *)sender02 {
    if(isCheck){
        for (UIButton* button in _emotionBtnGroup02){
            [button setBackgroundImage:[UIImage imageNamed:@"log_emotion2.png"] forState:UIControlStateNormal];
            button.selected = false;
        }
        sender02.selected = true;
        [sender02 setBackgroundImage:[UIImage imageNamed:@"log_emotion1.png"] forState:UIControlStateNormal];
    } else {
        sender02.selected = true;
        [sender02 setBackgroundImage:[UIImage imageNamed:@"log_emotion1.png"] forState:UIControlStateNormal];
        isCheck = true;
    }
    mood2Val = (int)[_emotionBtnGroup02 indexOfObject:sender02]+1;
    emotionString = [emotionArray02 objectAtIndex:mood2Val];
    NSLog(@"emotion value(02) : %d, %@", mood2Val, emotionString);
    
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

// Page 8 에서의 선택 ( 네 / 예시가 필요합니다 )
- (IBAction)page8Btn:(UIButton *)sender {
    if(isCheck){
        for (UIButton* button in _page8BtnGroup){
            [button setBackgroundImage:[UIImage imageNamed:@"log_next2.png"] forState:UIControlStateNormal];
            button.selected = false;
        }
        sender.selected = true;
        [sender setBackgroundImage:[UIImage imageNamed:@"log_next1.png"] forState:UIControlStateNormal];
    } else {
        sender.selected = true;
        [sender setBackgroundImage:[UIImage imageNamed:@"log_next1.png"] forState:UIControlStateNormal];
        isCheck = true;
    }
    
    switch((int)[_page8BtnGroup indexOfObject:sender]){
        case 0: {
            // [ 네 ]
            nextpageNum = 13;
            NSLog(@"8p --> %dp / mood :%d", nextpageNum, mood1Val);
            break;
        }
        case 1: {
            // [ 예시가 필요합니다 ]
            if(mood1Val >0){
                //긍정의 예시
                nextpageNum = 901;
                NSLog(@"8p --> %dp / mood :%d", nextpageNum, mood1Val);
            } else {
                //부정의 예시
                nextpageNum = 902;
                NSLog(@"8p --> %dp / mood :%d", nextpageNum, mood1Val);
            }
            break;
        }
            
        default:{
            NSLog(@"error, mood1Val :%d | pageNum :%d", mood1Val, nextpageNum);
            break;
        }
    }
    
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}

// 입력 창에 입력 시 넘어가기 버튼 띄우기
- (void)textViewDidChange:(NSNotification *)notification{
    //NSLog(@"TextView did Change");
    _nextBtn.hidden = NO;
    _nextBtnback.hidden = NO;
}


// WebView 생성 (최근 기분 그래프)
- (void)getRecentGrapch {
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://healingmindcenter.com/cbm_app/cbm_api/cbm_graph.php"]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    //&으로 분리되고, "=" 기호로 값과 키를 연결하는 key-value tuple로 인코딩되는 값(HTML Form형태)- ContentType으로 넘김
    int userPkey = (int)[userDefaults integerForKey:@"UserPKey"];
    int groupType = (int)[userDefaults integerForKey:@"GroupType"];
    NSString *body = [NSString stringWithFormat:@"user_id=%d&type=%d", userPkey, groupType];
    NSData *bodyData = [body dataUsingEncoding:NSUTF8StringEncoding];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:bodyData];
    [_recentGraph setTranslatesAutoresizingMaskIntoConstraints:false];
    NSLog(@"%@", request);
    [_recentGraph loadRequest:request];
    
}

// WebView 크기지정





// Slider 생성
- (void)createSlider {
    //slider관련 action함수는 touchesBegan CGRectMake은 x,y,width,height이며 width와 height,x 고정하고 y축으로 위치 잡기
    slider2 = [[OurSlider alloc] initWithFrame:CGRectMake(0, UIScreen.mainScreen.bounds.size.height*0.40, UIScreen.mainScreen.bounds.size.width, 100)];
    //example hax ffdbfc -> red: 0xff green: 0xdb blue: 0xfc
    [slider2 setView:0xe1 green:0xc2 blue:0xe2];
    //slider값 사용시 slider.tag로 하면 된다.
    [self.view addSubview:slider2];
    //slider밑에 라벨할 글 array하기
    NSArray *textArray2=[NSArray arrayWithObjects:@"매우 기분이 나쁜",@"",@"",@"",@"",@"",@"",@"",@"",@"",@"매우 기분이 좋은",nil];
    //textArray에 값을 넣고 titleNameType지정하기(titleNameType - 0:textArray가 slider 아래 1:textArray가 slider 위)
    [slider2 setPoint:-5 endNum:5 textArray:textArray2 titleNameType:1];
    //slider2.hidden = YES;
    
    slider5 = [[OurSlider alloc] initWithFrame:CGRectMake(0, UIScreen.mainScreen.bounds.size.height*0.40, UIScreen.mainScreen.bounds.size.width, 100)];
    [slider5 setView:0xe1 green:0xc2 blue:0xe2];
    [self.view addSubview:slider5];
    NSArray *textArray5=[NSArray arrayWithObjects:@"매우 약하게 느낌",@"",@"",@"",@"",@"",@"",@"",@"",@"매우 강하게 느낌",nil];
    [slider5 setPoint:1 endNum:10 textArray:textArray5 titleNameType:1];
    //slider5.hidden = YES;
}


// Slider Action Listener
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
    UITouch *touch = [touches anyObject];
    //printf("value: %d\n",(int)slider.tag);
    NSMutableArray *pointArray2 = slider2.getView;
    int len2 = (int)pointArray2.count;
    
    NSMutableArray *pointArray5 = slider5.getView;
    int len5 = (int)pointArray5.count;
    
    
    for(int i=0;i<len2;i++){
        if(pointArray2[i]==touch.view){
            NSLog(@"Slider 2 touch action");
            _nextBtn.hidden = NO;
            _nextBtnback.hidden = NO;
            break;
        }
    }
    
    for(int i=0;i<len5;i++){
        if(pointArray5[i]==touch.view){
            NSLog(@"Slider 5 touch action");
            _nextBtn.hidden = NO;
            _nextBtnback.hidden = NO;
            break;
        }
    }
}

- (void)cuttingUsername {
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userFullname =[userDefaults objectForKey:@"UserName"];
    NSLog(@"%@님 접근",userFullname);
    // 이름이 2글자 이상일 경우에만 성 제거
    if([userFullname length] >= 2){
        userName = [userFullname substringFromIndex : 1];
    } else if([userFullname length] == 1){
        userName = userFullname;
    } else {
        userName = @"user";
    }
    NSLog(@"반갑습니다 %@님", userName);
}

// 디바이스에 맞춰 배경이 꽉 차도록 설정
- (void)fitBackgroud {
    UIImage *image = [UIImage imageNamed:@"back_pink.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
}

// DB에 저장 - mood1, mood2, emotion, when, who, where, total
- (void) updateLog {
    isDoingNetwork = 1;
    
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];

    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/update_log.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];

    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];

    //num : %d, text : %@
    NSString *postData = [NSString stringWithFormat:@"pkey=%d&testPkey=%d&mood1=%d&mood2=%d&emotion=%d&when=%@&who=%@&where=%@&total=%@", testLogPkey, testPkey, mood1Val, mood2Val, emotionVal, whenText, whoText, whereText, totalText];
    //NSLog(@"pkey=%d &testPkey=%d &mood1=%d &mood2=%d &emotion=%d &when=%@ &who=%@ &where=%@ &total=%@", testLogPkey, testPkey, mood1Val, mood2Val, emotionVal, whenText, whoText, whereText, totalText);

    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                if(self->isDoingNetwork==1)
                    self->isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if(isDoingNetwork==1){
                    if([content intValue] == 0)
                        [self updateCurrentProgress];
                    else{
                        isDoingNetwork = 0;
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];   }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                    }
                }
            }
        } ];
    [dataTask resume];
}

- (void) updateModeAndEmotion{
    isDoingNetwork2 = 1;
    
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];

    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/update_log.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];

    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];

    //num : %d, text : %@
    NSString *postData = [NSString stringWithFormat:@"pkey=%d&testPkey=%d&mood1=%d&mood2=%d&emotion=%d&when=%@&who=%@&where=%@&total=%@", testLogPkey, testPkey, mood1Val, mood2Val, emotionVal, whenText, whoText, whereText, totalText];
    //NSLog(@"pkey=%d &testPkey=%d &mood1=%d &mood2=%d &emotion=%d &when=%@ &who=%@ &where=%@ &total=%@", testLogPkey, testPkey, mood1Val, mood2Val, emotionVal, whenText, whoText, whereText, totalText);

    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                if(self->isDoingNetwork2==1)
                    self->isDoingNetwork2 = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if(isDoingNetwork2==1){
                    if([content intValue] == 0){
                        [self getRecentGrapch];
                        [self PreControlPage6];
                    }
                    else{
                        isDoingNetwork2 = 0;
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];   }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                    }
                }
            }
        } ];
    [dataTask resume];
}


//끝났음을 알리는 DB_CurrentProgress 1 증가
- (void) updateCurrentProgress{
    isDoingNetwork = 2;
    
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    int testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    int testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey, testPkey];
    
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                if(self->isDoingNetwork==2)
                    self->isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if(isDoingNetwork==2){
                    if([content intValue] == 0)
                        [self.navigationController popViewControllerAnimated:YES];
                    else{
                        isDoingNetwork = 0;
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                        UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                            [alert dismissViewControllerAnimated:YES completion:nil];   }];
                        [alert addAction:cancel];
                        [self presentViewController:alert animated:YES completion:nil];
                    }
                }
            }
    } ];
    [dataTask resume];
}

//if([_goalText.text isEqual:@""]){ // goalText 입력 안 했을 시 alert 띄움
//        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"알림" message:@"내용을 입력하세요." preferredStyle:UIAlertControllerStyleAlert];
//        UIAlertAction *closeAction = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleCancel handler:nil];
//        [alert addAction:closeAction];
//        [self presentViewController:alert animated:YES completion:nil];
//}
//else{

@end
