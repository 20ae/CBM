//
//  LogController.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>
#import "OurSlider.h"

NS_ASSUME_NONNULL_BEGIN

@interface LogController : UIViewController <WKNavigationDelegate,WKUIDelegate>

@property (strong, nonatomic) IBOutlet UIButton *nextBtn;
@property (strong, nonatomic) IBOutlet UIImageView *nextBtnback;

//page1
@property (strong, nonatomic) IBOutlet UILabel *page1L1;
@property (strong, nonatomic) IBOutlet UILabel *page1L2;
@property (strong, nonatomic) IBOutlet UILabel *page1L3;
@property (strong, nonatomic) IBOutlet UIImageView *page1Img;

//page2
@property (strong, nonatomic) IBOutlet UILabel *page2L1;
@property (strong, nonatomic) IBOutlet UILabel *page2L2;

//page3
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *emotionBtnGroup01;
@property (strong, nonatomic) IBOutlet UILabel *page301L1;
@property (strong, nonatomic) IBOutlet UILabel *page301Blank;
@property (strong, nonatomic) IBOutlet UILabel *page301L2;

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *emotionBtnGroup02;
@property (strong, nonatomic) IBOutlet UILabel *page302L1;
@property (strong, nonatomic) IBOutlet UILabel *page302L2;
@property (strong, nonatomic) IBOutlet UILabel *page302Blank;

//page4
@property (strong, nonatomic) IBOutlet UILabel *page4L1;
@property (strong, nonatomic) IBOutlet UILabel *page4L2;
@property (strong, nonatomic) IBOutlet UILabel *page4L3;

//page5
@property (strong, nonatomic) IBOutlet UILabel *page5L1;

//page6
@property (strong, nonatomic) IBOutlet UILabel *page6L1;
@property (strong, nonatomic) IBOutlet WKWebView *recentGraph;

//page7
@property (strong, nonatomic) IBOutlet UILabel *page7L1;
@property (strong, nonatomic) IBOutlet UILabel *page7L2;
@property (strong, nonatomic) IBOutlet UILabel *page7L3;
@property (strong, nonatomic) IBOutlet UIImageView *page7Img;

//page8
@property (strong, nonatomic) IBOutlet UILabel *page8L1;
@property (strong, nonatomic) IBOutlet UILabel *page8L2;
@property (strong, nonatomic) IBOutlet UILabel *page8L3;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *page8BtnGroup;

//page901
@property (weak, nonatomic) IBOutlet UILabel *page901L1;
@property (weak, nonatomic) IBOutlet UILabel *page901L2;
@property (weak, nonatomic) IBOutlet UILabel *page901L3;

//page1001
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page1001L;

//page1101
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page1101L;

//=========

//page902
@property (weak, nonatomic) IBOutlet UILabel *page902L1;
@property (weak, nonatomic) IBOutlet UILabel *page902L2;
@property (weak, nonatomic) IBOutlet UILabel *page902L3;

//page1002
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page1002L;

//page1102
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page1102L;

//=========

//page12
@property (weak, nonatomic) IBOutlet UILabel *page12L1;
@property (weak, nonatomic) IBOutlet UILabel *page12L2;

//page13
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page13L;
@property (weak, nonatomic) IBOutlet UITextView *whenTextView;

//page14
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page14L;
@property (weak, nonatomic) IBOutlet UITextView *whereTextView;

//page15
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page15L;
@property (weak, nonatomic) IBOutlet UITextView *whoTextView;

//page16
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *page16L;
@property (weak, nonatomic) IBOutlet UITextView *totalTextView;

//page1701
@property (weak, nonatomic) IBOutlet UILabel *page1701L1;
@property (weak, nonatomic) IBOutlet UILabel *page1701L2;
@property (weak, nonatomic) IBOutlet UILabel *page1701L3;
@property (weak, nonatomic) IBOutlet UILabel *page1701L4;
@property (weak, nonatomic) IBOutlet UILabel *page1701L5;

//page1702
@property (weak, nonatomic) IBOutlet UILabel *page1702L1;
@property (weak, nonatomic) IBOutlet UILabel *page1702L2;
@property (weak, nonatomic) IBOutlet UILabel *page1702L3;
@property (weak, nonatomic) IBOutlet UILabel *page1702L4;

@end

NS_ASSUME_NONNULL_END
