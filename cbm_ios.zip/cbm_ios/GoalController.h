//
//  GoalController.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface GoalController : UIViewController <NSURLSessionDataDelegate>

// next 버튼
@property (weak, nonatomic) IBOutlet UIButton *goalNextBtn;
@property (weak, nonatomic) IBOutlet UIImageView *goalNextBtn_Back;


- (IBAction)btnClick:(UIButton *)sender;

// 목표세우기 1page
@property (weak, nonatomic) IBOutlet UILabel *goalLabel1_1;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel1_2;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel1_3;

// 목표세우기 2page
@property (weak, nonatomic) IBOutlet UILabel *goalLabel2_1;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel2_2;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel2_3;

// 목표세우기 3page
@property (weak, nonatomic) IBOutlet UILabel *goalLabel3_1;

@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *radioButtons;

- (IBAction)touchRadioButton:(UIButton *)sender;

// 목표세우기 4page
@property (weak, nonatomic) IBOutlet UILabel *goalLabel4_1;

@property (weak, nonatomic) IBOutlet UIButton *goalYesBtn;
@property (weak, nonatomic) IBOutlet UIButton *goalNoBtn;
- (IBAction)touchYesBtn:(UIButton *)sender;

- (IBAction)touchNoBtn:(UIButton *)sender;


// 목표세우기 5page(Yes 선택)

@property (weak, nonatomic) IBOutlet UILabel *goalLabel5_1;
@property (weak, nonatomic) IBOutlet UITextView *goalText;

// 목표세우기 6page(Yes 선택2)

@property (weak, nonatomic) IBOutlet UILabel *goalLabel6_1;
@property (weak, nonatomic) IBOutlet UILabel *goalLabel6_2;

- (void) updateGoal:(int) goal goalText : (NSString *) goalText;

// 목표세우기 7page(No 선택)
@property (weak, nonatomic) IBOutlet UILabel *goalLabel7_1;

- (void) updateCurrentProgress;

// 레이블을 띄워주는 함수
-(void) visibleLabel:(UILabel *)label;

// 버튼을 띄워주는 함수
-(void)visibleBtn:(UIButton *)button;

// 버튼 배경을 띄워주는 함수
-(void)visibleBtnBack:(UIImageView *)image;

// goalLabel2_2의 text를 반환해주는 함수 (성을 제외한 이름을 포함한 문장)
-(NSString *)getLabelText;

@end

NS_ASSUME_NONNULL_END
