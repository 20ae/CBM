//
//  QnAController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "QnAController.h"

@interface QnAController (){
    int count;
}
@property (weak, nonatomic) IBOutlet UIButton *QnAButton1;
@property (weak, nonatomic) IBOutlet UILabel *Answer1;

@property (weak, nonatomic) IBOutlet UIButton *QnAButton2;
@property (weak, nonatomic) IBOutlet UIButton *QnAButtonLabel2;
@property (weak, nonatomic) IBOutlet UILabel *Answer2;

@property (weak, nonatomic) IBOutlet UIButton *QnAButton3;
@property (weak, nonatomic) IBOutlet UIButton *QnAButtonLabel3;
@property (weak, nonatomic) IBOutlet UILabel *Answer3;

@property (weak, nonatomic) IBOutlet UIButton *QnAButton4;
@property (weak, nonatomic) IBOutlet UIButton *QnAButtonLabel4;
@property (weak, nonatomic) IBOutlet UILabel *Answer4;

@property (weak, nonatomic) IBOutlet UIButton *QnAButton5;
@property (weak, nonatomic) IBOutlet UIButton *QnAButtonLabel5;

@property (weak, nonatomic) IBOutlet UIButton *QnAButton6;
@property (weak, nonatomic) IBOutlet UIButton *QnAButtonLabel6;
@property (weak, nonatomic) IBOutlet UILabel *Answer5;

@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonImage1;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonImage2;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonImage3;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonImage4;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonImage5;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonImage6;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonLabelImage2;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonLabelImage3;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonLabelImage4;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonLabelImage5;
@property (weak, nonatomic) IBOutlet UIImageView *QnAButtonLabelImage6;



@end

@implementation QnAController

@synthesize QnAButton2;
@synthesize QnAButtonLabel2;
@synthesize QnAButton4;
@synthesize QnAButtonLabel4;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    count = 0;
    //네비게이션 제거
    self.navigationController.navigationBar.hidden=YES;
    
    //배경
    UIImage *bgImage = [UIImage imageNamed:@"back_report.png"];
    UIImageView *bgImageView = [[UIImageView alloc] initWithImage:bgImage];
    bgImageView.frame = [[UIScreen mainScreen]bounds];
    bgImageView.contentMode = UIViewContentModeScaleToFill;
    bgImageView.alpha = 1.0;
    [self.view addSubview:bgImageView];
    [self.view sendSubviewToBack:bgImageView];
    
    //버튼 줄바꿈 추가하기
    QnAButton2.titleLabel.numberOfLines=3;
    QnAButtonLabel2.titleLabel.numberOfLines=3;
    QnAButton4.titleLabel.numberOfLines=2;
    QnAButtonLabel4.titleLabel.numberOfLines=2;
    
    self.Answer1.hidden = YES;
    self.Answer2.hidden = YES;
    self.Answer3.hidden = YES;
    self.Answer4.hidden = YES;
    self.Answer5.hidden = YES;
    
    self.QnAButtonLabel2.hidden = YES;
    self.QnAButtonLabel3.hidden = YES;
    self.QnAButtonLabel4.hidden = YES;
    self.QnAButtonLabel5.hidden = YES;
    self.QnAButtonLabel6.hidden = YES;
    self.QnAButtonLabelImage2.hidden = YES;
    self.QnAButtonLabelImage3.hidden = YES;
    self.QnAButtonLabelImage4.hidden = YES;
    self.QnAButtonLabelImage5.hidden = YES;
    self.QnAButtonLabelImage6.hidden = YES;
}

- (IBAction)backButtonClicked:(UIButton *)sender {
    if(count==0){
        [self.navigationController popViewControllerAnimated:YES];
    }else {
        count = 0;
        [self deleteView];
        [self firstView];
        
    }
    
}

- (IBAction)button1Clicked:(id)sender {
    if(count==0){
        count++;
        [self deleteView];
        self.QnAButton1.hidden = NO;
        self.QnAButtonImage1.hidden = NO;
        self.Answer1.hidden = NO;
    }else {
        count = 0;
        [self deleteView];
        [self firstView];
        
    }
    
}

- (IBAction)button2Clicked:(id)sender {
    count++;
    [self deleteView];
    self.QnAButtonLabel2.hidden = NO;
    self.QnAButtonLabelImage2.hidden = NO;
    self.Answer2.hidden = NO;
}

- (IBAction)button3Clicked:(id)sender {
    count++;
    [self deleteView];
    self.QnAButtonLabel3.hidden = NO;
    self.QnAButtonLabelImage3.hidden = NO;
    self.Answer3.hidden = NO;
}

- (IBAction)button4Clicked:(id)sender {
    count++;
    [self deleteView];
    self.QnAButtonLabel4.hidden = NO;
    self.QnAButtonLabelImage4.hidden = NO;
    self.Answer4.hidden = NO;
}

- (IBAction)button5Clicked:(id)sender {
    count++;
    [self deleteView];
    self.QnAButtonLabel5.hidden = NO;
    self.QnAButtonLabelImage5.hidden = NO;
    self.Answer5.hidden = NO;
}

- (IBAction)button6Clicked:(id)sender {
    count++;
    [self deleteView];
    self.QnAButtonLabel6.hidden = NO;
    self.QnAButtonLabelImage6.hidden = NO;
    self.Answer5.hidden = NO;
}

- (IBAction)buttonLabel2Clicked:(id)sender {
    count = 0;
    [self deleteView];
    [self firstView];
}
- (IBAction)buttonLabel3Clicked:(id)sender {
    count = 0;
    [self deleteView];
    [self firstView];
}
- (IBAction)buttonLabel4Clicked:(id)sender {
    count = 0;
    [self deleteView];
    [self firstView];
}
- (IBAction)buttonLabel5Clicked:(id)sender {
    count = 0;
    [self deleteView];
    [self firstView];
}
- (IBAction)buttonLabel6Clicked:(id)sender {
    count = 0;
    [self deleteView];
    [self firstView];
}

-(void)deleteView{
    self.QnAButton1.hidden = YES;
    self.QnAButton2.hidden = YES;
    self.QnAButton3.hidden = YES;
    self.QnAButton4.hidden = YES;
    self.QnAButton5.hidden = YES;
    self.QnAButton6.hidden = YES;
    self.QnAButtonImage1.hidden = YES;
    self.QnAButtonImage2.hidden = YES;
    self.QnAButtonImage3.hidden = YES;
    self.QnAButtonImage4.hidden = YES;
    self.QnAButtonImage5.hidden = YES;
    self.QnAButtonImage6.hidden = YES;
    
    self.Answer1.hidden = YES;
    self.Answer2.hidden = YES;
    self.Answer3.hidden = YES;
    self.Answer4.hidden = YES;
    self.Answer5.hidden = YES;
    
    self.QnAButtonLabel2.hidden = YES;
    self.QnAButtonLabel3.hidden = YES;
    self.QnAButtonLabel4.hidden = YES;
    self.QnAButtonLabel5.hidden = YES;
    self.QnAButtonLabel6.hidden = YES;
    self.QnAButtonLabelImage2.hidden = YES;
    self.QnAButtonLabelImage3.hidden = YES;
    self.QnAButtonLabelImage4.hidden = YES;
    self.QnAButtonLabelImage5.hidden = YES;
    self.QnAButtonLabelImage6.hidden = YES;
}

-(void)firstView{
    self.QnAButton1.hidden = NO;
    self.QnAButton2.hidden = NO;
    self.QnAButton3.hidden = NO;
    self.QnAButton4.hidden = NO;
    self.QnAButton5.hidden = NO;
    self.QnAButton6.hidden = NO;
    self.QnAButtonImage1.hidden = NO;
    self.QnAButtonImage2.hidden = NO;
    self.QnAButtonImage3.hidden = NO;
    self.QnAButtonImage4.hidden = NO;
    self.QnAButtonImage5.hidden = NO;
    self.QnAButtonImage6.hidden = NO;
}

@end
