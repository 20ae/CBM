//
//  ViewController.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import <UIKit/UIKit.h>

@class HomeController;

@interface LoginController : UIViewController{
    HomeController *homeView;
}

-(IBAction)loginButton:(id)sender;

@property (weak, nonatomic) IBOutlet UISegmentedControl *group_segment;
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *number;



@end

