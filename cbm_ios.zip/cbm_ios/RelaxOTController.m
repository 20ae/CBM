//
//  RelaxOTController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "RelaxOTController.h"

@interface RelaxOTController ()
{
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    int testPkey;
    int testLogPkey;
    int count;
    
    int firstpg;
    int secondpg;
    
    int isDoingNetwork; //중복 터치 차단
}
//버튼관련
@property (weak, nonatomic) IBOutlet UIImageView *RelaxButBack;
@property (weak, nonatomic) IBOutlet UIButton *RelaxOTBut;
//첫번째장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel;
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel2;
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel3;

//두번째장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel4;
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel5;
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel6;

//네번째장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxOTLabel7;

@end

@implementation RelaxOTController

- (void)viewDidLoad {
    [super viewDidLoad];
    isDoingNetwork = 0;
    // Do any additional setup after loading the view.
    
    //TestPkey와 TestLogPkey
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    
    
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_blue.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼관련 설정
    self.RelaxOTBut.hidden = YES;
    self.RelaxButBack.hidden = YES;
    [self.RelaxOTBut setTitle:@"" forState:UIControlStateNormal];
    
    //앱 다시 활성활 때 호출하는 함수
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(apWillEnterForeground:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    
    //페이지 및 시간차 관련 변수
    count = 1;
    firstpg = 0;
    secondpg = 0;
    
    //각 페이지 관련 오브젝트 숨기기 및 영상 링크 가져오기
    //첫번째 장면
    {
        //RelaxOTLabel 테스트 일부 굵게하고 줄간격 설정
        _RelaxOTLabel.text = @"지금부터 3분 동안\n'말랑말랑 마음풀기'를 해볼 거예요.";
        //RelaxOTLabel textfont적용
        NSString *research =@"'말랑말랑 마음풀기'";
        NSUInteger result = [_RelaxOTLabel.text rangeOfString:research options:NSCaseInsensitiveSearch].location;
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:_RelaxOTLabel.text];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:15] range:NSMakeRange(result, research.length)];
        //RelaxOTLabel2 textfont적용
        NSString *research2 =@"말랑말랑 마음풀기";
        NSUInteger result2 = [_RelaxOTLabel2.text rangeOfString:research2 options:NSCaseInsensitiveSearch].location;
        NSMutableAttributedString* textFont2 = [[NSMutableAttributedString alloc] initWithString:_RelaxOTLabel2.text];
        [textFont2 addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(result2, research2.length)];
        
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont.length)];
        [textFont2 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont2.length)];
        
        [_RelaxOTLabel setAttributedText:textFont];
        [_RelaxOTLabel2 setAttributedText:textFont2];
        self.RelaxOTLabel2.hidden = YES;
        self.RelaxOTLabel3.hidden = YES;
    }
    //두번째 장면
    {
        NSMutableAttributedString* relaxLabel4 = [[NSMutableAttributedString alloc] initWithString:[_RelaxOTLabel4 text]];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [relaxLabel4 addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, relaxLabel4.length)];
        [_RelaxOTLabel4 setAttributedText:relaxLabel4];
        self.RelaxOTLabel4.hidden = YES;
        self.RelaxOTLabel5.hidden = YES;
        self.RelaxOTLabel6.hidden = YES;
    }
    //세번쩨 장면
    {
        NSString *strUrl = @"http://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/relax_ot/1.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay:) name:AVPlayerItemPlaybackStalledNotification object:[player currentItem]];
    }
    //네번째 장면
    {
        NSMutableAttributedString* textFont = [[NSMutableAttributedString alloc] initWithString:@"이번엔 구름이네요.\n마음이 좀 편안해졌나요?\n혹시 별로 효과가 없어도 걱정하지 말아요.\n앞으로 ‘말랑말랑 마음풀기’를 자주 연습할 거예요.\n조금씩 따라 하다 보면 마음이 편안해질 거예요:)"];
        [textFont addAttribute:NSFontAttributeName value:[UIFont fontWithName:@"NanumSquareOTF_acB" size:13] range:NSMakeRange(53, 11)];
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        [style setLineSpacing:10];
        [style setAlignment:NSTextAlignmentCenter];
        [textFont addAttribute:NSParagraphStyleAttributeName value:style range:NSMakeRange(0, textFont.length)];
        [_RelaxOTLabel7 setAttributedText:textFont];
        self.RelaxOTLabel7.hidden = YES;
    }
    
    //첫번째페이지 시간차 변수 및 함수호출
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(RelaxOT1pageNext:) userInfo:NO repeats:YES];
}
- (IBAction)ActionBut:(id)sender {
    switch (count) {
        case 1:
            {
                count++;
                self.RelaxButBack.hidden = YES;
                self.RelaxOTBut.hidden = YES;
                self.RelaxOTLabel.hidden = YES;
                self.RelaxOTLabel2.hidden = YES;
                self.RelaxOTLabel3.hidden = YES;
                
                self.RelaxOTLabel4.hidden = NO;
                //두번째페이지 시간차 변수 및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(RelaxOT2pageNext:) userInfo:NO repeats:YES];
            }
            break;
        case 2:
            {
                count++;
                self.RelaxButBack.hidden = YES;
                self.RelaxOTBut.hidden = YES;
                self.RelaxOTLabel4.hidden = YES;
                self.RelaxOTLabel5.hidden = YES;
                self.RelaxOTLabel6.hidden = YES;
                
                [player play];
                    
                playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
                playerLayer.frame = self.view.bounds;
                float x = 0;
                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                float width = playerLayer.frame.size.width;
                float height = playerLayer.frame.size.height;
                CGRect resizeRect = CGRectMake(x, y, width, height);
                [playerLayer setFrame:resizeRect];
                [self.view.layer addSublayer:playerLayer];
            }
            break;
        case 3:
            {
                count++;
                self.RelaxButBack.hidden = YES;
                self.RelaxOTBut.hidden = YES;
                playerLayer.hidden = YES;
                self.RelaxOTLabel7.hidden = NO;
                
                //세번째페이지 시간차 변수 및 함수호출
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(RelaxOT4pageNext:) userInfo:NO repeats:NO];
            }
            break;
        default:
            if(isDoingNetwork==0)
                [self updateDoneSection:testLogPkey :testPkey];
                //[self.navigationController popViewControllerAnimated:YES];
                break;
    }
}

//시간차 관련 함수
-(void)RelaxOT1pageNext:(NSTimer*)timer{
    firstpg++;
    if(firstpg==1){
        self.RelaxOTLabel2.hidden = NO;
    }
    else if(firstpg==2){
        self.RelaxOTLabel3.hidden = NO;
    }
    else{
        self.RelaxOTBut.hidden = NO;
        self.RelaxButBack.hidden = NO;
    }
    
    if(firstpg>=3){
        [timer invalidate];
    }
}
-(void)RelaxOT2pageNext:(NSTimer*)timer{
    secondpg++;
    if(secondpg==1){
        self.RelaxOTLabel5.hidden = NO;
    }
    else{
        self.RelaxOTLabel6.hidden = NO;
        self.RelaxOTBut.hidden = NO;
        self.RelaxButBack.hidden = NO;
    }
    
    if(secondpg>=2){
        [timer invalidate];
    }
}
//동영상 중단 시 호출되는 함수
- (void)replay:(NSNotification *)notification{
    [player play];
    NSLog(@"pause video replay");
}

//동영상 재생 끝난 후 호출되는 함수
- (void)playerItemDidReachEnd:(NSNotification *)notification {
    NSLog(@"Ending");
   
    self.RelaxOTBut.hidden = NO;
    self.RelaxButBack.hidden = NO;
    
}
-(void)RelaxOT4pageNext:(NSTimer*)timer{
    self.RelaxOTBut.hidden = NO;
    self.RelaxButBack.hidden = NO;
    [timer invalidate];
}

//section update 관련 함수
- (void) updateDoneSection: (int) testLogPkey : (int) testPkey{
    isDoingNetwork = 1;
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분
    NSString *url = @"http://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이다.
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey,testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                NSLog(@"network error!");
                isDoingNetwork = 0;
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
}
//홈버튼 누르고 나서 다시 앱이 활성화 할 때 호출되는 함수
- (void) apWillEnterForeground: (NSNotification *)notification{
    NSLog(@"확인");
    if(count == 3){
        if(player.timeControlStatus == AVPlayerTimeControlStatusPaused){
            [player play];
        }
    }
}

@end
