//
//  SignupController.h
//  cbm_ios
//
//  Created by ae on 2022/02/08.
//

#import <UIKit/UIKit.h>

@class SignupController;

@interface SignupController : UIViewController

- (IBAction)signup:(id)sender;

@property (weak, nonatomic) IBOutlet UISegmentedControl *group_type;
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *number;

@end


