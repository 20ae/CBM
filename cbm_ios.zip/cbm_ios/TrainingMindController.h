//
//  TrainingMindController.h
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//
@import AVFoundation;
#import <UIKit/UIKit.h>
#import "OurSlider.h"

NS_ASSUME_NONNULL_BEGIN

@interface TrainingMindController : UIViewController
@property (strong, nonatomic) AVPlayerLayer * videoLayer;
@end

NS_ASSUME_NONNULL_END
