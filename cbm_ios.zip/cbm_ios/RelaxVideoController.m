//
//  RelaxVideoController.m
//  cbm_ios
//
//  Created by mac03 on 2022/01/10.
//

#import "RelaxVideoController.h"

@interface RelaxVideoController (){
    AVPlayer *player;
    AVPlayerLayer *playerLayer;
    
    int testPkey;
    int testLogPkey;
    int count;
    
    int firstpg;
    int thirdpg;
    int fourthpg;
    
    int isDoingNetwork;
}

//버튼 관련
@property (weak, nonatomic) IBOutlet UIButton *NextButton;
@property (weak, nonatomic) IBOutlet UIImageView *ButtonBack;

//첫 번째 장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel1;
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel2;
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel3;
@property (weak, nonatomic) IBOutlet UIImageView *RelaxVideoImage;

//세 번째 장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel4;
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel5;

//네 번째 장면
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel6;
@property (weak, nonatomic) IBOutlet UILabel *RelaxVideoLabel7;

@end

@implementation RelaxVideoController

- (void)viewDidLoad {
    [super viewDidLoad];
    isDoingNetwork=0; //중복 터치 차단
    //네비게이션 바 제거
    //self.navigationController.navigationBar.hidden=YES;
    //TestPkey와 TestLogPkey
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    testPkey = (int)[userDefaults integerForKey:@"testPkey"];
    testLogPkey = (int)[userDefaults integerForKey:@"testLogPkey"];
    NSLog(@"%d",testLogPkey);
    //화면 크기에 따라 배경화면에 들어갈 이미지를 크기조절해줌.
    UIImage *image = [UIImage imageNamed:@"back_green.png"];
    float resizeWidth = UIScreen.mainScreen.bounds.size.width;
    float resizeHeight = UIScreen.mainScreen.bounds.size.height;
     
    UIGraphicsBeginImageContext(CGSizeMake(resizeWidth, resizeHeight));
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0.0, resizeHeight);
    CGContextScaleCTM(context, 1.0, -1.0);
     
    CGContextDrawImage(context, CGRectMake(0.0, 0.0, resizeWidth, resizeHeight), [image CGImage]);
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    self.view.backgroundColor = [UIColor colorWithPatternImage:scaledImage];
    
    //버튼관련 설정
    self.NextButton.hidden = YES;
    self.ButtonBack.hidden = YES;
    [self.NextButton setTitle:@"" forState:UIControlStateNormal];
    
    //앱 다시 활성활 때 호출하는 함수
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(apWillEnterForeground:)
                                                 name:UIApplicationWillEnterForegroundNotification
                                               object:nil];
    
    //페이지 및 시간차 관련 변수
    count = 1;
    firstpg = 0;
    thirdpg = 0;
    fourthpg = 0;
    //각 페이지 관련 오브젝트 숨기기 및 영상 링크 가져오기
    //첫번째 장면
    {
        self.RelaxVideoLabel2.hidden = YES;
        self.RelaxVideoLabel3.hidden = YES;
        self.RelaxVideoImage.hidden = YES;
    }
    //두번째 장면
    {
        NSString *strUrl = @"https://healingmindcenter.s3.ap-northeast-2.amazonaws.com/cbm_app/training_relax/1.mp4";
        NSURL *url = [NSURL URLWithString:strUrl];
        player = [AVPlayer playerWithURL:url];
        player.actionAtItemEnd = AVPlayerActionAtItemEndNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(playerItemDidReachEnd:)
                                                name:AVPlayerItemDidPlayToEndTimeNotification
                                                object:[player currentItem]];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(replay:) name:AVPlayerItemPlaybackStalledNotification object:[player currentItem]];
        
    }
    //세번째 장면
    {
        self.RelaxVideoLabel4.hidden = YES;
        self.RelaxVideoLabel5.hidden = YES;
    }
    //네번째 장면
    {
        self.RelaxVideoLabel6.hidden = YES;
        self.RelaxVideoLabel7.hidden = YES;
    }
    //첫번째페이지 시간차 변수 및 함수호출
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(relaxVideo1pageNext:) userInfo:NO repeats:YES];
}

//장면 타이머
-(void)relaxVideo1pageNext:(NSTimer*)timer{
    firstpg++;
    if(firstpg == 1){
        self.RelaxVideoLabel2.hidden = NO;
        self.RelaxVideoImage.hidden = NO;
    }
    else if(firstpg == 2){
        self.RelaxVideoLabel3.hidden = NO;
    }
    else {
        self.NextButton.hidden = NO;
        self.ButtonBack.hidden = NO;
    }
    
    if(firstpg >=3){
        //timer loop 종료
        [timer invalidate];
    }
}
-(void)relaxVideo3pageNext:(NSTimer*)timer{
    thirdpg++;
    if(thirdpg==1){
        self.RelaxVideoLabel5.hidden = NO;
    }else{
        self.NextButton.hidden = NO;
        self.ButtonBack.hidden = NO;
    }
    if(thirdpg >= 2){
        [timer invalidate];
    }
}
-(void)relaxVideo4pageNext:(NSTimer*)timer{
    fourthpg++;
    if(fourthpg==1){
        self.RelaxVideoLabel7.hidden = NO;
    }else{
        self.NextButton.hidden = NO;
        self.ButtonBack.hidden = NO;
    }
    if(fourthpg >= 2){
        [timer invalidate];
    }
}
//동영상 중단 시 호출되는 함수
- (void)replay:(NSNotification *)notification{
    [player play];
    NSLog(@"pause video replay");
}
//영상 끝날 때 호출 되는 함수
- (void)playerItemDidReachEnd:(NSNotification *)notification {
    NSLog(@"Ending");
    self.NextButton.hidden = NO;
    self.ButtonBack.hidden = NO;
}
//버튼 클릭 이벤트
- (IBAction)btnAction:(UIButton *)sender {
    switch (count) {
        case 1:
            {
                count++;
                self.RelaxVideoLabel1.hidden = YES;
                self.RelaxVideoLabel2.hidden = YES;
                self.RelaxVideoLabel3.hidden = YES;
                self.RelaxVideoImage.hidden = YES;
                self.NextButton.hidden = YES;
                self.ButtonBack.hidden = YES;
                
                [player play];
                    
                playerLayer = [AVPlayerLayer playerLayerWithPlayer:player];
                playerLayer.frame = self.view.bounds;
                float x = 0;
                float y = -UIScreen.mainScreen.bounds.size.height * 0.05;
                float width = playerLayer.frame.size.width;
                float height = playerLayer.frame.size.height;
                CGRect resizeRect = CGRectMake(x, y, width, height);
                [playerLayer setFrame:resizeRect];
                [self.view.layer addSublayer:playerLayer];
            }
            break;
        case 2:
            {
                count++;
                self.NextButton.hidden = YES;
                self.ButtonBack.hidden = YES;
                playerLayer.hidden = YES;
            
                self.RelaxVideoLabel4.hidden = NO;
                NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(relaxVideo3pageNext:) userInfo:NO repeats:YES];
            }
            break;
        case 3:
        {
            count++;
            self.RelaxVideoLabel4.hidden = YES;
            self.RelaxVideoLabel5.hidden = YES;
            self.NextButton.hidden = YES;
            self.ButtonBack.hidden = YES;
            
            self.RelaxVideoLabel6.hidden = NO;
            NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(relaxVideo4pageNext:) userInfo:NO repeats:YES];
        }break;
        default:
            if(isDoingNetwork==0)
                [self updateDoneSection:testLogPkey :testPkey];
                //[self.navigationController popViewControllerAnimated:YES];
                break;
    }
}

//완료
- (void) updateDoneSection: (int) testLogPkey : (int) testPkey{
    isDoingNetwork = 1;
    // Create the configuration, which is necessary so we can cancel cacheing amongst other things.
    NSURLSessionConfiguration * defaultConfigObject = [NSURLSessionConfiguration defaultSessionConfiguration];
    // Disables cacheing
    defaultConfigObject.requestCachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
    NSURLSession * defaultSession = [NSURLSession sessionWithConfiguration:defaultConfigObject delegate:self delegateQueue:[NSOperationQueue mainQueue]];
    
    //url부분
    NSString *url = @"https://healingmindcenter.com/cbm_app/cbm_api/request_done_section.php";
    NSMutableURLRequest * urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    
    //post 데이터를 넣는 부분 -> NSString일때 %@, int일때 %d이다.
    NSString *postData = [NSString stringWithFormat:@"Pkey=%d&testPkey=%d", testLogPkey,testPkey];
    [urlRequest setHTTPMethod:@"POST"];
    [urlRequest setHTTPBody:[postData dataUsingEncoding:NSUTF8StringEncoding]];
    NSURLSessionDataTask * dataTask = [defaultSession dataTaskWithRequest:urlRequest completionHandler: ^(NSData *data, NSURLResponse *response, NSError *error){
            
            if(error){
                isDoingNetwork = 0;
                NSLog(@"network error!");
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                    [alert dismissViewControllerAnimated:YES completion:nil];   }];
                [alert addAction:cancel];
                [self presentViewController:alert animated:YES completion:nil];
            }
            else{
                NSString *content = [[NSString alloc]  initWithBytes:(char *)data.bytes length:data.length encoding: 0x80000422];
                NSLog(@"responseData1: %@", content);
                if([content intValue] == 0)
                    [self.navigationController popViewControllerAnimated:YES]; // 홈으로 이동
                else{
                    isDoingNetwork = 0;
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"네트워크 오류" message:@"네트워크 연결에 실패했습니다.\n다시 실행해 주세요." preferredStyle: UIAlertControllerStyleAlert];
                    UIAlertController* cancel = [UIAlertAction actionWithTitle:@"확인" style:UIAlertActionStyleDefault handler:^(UIAlertAction * action){
                        [alert dismissViewControllerAnimated:YES completion:nil];   }];
                    [alert addAction:cancel];
                    [self presentViewController:alert animated:YES completion:nil];
                }
            }
            
        } ];
    [dataTask resume];
}
//홈버튼 누르고 나서 다시 앱이 활성화 할 때 호출되는 함수
- (void) apWillEnterForeground: (NSNotification *)notification{
    NSLog(@"확인");
    if(count==2){
        if(player.timeControlStatus == AVPlayerTimeControlStatusPaused){
            [player play];
        }
    }
}
@end
